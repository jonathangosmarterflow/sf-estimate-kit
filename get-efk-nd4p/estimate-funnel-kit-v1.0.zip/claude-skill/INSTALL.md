# Install the Claude skill (3 ways)

The skill is the folder `estimate-funnel-builder` sitting next to this file. It contains `SKILL.md` and a `reference/` folder. Pick whichever of the three ways matches how you use Claude. If none of them fit, skip this file entirely and use `prompts/BUILDER-PROMPT.md` instead. It works in any AI chat and gets you the same config.

---

## Way 1. Claude Code (the terminal or the VS Code extension)

This is the path we use on camera.

1. Open your terminal.
2. Copy the skill folder into your skills directory. For all your projects:

   ```
   mkdir -p ~/.claude/skills
   cp -R "estimate-funnel-builder" ~/.claude/skills/
   ```

   Or, to keep it to one project only, from inside that project's folder:

   ```
   mkdir -p .claude/skills
   cp -R "/path/to/kit/claude-skill/estimate-funnel-builder" .claude/skills/
   ```

3. Start Claude Code in the folder where you unzipped the kit (the folder with `studio.html` in it).
4. Type: **build my estimate funnel**

DONE looks like: Claude tells you it found the kit, asks you for context, then asks a handful of questions.

Note: the skill reads and writes files inside the kit folder, so start Claude Code in that folder. If you started somewhere else, tell Claude the full path to the kit.

If your Claude cannot reach files at all, it will say so and hand you the settings as one block of JSON instead. That is the fallback and it gets you to the same funnel: open `studio.html`, stay on tab 1 **Niche**, paste the block under **Paste your AI answer here**, press **Check it**, then **Accept and use these settings**, and download your funnel from tab 6 **Publish**.

---

## Way 2. Claude desktop or Claude on the web

Skill support here depends on your plan, so check before you spend time on it.

1. Open **Settings**. If your plan shows a **Capabilities** section with **Skills** in it, you can upload a skill. If you do not see a Skills section, skip to Way 3 or use the any AI prompt.
2. Zip the `estimate-funnel-builder` folder (right click the folder, Compress on a Mac, Send to > Compressed folder on Windows).
3. Upload the zip in the Skills section and enable it.
4. Start a new chat, attach your price list or any notes you have, and type: **build my estimate funnel**
5. Claude cannot write files to your computer from the web. So when it gives you the config, copy the JSON, open `studio.html` from your kit folder, and on tab 1 **Niche** paste it into the box under **Paste your AI answer here**. Press **Check it**, then **Accept and use these settings**. The Studio builds and downloads the funnel file for you from tab 6 **Publish**.

If your plan shows no Skills section, that is not a problem. Way 3 and the any AI prompt both get you to the same finished funnel.

---

## Way 3. A Claude Project

Good if you want it available to a whole team without installing anything.

1. Create a new Project in Claude.
2. Open the project's **instructions** (the custom instructions box) and paste the whole contents of `prompts/BUILDER-PROMPT.md` into it.
3. Upload to the project's knowledge: the `presets/` files for the niches you care about, plus this kit's `PLAYBOOK.md`.
4. Start a chat in that project and say: **build my estimate funnel**
5. Copy the JSON it gives you into `studio.html`, tab 1 **Niche**, under **Paste your AI answer here**.

---

## No AI at all

You do not need any of this. Open `studio.html`, pick your niche on tab 1, and type your own services and prices on tab 3. The AI only ever fills in the same form faster.

---

## Troubleshooting

- **"Claude does not react to build my estimate funnel."** The skill is not loaded. In Claude Code, check that `SKILL.md` sits at `~/.claude/skills/estimate-funnel-builder/SKILL.md` and restart the session.
- **"It cannot find the kit."** Tell it the full path to the folder that contains `studio.html`.
- **"It wrote the config but not the funnel file."** Say: "now build my-funnel.html from funnel.html". Or paste the config into `studio.html` on tab 1 **Niche** and download the funnel from tab 6 **Publish**.
- **"The doctor command fails."** That is Node.js missing, and it is optional. The Studio runs the same checks in your browser with no install.
