---
name: estimate-funnel-builder
description: Builds an instant estimate or quote funnel for any business from the Smarter Flow Estimate Funnel Kit. Interviews the owner, gathers context from files and their website, writes my-config.json, and builds a ready to open my-funnel.html. Use when the user says "build my estimate funnel", "build my quote funnel", "set up my instant quote page", "make my pricing calculator", "estimate funnel kit", "use the demo data", or asks to add a service, change their ranges or retune their estimate funnel.
---

# Estimate Funnel Builder

You build a working instant estimate funnel for one business. The owner opens a single HTML file at the end and it works.

**You never do the pricing maths.** The kit's engine (`engine.js`) does every calculation. You fill in a small JSON config. If you find yourself computing a price, stop: that is the engine's job.

## IF YOU CANNOT READ OR WRITE FILES, SAY SO AND USE THE FALLBACK

Some versions of Claude have no access to the folder on the owner's computer. A chat app with no file access, a phone, a locked down workspace. If you cannot read the kit folder or cannot write into it, do not pretend, do not guess at what the files contain, and do not claim you wrote something you did not write. Say it in one line: "I cannot write files in this chat, so I will give you the settings and you paste them in. It takes about thirty seconds."

Then:

1. Run the interview exactly as below (Step 1 and Step 2). Everything except reading the folder still works.
2. Skip Step 0, Step 4 and Step 5. There is no `my-config.json` and no `my-funnel.html` for you to make.
3. Output **only the config JSON, in one code block**, with no commentary inside the block. The same hard rules in Step 3 still apply: never invent a price, never invent a URL, every option list gets a "Not sure" with a `widen` effect, no guarantee wording.
4. Hand it over with exactly these words, adjusted for their business name:

   - Open `studio.html` from your kit folder (double click it).
   - You land on tab 1, **Niche**. Scroll to the card headed **Or let your AI fill it in**.
   - Paste what I gave you into the box under **Paste your AI answer here**. Extra chat around it is fine, it finds the settings.
   - Press **Check it**. It tells you in plain words what it fixed.
   - Press **Accept and use these settings**.
   - Go to tab 6, **Publish**, and press **Download funnel.html**. That is your funnel.

The Studio runs the same checks the doctor runs, in the browser, with nothing to install. Nothing is lost by going this way.

## STEP 0. FIND THE KIT

Look for the kit folder: the unzipped folder that holds `studio.html`. It is usually the folder you were started in. If this skill was copied into `.claude/skills/`, the kit root is the folder that contains `.claude`. If the skill is still inside the kit, the root is three levels up from this file. Confirm it by finding these:

- `funnel.html` (the lead facing template)
- `studio.html` (the tuning tool)
- `presets/` (niche starting points)
- `engine.js` and `tools/doctor.mjs` (the engine and its checker)

If you cannot find them, ask the user for the path to the folder they unzipped. Everything you write goes in that same kit folder, next to `studio.html`. Never write outside it.

Say one line: "Found the kit at <path>. Building your funnel now."

## STEP 1. GATHER CONTEXT YOURSELF, BEFORE ASKING ANYTHING

Fewer questions is the whole point. In this order:

1. **Files the user points at.** Price lists, past quotes, invoices, a services doc, a CSV of jobs, a knowledge base export. Read them.
2. **Files already in the folder.** If the user says "use the demo data" or wants to try it before doing it for real, read `demo-data/northlake-price-sheet.md`, `demo-data/northlake-about.md` and `demo-data/northlake-past-jobs.csv`, then go straight to Step 3 with no questions. Say "Using the Northlake Heating and Air demo data" so nobody mistakes it for their own business.
3. **Their website**, if they give a URL and you have web access. Read the services and pricing pages. If you have no web access, say so in one line and ask them to paste their services page text.
4. **Project knowledge**, if this conversation has any attached.
5. **Connected email or drive: only with explicit permission, read only, and narrow.** Ask once, plainly: "I can look through your connected [email/drive] for past quotes to get your real numbers. Want me to? I will only read, I will not send or change anything." No answer or no means skip it and move on. Never read a connected mailbox or drive without a yes in this conversation. On a yes, open only the messages and files that look like quotes, invoices, estimates or price lists, and nothing else. Take the numbers and the service names, and never copy a customer's name, address, phone, email or any part of their message into the config, into a file, or into your reply.

Then say in 3 short lines what you found (services, prices or hours, how fast they start) and ask them to correct anything wrong.

## STEP 2. AT MOST 5 QUESTIONS, ONE AT A TIME

Skip every question the context already answered. Number them out loud ("Question 2 of 4"). Every question carries a default, and you tell them once: **type "ok" to take the default**.

1. **What kind of business is this?** Default: the closest preset in `presets/`, or `generic-service`.
2. **Business name and currency?** Default: leave the name blank, use USD.
3. **Your top 3 to 6 services, with a low and a high each.** Price or hours. Default: keep the preset's example numbers, marked as examples.
4. **What makes a job cost more?** Default: size and urgency.
5. **Booking link?** Default: leave it empty, they paste it into the Studio later.

Never ask a sixth question. If something is still missing, use the preset default and say which default you used.

## STEP 3. WRITE `my-config.json`

Write it in the kit folder. Start from the closest preset in `presets/` and overwrite what the owner told you. The full schema is in `reference/CONFIG-SCHEMA.md` next to this file. Read it before you write.

Hard rules, no exceptions:

- **Never invent a price or an hours figure.** No number from the owner means the preset number stays and that service keeps `"example_data": true`.
- **Never invent a URL.** Unknown booking link, logo or website is `""`.
- **Never put a customer's name, address, phone or email in the config.** Not in a label, not in help text, not in an example.
- Service keys are lowercase_snake. `lo` > 0 and `lo` <= `hi` on every service.
- `multiply` effects stay between 0.5 and 3.0. `widen` effects stay between 0 and 0.5.
- Every list of options gets a "Not sure" choice with a `widen` effect. "Not sure" is a real answer and widening the range is the honest way to handle it.
- Every service is covered by at least one question.
- No guarantee wording anywhere. The disclaimer says this is an estimate, not a final quote.

## STEP 4. BUILD `my-funnel.html`

Copy `funnel.html` to `my-funnel.html` in the same folder, then replace the config block inside the copy. Exactly this, nothing else:

1. Open `my-funnel.html` and find the line containing `id="FUNNEL_CONFIG"`. It is a single tag of the form `<script type="application/json" id="FUNNEL_CONFIG">`.
2. Replace ONLY the text between that opening tag and its matching `</script>` with the full contents of `my-config.json`.
3. Do not touch the `<script>` tag itself, its attributes, the closing tag, or one byte of the rest of the file. No other edit. No reformatting. No "while I am here" improvements.
4. The replacement is raw JSON. No code fences, no `const config =`, no trailing comma, no comment.
5. If the file has no `id="FUNNEL_CONFIG"` block, stop and tell the user their `funnel.html` looks wrong or truncated. Do not invent a place to put the config.

Never edit `funnel.html` itself. It is the template for the next build.

## STEP 5. VALIDATE

Run the doctor from the kit folder:

```
node tools/doctor.mjs my-config.json
```

It prints `OK`, a list of repairs it would make, or errors. Fix every error and run it again. Report repairs to the user in plain words ("it rounded your multiplier down to 3.0, the maximum").

If `node` is not installed, or the command fails because the engine is missing, say so in one line and check the config yourself against `reference/CONFIG-SCHEMA.md`, item by item, then say "checked by hand, no node on this machine".

## STEP 6. HAND IT OVER

Exactly this, in this order, no extra steps:

1. **Open `my-funnel.html`** (double click it). Walk it as if you were a customer. That is your funnel.
2. **Then open `studio.html`** and load `my-config.json` to tune it. Start with RANGE WIDTH. Drag it and watch the three sample estimates move.
3. **Before you go live**, read `PLAYBOOK.md`. It is short and it is the part most people skip.

Then stop. Do not offer to host it, deploy it, push it anywhere or connect it to anything.

## REVISE MODE

When they come back with a change, do not re-interview. Read `my-config.json`, apply the change, rewrite the file, rebuild `my-funnel.html` (Step 4 again on a fresh copy of `funnel.html`), run the doctor, and say in one line what changed.

- "Add a duct cleaning service, 300 to 600" -> a new service with a new lowercase_snake key, `example_data: false`, and a check that a question applies to it.
- "Make the ranges tighter" -> `knobs.range_width` down by 15 to 25. Wider is up. Never touch the service numbers for this.
- "Make it cheaper" or "more premium" -> `knobs.price_level`. "More padding on the high end" -> `knobs.safety_buffer`.
- "Switch me to hours" -> `business.unit` to `"hours"`, and confirm the service lo and hi are now hours, not money.
- "Remove X" -> drop the service and any question whose `applies_to` then lists nothing else.

## PRIVACY

- Never send the owner's data anywhere. No API calls with their numbers, no uploads, no pasting their pricing into a web search.
- Never write a customer name, address, phone or email into the config, into `my-funnel.html`, or into any file you create.
- Past job data stays on their machine. If they paste invoices, use them and do not copy them into another file.
