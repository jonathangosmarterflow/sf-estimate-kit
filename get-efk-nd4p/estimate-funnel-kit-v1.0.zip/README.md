# Estimate Funnel Kit v1.0

An instant estimate funnel for any business, in any niche, built in about ten minutes, with whatever AI you already use, or with no AI at all.

**Start here: open `START-HERE.html` in your browser.** Double click it. That is the whole install.

---

## What this is

A customer lands on your page, answers a handful of questions, and sees a real price range and a realistic timeline straight away, then books a call. No "contact us for a quote", no waiting, no back and forth.

The maths is done by code that ships with the kit, in the customer's browser, offline, with no server and no account. The AI, if you use one, only fills in a small settings file: your services, your numbers, your questions. That is deliberate. It means the funnel works the same whether you used the smartest AI on the market or the cheapest one on your phone.

## The three paths

| You | Do this |
|---|---|
| Use Claude | Install the skill in `claude-skill/`, then say "build my estimate funnel" |
| Use another AI | Paste `prompts/BUILDER-PROMPT.md` into ChatGPT, Gemini, Meta AI, anything |
| Use no AI | Open `studio.html`, pick your niche, type your prices |

All three end in the same place: a `my-config.json` file with your numbers in it, and a single `my-funnel.html` file you can put anywhere.

## The files

```
START-HERE.html      pick your path, three cards, start here
studio.html          THE MAIN TOOL. Niche, business, prices, knobs, train, publish.
funnel.html          the template your customers see. One file. Works offline.
src/engine.js        the pricing engine. Pure functions, no dependencies.
presets/             starting points per niche (hvac, plumbing, cleaning, agency...)
demo-data/           a fake HVAC business to try the whole thing on
prompts/
  BUILDER-PROMPT.md          paste into any AI to build your config
  CALIBRATE-PROMPT.md        turns messy past invoices into clean training rows
  REVIEW-MY-FUNNEL-PROMPT.md has an AI play three customers and report what is broken
claude-skill/
  INSTALL.md                 3 ways to use the Claude path
  estimate-funnel-builder/   the skill itself
highlevel/INSTALL.md   host it, embed it, and catch the lead in HighLevel. Click by click.
tools/doctor.mjs       optional command line check of your config (needs Node.js)
PLAYBOOK.md            12 lessons from running a live estimate funnel. Read it.
NICHE-IDEAS.md         40 niches this works for, and what each funnel asks
LICENSE.txt            use it for your business and your clients' businesses
```

## The six knobs

Every one is a 0 to 100 number, and the Studio tells you in plain words what each number does to your estimate.

- **RANGE WIDTH** how far apart your low and high sit. The first one you should touch.
- **PRICE LEVEL** shifts the whole range up or down.
- **SAFETY BUFFER** padding, on the high end only, never on the low end.
- **RUSH PREMIUM** how much a hurry costs.
- **ROUNDING** exact numbers, or round ones.
- **DETAIL SHOWN** the range only, or the range plus what drives it, or a full breakdown.

## Train it on your real jobs

The Train tab takes your past jobs (service, what you quoted, what it actually came to) and tells you, per service, whether you run high or low. It never changes your prices on its own. You accept or reject each suggestion.

It needs at least 3 jobs for a service before it says anything, treats 3 or 4 as low confidence, never moves more than 15% in one round, and shows you outliers instead of quietly using them. Those four rules are there because we learned each one the hard way. The Playbook explains how.

## What this kit will never do

- Invent a price. Numbers you did not give it stay flagged as examples and block publishing.
- Invent a link. An unknown booking URL stays empty rather than plausible and wrong.
- Send your data anywhere. Everything runs in your browser, on your machine.
- Put the word "guaranteed" in front of a customer. It is an estimate, not a quote.
- Need an account, a subscription, an API key or an internet connection to calculate.

## Requirements

A web browser. That is it.

Node.js is optional and only powers `tools/doctor.mjs`, which does the same checks the Studio already does in your browser.

## Stuck?

Reply to your receipt email and say where you got stuck. That feedback is how this kit gets better.

---

*Built by Smarter Flow. Licence in `LICENSE.txt`: use it for your own business and your clients' businesses, do not resell the kit itself.*
