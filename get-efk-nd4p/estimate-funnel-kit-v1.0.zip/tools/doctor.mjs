#!/usr/bin/env node
// doctor.mjs - Estimate Funnel Kit v1.0
// Thin CLI around EFK.doctor() in ../engine.js. No dependencies.
//
//   node kit/tools/doctor.mjs my-config.json
//   cat my-config.json | node kit/tools/doctor.mjs
//   node kit/tools/doctor.mjs my-config.json --json      (machine readable)
//   node kit/tools/doctor.mjs my-config.json --fixed out.json  (write the repaired config)
//
// Exit codes: 0 = ok (repairs and warnings allowed), 1 = errors, 2 = could not run.

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
// In the downloaded kit the engine sits next to studio.html. In the source tree it is in src/.
const enginePath = [resolve(here, '../engine.js'), resolve(here, '../src/engine.js')].find((p) => existsSync(p)) || resolve(here, '../engine.js');

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const fixedAt = args.includes('--fixed') ? args[args.indexOf('--fixed') + 1] : null;
const file = args.find((a) => !a.startsWith('--') && a !== fixedAt);

function die(msg, code = 2) {
  if (asJson) console.log(JSON.stringify({ ok: false, errors: [msg], repairs: [], warnings: [] }));
  else console.error('CANNOT RUN: ' + msg);
  process.exit(code);
}

// --- load the engine -------------------------------------------------------
let EFK;
try {
  const mod = await import(enginePath);
  EFK = mod.EFK || mod.default || globalThis.EFK;
} catch (e) {
  die(
    'engine not found or failed to load at ' + enginePath + '\n' +
      String(e && e.message ? e.message : e) +
      '\nThe kit is incomplete. Re-download it, or use studio.html which runs the same checks in your browser.'
  );
}
if (!EFK || typeof EFK.doctor !== 'function') {
  die('engine loaded but EFK.doctor is missing. Re-download the kit.');
}

// --- read the config -------------------------------------------------------
let text;
if (file) {
  try {
    text = readFileSync(resolve(process.cwd(), file), 'utf8');
  } catch (e) {
    die('cannot read ' + file + ': ' + (e && e.message));
  }
} else if (!process.stdin.isTTY) {
  text = readFileSync(0, 'utf8');
} else {
  die('no config given.\nUsage: node kit/tools/doctor.mjs my-config.json');
}

// --- run -------------------------------------------------------------------
let r;
try {
  r = EFK.doctor(text);
} catch (e) {
  // EFK.doctor is specified never to throw. If it does, that is a kit bug, not a config problem.
  die('the doctor crashed on this config (that is a kit bug): ' + (e && e.message));
}

const repairs = r.repairs || [];
const errors = r.errors || [];
const warnings = r.warnings || [];
const ok = r.ok !== false && errors.length === 0;

if (fixedAt && r.config) {
  try {
    writeFileSync(resolve(process.cwd(), fixedAt), JSON.stringify(r.config, null, 2) + '\n');
  } catch (e) {
    die('could not write ' + fixedAt + ': ' + (e && e.message));
  }
}

if (asJson) {
  console.log(JSON.stringify({ ok, repairs, warnings, errors }, null, 2));
  process.exit(ok ? 0 : 1);
}

const line = (prefix, items) => items.forEach((s) => console.log('  ' + prefix + ' ' + s));

if (ok && repairs.length === 0 && warnings.length === 0) {
  console.log('OK. This config is ready. Open your funnel file and walk it as a customer.');
} else if (ok) {
  console.log('OK, with notes.');
} else {
  console.log('NOT READY. Fix the errors below, then run this again.');
}

if (repairs.length) {
  console.log('\nREPAIRED (' + repairs.length + '), the kit fixed these for you:');
  line('-', repairs);
}
if (warnings.length) {
  console.log('\nWORTH A LOOK (' + warnings.length + '):');
  line('-', warnings);
}
if (errors.length) {
  console.log('\nERRORS (' + errors.length + '), the funnel will not run until these are fixed:');
  line('!', errors);
}
if (repairs.length && !fixedAt) {
  console.log('\nTo save the repaired version:  node kit/tools/doctor.mjs ' + (file || 'my-config.json') + ' --fixed my-config.json');
}

process.exit(ok ? 0 : 1);
