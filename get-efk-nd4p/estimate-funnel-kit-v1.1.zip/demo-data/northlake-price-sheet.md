# Northlake H&A - price notes (internal, not for customers)

updated whenever Ray remembers to. don't hand this to a customer, just use it as a gut check.

## AC stuff

- AC repair - general: 160 to 620. ~~was 500 now 600~~ for compressor jobs specifically, more like 550-700
- AC repair, capacitor or fan motor only: usually 175-260, quick job
- AC install / full replace: 4700 - 9800 depending on unit size and brand. builder grade units come in lower end
  - Ray says bump this in July, everybody wants AC in July and we're slammed
- if it's a rooftop unit add 300-500 to whatever the number is, way more of a pain

## Furnace stuff

- furnace repair: 160-720, ~~was 650 now 700~~ (ignition or blower issues run higher)
- furnace install: 3900-7600. gas furnaces on the low end, high efficiency units toward the top
- full system replace (AC + furnace together): starts at 8200, can run past 16k for bigger homes or two systems
  - two systems = two zones, don't quote single system price for a two zone house, learned that the hard way

## Duct cleaning

- whole home duct cleaning: 375-950
- add-on: dryer vent cleaning +85 if they want it same visit
- if there's obvious mold or rodents in the ducts, that's a different quote, don't use this sheet

## Maintenance / tune ups

- seasonal tune up: 95-210
- tune up + filter swap: +25
- Ray comps this for anyone on the maintenance plan, don't quote if they mention "plan member"

## Thermostat

- thermostat install, standard programmable: 210-450
- thermostat install, smart / wifi (Nest, Ecobee etc): 350-620
- if wiring is old (no C-wire) add 75-150 for the extra wiring work

## Trip charge / after hours (read this part)

- standard trip charge inside city limits: waived if they book the job
- trip charge if they DON'T book: $65, always mention this up front so nobody's surprised
- after hours (nights, weekends): add 25% to whatever the base number is
- after hours AND emergency same day: add 40%, not 25% + 40% stacked, just use the bigger one
- holiday calls: call Ray first before quoting anything, he wants to price those himself

## Access notes (this moves the price more than people think)

- attic units, easy pull down stairs: no change
- crawl space access: add 75-150 labor
- rooftop commercial-style units on a residential home: treat like commercial, call Ray
- gated community or HOA needing a scheduled window: add a day to the timeline, not the price

## Misc asides

- Ray says never quote a full system replace over the phone, always needs the in person walkthrough
- old customers (5+ years with us) get the lower end of whatever range applies, don't need to ask, just do it
- financing available through the usual partner, doesn't change the cash price above
- if a customer mentions "I got a quote from [competitor] for way less" don't chase it down, just note it and move on

## Numbers Ray keeps changing his mind about

- duct cleaning: was quoted low as 300 a while back, that's too low now with what we pay techs, use the 375 floor
- thermostat install smart tier: ~~was 300 now 350~~ (going up again probably by fall)
- maintenance tune up: keep it under 220 even in peak season, it's a loss leader on purpose
