# 40 niches this works for

Any business where the honest answer to "what does it cost" is "somewhere between X and Y, depending", and where the customer today gets told "book a call and we'll tell you". That is most local service businesses and most agencies.

The middle column is what that funnel asks. It is a starting point, not a rule. Whatever moves the price in a trade is what its funnel should ask about, and nothing else. Three to five questions is the sweet spot. Seven is too many.

If your niche is not listed, pick the closest one, load it in the Studio and rename the services. The engine does not care what trade it is.

## Home services

| # | Niche | What the funnel asks |
|---|---|---|
| 1 | HVAC | Repair or replace, home size, unit age, where the unit sits, how soon |
| 2 | Plumbing | Job type, one fixture or whole house, is it leaking right now, property age |
| 3 | Roofing | Roof size or home footprint, material, storeys, repair or full replacement, is it leaking |
| 4 | Electrical | Job type, panel age, how many outlets or fixtures, permit needed, urgency |
| 5 | Painting | Interior or exterior, rooms or square footage, ceilings and trim included, prep and repairs needed |
| 6 | Landscaping and lawn care | One off or ongoing, lot size, which services, slope and access, how often |
| 7 | Pest control | Which pest, property size, one treatment or a plan, how bad is it now |
| 8 | Flooring | Material, square footage, rooms, removing the old floor, subfloor condition |
| 9 | Windows and doors | How many, single or double glazed, frame material, one storey or two |
| 10 | Solar | Monthly power bill, roof type and age, battery wanted, own or rent |
| 11 | Pools | Build, resurface or service, size, features wanted, access for machinery |
| 12 | Fencing and decking | Linear feet or square footage, material, height, removing the old one, ground slope |
| 13 | Remodeling and general contracting | Which room, size, moving plumbing or walls, finish level, permits |
| 14 | Tree service | How many trees, height, near the house or power lines, stump removal, haul away |
| 15 | Pressure washing | Surfaces, square footage, storeys, how long since the last clean |
| 16 | Concrete and driveways | Square footage, new pour or replace, finish, removing the old surface, access |

## Cleaning, moving and restoration

| # | Niche | What the funnel asks |
|---|---|---|
| 17 | Residential cleaning | Bedrooms and bathrooms, one off deep clean or recurring, how often, pets, add ons |
| 18 | Commercial janitorial | Square footage, how many nights a week, restrooms, floor type, after hours access |
| 19 | Junk removal | How much (a truckload picture scale works well), what it is, stairs, same day |
| 20 | Moving | Bedrooms, distance, stairs or elevator, packing wanted, storage needed |
| 21 | Water and fire damage restoration | What happened, how many rooms, how long ago, insurance claim, standing water now |
| 22 | Appliance repair | Which appliance, brand, symptom, in warranty, how old |

## Automotive

| # | Niche | What the funnel asks |
|---|---|---|
| 23 | Auto detailing and ceramic coating | Vehicle size, interior or exterior or both, condition, coating wanted, mobile or in shop |
| 24 | Auto repair | Make and model, year, symptom, warning light on, drivable right now |
| 25 | Window tint and vinyl wrap | Vehicle size, how many windows or full wrap, film or finish, removing old film |

## Agency, marketing and professional services

| # | Niche | What the funnel asks |
|---|---|---|
| 26 | HighLevel agency and automation | What to build, how many funnels and workflows, existing account or fresh, integrations, go live date |
| 27 | Web design | How many pages, new or redesign, ecommerce, content ready, deadline |
| 28 | Paid ads management | Monthly ad budget, which platforms, creative needed, existing account or new, landing pages included |
| 29 | Video production | Video length, how many, filming days, location, script and editing included |
| 30 | Business consulting | Scope, company size, on site or remote, how many weeks, deliverables wanted |
| 31 | Bookkeeping and accounting | Monthly transaction volume, how many accounts, payroll, how far behind, tax filing included |
| 32 | IT support and managed services | How many users and devices, servers, on site visits, hours of cover, security add ons |
| 33 | Recruiting and staffing | Which role, seniority, how many hires, contract or permanent, how fast |

## Health, beauty and coaching

| # | Niche | What the funnel asks |
|---|---|---|
| 34 | Med spa and aesthetics | Which treatment, area, first time or maintenance, package or single session |
| 35 | Dental | Which treatment, how many teeth, insurance, x rays done recently, sedation |
| 36 | Personal training and coaching | Goal, sessions per week, one to one or small group, how many weeks, nutrition included |

## Events and specialty

| # | Niche | What the funnel asks |
|---|---|---|
| 37 | Wedding and event photography | Date, hours of coverage, second shooter, album wanted, travel |
| 38 | Catering | Headcount, menu style, service staff, venue has a kitchen, bar service |
| 39 | Equipment rental | Which equipment, how many days, delivery and pickup, operator needed, weekend |
| 40 | Signage and large format print | Size, how many, material, installation, how fast |

---

# For agencies: sell this as a service

Most of the businesses above will never install a funnel themselves. That is the opportunity. The kit is licensed for exactly this: build funnels for your clients and charge whatever you like for the work. You may not resell the kit itself. See `LICENSE.txt`.

## Six ways agencies are using it

**1. The paid audit opener.** A local business owner says "I'll think about it". Instead of a proposal, build their estimate funnel live on the call in ten minutes, with their real services and their real numbers. They watch a thing get built. That is a completely different conversation to a slide deck.

**2. As the onboarding step, not a deliverable.** Most local clients cannot articulate what they charge until someone makes them write it down. The interview inside the builder prompt does that for you. You come out of it with their services, their ranges, what drives their pricing and their timelines, which is exactly what every other thing you build for them needs anyway.

**3. Bundled into a lead gen retainer.** The estimate funnel is the front of the funnel, the HighLevel workflow in `highlevel/INSTALL.md` is the middle, their calendar is the end. You are not selling a page, you are selling the mechanism that turns anonymous traffic into a booked appointment with a number already attached.

**4. As a snapshot style offer across one niche.** Build it once properly for one HVAC company, then the second one takes twenty minutes because you already know what HVAC funnels ask. Niche by niche, your build time collapses while your price does not have to.

**5. The reactivation angle.** Every agency has a list of clients who went quiet. "I built you something, want to see it" with a working funnel for their actual business behind the link is the highest answer rate message most agencies have.

**6. As proof in a competitive pitch.** When you are up against two other agencies, be the one who already built something. Nobody else in the pitch is going to do that.

## What to charge

That is your call and it depends on your market, your client's size and what else you are bundling. Two things worth knowing before you price it:

- The build is fast, but the value is not in the build. It is in the pricing conversation and the ongoing calibration. Price the outcome, not the ten minutes.
- The calibrate habit in `PLAYBOOK.md` (pull the finished jobs, train the engine, adjust one thing) is a genuine recurring service. It takes fifteen minutes and it is the difference between a funnel that gets more accurate every month and one that quietly drifts. That is a retainer line item, and it is one your client can feel.

## Doing it at scale

- Build one config per client and keep them in one folder. The config is small and plain text.
- Once you have done three funnels in a niche, save the best one as your own preset. The next one starts from that instead of from the generic one.
- Every client's funnel points at their own webhook and their own calendar. Nothing is shared and nothing is central, so one client's changes can never affect another's.
- Hand the client `PLAYBOOK.md` at handover. A client who understands why the range is wide will not ask you to narrow it.
