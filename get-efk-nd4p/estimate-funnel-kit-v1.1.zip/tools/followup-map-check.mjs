#!/usr/bin/env node
/* Estimate Funnel Kit - followup-map-check.mjs
 * Proves the follow-up map and the HighLevel install guide say the same thing.
 *
 *   node tools/followup-map-check.mjs
 *
 * It reads the follow-up sequence (src/followup-sequence.json, else the copy in
 * highlevel/followup-sequence.json, else the one baked into followup-map.html) and
 * checks, for the lead sequence and the booking sequence:
 *   - every step has the keys the map needs
 *   - the steps are in time order (delays never go backwards)
 *   - every merge field is a real webhook key
 *   - every {{placeholder}} in a message is one the map knows how to fill
 *   - every subject and body is word for word in highlevel/INSTALL.md
 *   - every message to the lead has at most one link, and every SMS has the STOP line
 *   - the map page carries the same sequence as the source file
 * Exit code 0 = all good. Exit code 1 = something drifted, and it says what.
 * No npm packages.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const KIT = path.resolve(HERE, '..');
const SEQ_SRC = path.join(KIT, 'src', 'followup-sequence.json');
const SEQ_SHIP = path.join(KIT, 'highlevel', 'followup-sequence.json');
const MAP_HTML = path.join(KIT, 'followup-map.html');
const INSTALL = path.join(KIT, 'highlevel', 'INSTALL.md');
const ENGINE = path.join(KIT, 'engine.js');

const WEBHOOK_KEYS = [
  'name', 'email', 'phone', 'business_name', 'niche', 'services_text',
  'estimate_low', 'estimate_high', 'estimate_low_text', 'estimate_high_text',
  'estimate_unit', 'currency', 'timeline_text', 'answers_text', 'knobs_text',
  'page_url', 'utm_source', 'utm_medium', 'utm_campaign', 'submitted_at',
  'kit_version', 'summary_text', 'possibly_fake', 'fake_reasons', 'watch_match'
];
/* placeholders HighLevel fills from the calendar, not from the webhook */
const SYSTEM_FIELDS = ['appointment_time'];
const ANCHORS = ['booked', 'before_call', 'no_show', 'cancel'];
const TYPES = ['email', 'sms', 'task', 'wait', 'notify'];
const RECIPIENTS = ['owner', 'lead', 'none'];
const REQUIRED = ['id', 'type', 'channel', 'delay', 'to', 'subject', 'body', 'merge_fields', 'notes'];

let fails = 0, passes = 0;
function check(name, ok, detail) {
  if (ok) { passes++; return; }
  fails++;
  console.log('  FAIL ' + name + (detail ? ': ' + detail : ''));
}

function embeddedSequence(html) {
  const m = html.match(/<script type="application\/json" id="FOLLOWUP_SEQUENCE">([\s\S]*?)<\/script>/);
  if (!m) return null;
  try { return JSON.parse(m[1]); } catch (e) { return null; }
}

/* ---- load ---- */
let seq = null, seqFrom = '';
for (const [file, name] of [[SEQ_SRC, 'src/followup-sequence.json'], [SEQ_SHIP, 'highlevel/followup-sequence.json']]) {
  if (seq || !fs.existsSync(file)) continue;
  try { seq = JSON.parse(fs.readFileSync(file, 'utf8')); seqFrom = name; }
  catch (e) { console.log('  FAIL ' + name + ' is not valid JSON: ' + e.message); process.exit(1); }
}
if (!seq && fs.existsSync(MAP_HTML)) {
  seq = embeddedSequence(fs.readFileSync(MAP_HTML, 'utf8'));
  seqFrom = 'followup-map.html';
}
if (!seq) { console.log('  FAIL no follow-up sequence found (src/ or highlevel/followup-sequence.json, or followup-map.html)'); process.exit(1); }
if (!fs.existsSync(INSTALL)) { console.log('  FAIL highlevel/INSTALL.md not found'); process.exit(1); }
const guide = fs.readFileSync(INSTALL, 'utf8');
console.log('Follow-up map check (sequence from ' + seqFrom + ')');

/* ---- the webhook key list still matches what the engine sends ---- */
if (fs.existsSync(ENGINE)) {
  try {
    const EFK = createRequire(import.meta.url)(ENGINE);
    const live = Object.keys(EFK.payload({}, {}, {}, {})).sort();
    const want = WEBHOOK_KEYS.slice().sort();
    check('webhook key list matches engine.js payload()', JSON.stringify(live) === JSON.stringify(want),
      'engine sends ' + live.join(', '));
  } catch (e) { check('engine.js loads', false, e.message); }
}

/* ---- shape ---- */
const steps = Array.isArray(seq.steps) ? seq.steps : [];
check('sequence has steps', steps.length > 0);
check('sequence has a trigger', seq.trigger && seq.trigger.type === 'trigger');
const placeholders = seq.placeholders || {};
for (const [ph, def] of Object.entries(placeholders)) {
  if (def && def.system) check('placeholder ' + ph + ' is a calendar field the map knows', SYSTEM_FIELDS.includes(def.system), def.system);
  else check('placeholder ' + ph + ' fills from a webhook key', def && WEBHOOK_KEYS.includes(def.from), def && def.from);
}
const LINK_RE = /YOUR-BOOKING-LINK|YOUR-FUNNEL-LINK|https?:\/\//g;

const FOOTER_RE = /\n\{\{your business postal address\}\}\nNot interested\? Reply "unsubscribe" and we will stop emailing you\.$/;
check('the postal address is an owner fill the map shows', !!(seq.owner_fills && seq.owner_fills['{{your business postal address}}']));
const ids = new Set();
function checkSteps(list, label, booking) {
let lastDelay = -Infinity, lastAnchor = -1;
for (const s of list) {
  const at = label + ' step ' + (s && s.id ? s.id : '?');
  for (const k of REQUIRED) check(at + ' has key "' + k + '"', s && Object.prototype.hasOwnProperty.call(s, k));
  if (!s) continue;
  check(at + ' id is unique', !ids.has(s.id)); ids.add(s.id);
  check(at + ' type is one of ' + TYPES.join('|'), TYPES.includes(s.type), s.type);
  check(at + ' to is one of ' + RECIPIENTS.join('|'), RECIPIENTS.includes(s.to), s.to);
  check(at + ' delay is a number of minutes', typeof s.delay === 'number' && s.delay >= 0, String(s.delay));
  if (booking) {
    /* booking steps hang off a moment: booked, before the call (counting down), no show, cancel */
    const ai = ANCHORS.indexOf(s.anchor);
    check(at + ' anchor is one of ' + ANCHORS.join('|'), ai !== -1, s.anchor);
    check(at + ' anchors stay in order', ai >= lastAnchor, s.anchor);
    if (ai !== lastAnchor) lastDelay = s.anchor === 'before_call' ? Infinity : -Infinity;
    if (s.anchor === 'before_call') check(at + ' counts down to the call', s.delay <= lastDelay, s.delay + ' after ' + lastDelay);
    else check(at + ' delay does not go backwards', s.delay >= lastDelay, s.delay + ' after ' + lastDelay);
    lastAnchor = ai;
  } else {
    check(at + ' delay does not go backwards', s.delay >= lastDelay, s.delay + ' after ' + lastDelay);
  }
  if (typeof s.delay === 'number') lastDelay = s.delay;
  if (s.type === 'wait') check(at + ' wait has a duration', typeof s.duration === 'number' && s.duration > 0);
  if (s.type === 'email' || s.type === 'notify') check(at + ' has a subject', typeof s.subject === 'string' && s.subject.length > 0);
  if (s.type === 'email' || s.type === 'sms') check(at + ' has a body', typeof s.body === 'string' && s.body.length > 0);
  if (s.type === 'task') check(at + ' task has a name in subject', typeof s.subject === 'string' && s.subject.length > 0);

  const mf = Array.isArray(s.merge_fields) ? s.merge_fields : [];
  check(at + ' merge_fields is a list', Array.isArray(s.merge_fields));
  for (const f of mf) check(at + ' merge field "' + f + '" is a webhook key', WEBHOOK_KEYS.includes(f));

  /* every {{placeholder}} the step uses is known, and its webhook key is listed */
  const texts = [s.subject, s.body].concat(Array.isArray(s.preview_lines) ? s.preview_lines : []).filter((t) => typeof t === 'string');
  for (const t of texts) {
    for (const m of t.match(/\{\{[^}]+\}\}/g) || []) {
      /* an owner fill written as {{...}} (the postal address) is typed once by the owner */
      if (seq.owner_fills && seq.owner_fills[m]) continue;
      const def = placeholders[m];
      check(at + ' placeholder ' + m + ' is in the placeholders list', !!def);
      if (def && !def.system) check(at + ' lists merge field "' + def.from + '" (used by ' + m + ')', mf.includes(def.from));
    }
  }

  /* word for word in the guide, so the map never shows copy the install does not build */
  for (const k of ['subject', 'body', 'body_instruction']) {
    const v = s[k];
    if (typeof v !== 'string' || !v) continue;
    check(at + ' ' + k + ' is word for word in INSTALL.md', guide.includes(v),
      JSON.stringify(v.slice(0, 70)) + (v.length > 70 ? '...' : ''));
  }

  /* the follow-up house rules: one link at most, a STOP line on every text */
  if (s.to === 'lead') {
    const links = ((s.subject || '') + ' ' + (s.body || '')).match(LINK_RE) || [];
    check(at + ' has one link at most', links.length <= 1, links.join(', '));
    if (s.type === 'sms') check(at + ' SMS ends with the STOP line', /Reply STOP to opt out\.$/.test(s.body || ''));
    /* v1.2.1: every email to a lead carries the footer: postal address and an unsubscribe line */
    if (s.type === 'email') check(at + ' email ends with the postal address and the unsubscribe line', FOOTER_RE.test(s.body || ''));
  }
}
}
checkSteps(steps, 'lead', false);
check('the lead sequence says when it stops', typeof seq.stops_when === 'string' && /books/.test(seq.stops_when) && /replies/.test(seq.stops_when) && /opts out/.test(seq.stops_when));
check('the lead sequence has the day 1, 3, 7 and 14 follow-ups', [1440, 4320, 10080, 20160].every((d) => steps.some((s) => s.type === 'email' && s.to === 'lead' && s.delay === d)));
const bk = seq.booking;
check('there is a booking sequence', bk && bk.trigger && bk.trigger.type === 'trigger' && Array.isArray(bk.steps) && bk.steps.length > 0);
if (bk && Array.isArray(bk.steps)) {
  checkSteps(bk.steps, 'booking', true);
  check('the booking confirmation carries the funnel link with utm_source=booked', bk.steps.some((s) => s.anchor === 'booked' && /YOUR-FUNNEL-LINK\?utm_source=booked/.test(s.body || '')));
  for (const a of ANCHORS) check('the booking sequence has a ' + a + ' step', bk.steps.some((s) => s.anchor === a));
}
check('the stop rules say an opt-out ends every sequence and makes no task', Array.isArray(seq.stop_rules) && seq.stop_rules.some((r) => /STOP/.test(r) && /unsubscribe/.test(r) && /never create a task/.test(r)));
const hot = seq.hot;
check('there is a hot lead lane', hot && hot.trigger && hot.trigger.type === 'trigger' && Array.isArray(hot.steps) && hot.steps.length > 0);
if (hot && Array.isArray(hot.steps)) {
  checkSteps(hot.steps, 'hot', false);
  check('the hot lead lane sends the lead nothing', hot.steps.every((s) => s.to !== 'lead'));
  check('the hot lead lane ends first for an opt-out', (hot.trigger.behind_the_scenes || []).some((x) => /opt-out/.test(x) && /DND/.test(x)) && /opts out/.test(hot.stops_when || ''));
  check('the hot lead lane never counts an email open', (hot.trigger.behind_the_scenes || []).some((x) => /opens never/.test(x)));
}

/* ---- house rules on the sequence text ---- */
const raw = JSON.stringify(seq);
const allSteps = steps.concat(bk && Array.isArray(bk.steps) ? bk.steps : [], hot && Array.isArray(hot.steps) ? hot.steps : []);
check('no em dashes in the sequence', raw.indexOf('\u2014') === -1);
check('no "SmarterFlow" in the sequence', !/SmarterFlow/.test(raw));
for (const bad of ['guaranteed', 'final price', 'fixed price', 'this price is locked', 'lock in a real number', 'prices tend to creep up', 'a plain fact']) {
  const msgs = allSteps.filter((s) => s.to === 'lead').map((s) => (s.subject || '') + ' ' + (s.body || '')).join(' ').toLowerCase();
  check('lead messages never say "' + bad + '"', msgs.indexOf(bad) === -1);
}

/* ---- the built page carries the same sequence ---- */
if (seqFrom === 'src/followup-sequence.json' && fs.existsSync(SEQ_SHIP)) {
  check('highlevel/followup-sequence.json is current (rebuild it if not)', fs.readFileSync(SEQ_SHIP, 'utf8') === fs.readFileSync(SEQ_SRC, 'utf8'));
}
if (seqFrom !== 'followup-map.html' && fs.existsSync(MAP_HTML)) {
  const html = fs.readFileSync(MAP_HTML, 'utf8');
  const baked = embeddedSequence(html);
  check('followup-map.html has the sequence baked in', !!baked);
  if (baked) check('followup-map.html is current (rebuild it if not)', JSON.stringify(baked) === JSON.stringify(seq));
  check('followup-map.html loads nothing from the internet', !/<script[^>]+src=|<link[^>]+href="http/i.test(html));
  check('followup-map.html has no em dashes', html.indexOf('\u2014') === -1);
  check('followup-map.html draws the booking canvas', html.indexOf('id="canvas-booking"') !== -1);
  check('followup-map.html draws the hot lead canvas', html.indexOf('id="canvas-hot"') !== -1);
  check('followup-map.html says it is a preview, not your installed CRM', /not a readout of what is installed in your HighLevel/.test(html));
}

console.log((fails ? 'FAILED' : 'PASSED') + ': ' + passes + ' checks passed, ' + fails + ' failed');
process.exit(fails ? 1 : 0);
