# Selling an instant quote page to a local business

For HighLevel agency owners and freelancers: offering a client an instant estimate page, without overselling it.

## Who it fits

Local service businesses that already quote by phone or email and hear "how much?" before anything else: HVAC, plumbing, roofing, cleaning, landscaping, painting, detailing, pest control. Also agencies and consultants who price in hours.

It fits best when the owner can say "most jobs like that land between X and Y" without a site visit. If every job needs an inspection first, the range will be wide and the booking button does the heavy lifting.

It does not fit a business that refuses to show any number before a call. Do not talk them into it.

## Build it before you pitch it

The strongest pitch is the finished thing on their phone. About ten minutes:

1. Pick the closest preset in the Studio, or paste their public price list into your AI with `prompts/BUILDER-PROMPT.md`.
2. Put in their business name, their brand colour and, if they publish one, their booking link.
3. Leave every price you guessed marked as an example. Say so when you send it.
4. Put it online: host the file (see `highlevel/INSTALL.md`, Part 1), or use **Get my live link** if your Publish tab shows it.
5. Send the link and ask them to try it on their phone, as if they were a customer.

## A short cold email

> Subject: I built you something, {{first name}}
>
> Hi {{first name}},
>
> I made a quick instant estimate page for {{business}}. A customer picks the job, answers a few questions, and sees a price range and a booking button in about a minute.
>
> The numbers in it are my guesses from your website, so they are placeholders until you look. Try it on your phone: {{link}}
>
> If it is useful, I can set it up with your real prices and send every lead straight to you. If not, no problem.
>
> {{your name}}

## A short follow-up

> Hi {{first name}}, did you get a chance to try the estimate page? The one thing I would want to know is whether the ranges look close to what you actually charge. If they are off, tell me by how much and I will fix them.

## A 60-second script (in person or on a Loom)

"When someone looks at your website at night, they want one thing: roughly what will this cost. Right now they have to call or fill in a form and wait. This page answers that in about a minute. They pick the job, answer a few questions, and see a range. Not a quote, a range, and it says so. Then there is one button: book a time with you.

These numbers are my guesses. You give me your real ranges and I set them in. When a customer sends their estimate, you get the job, the range and every answer before you call them back.

Want to try it on your phone right now?"

## What to include in the offer

- **Setup.** Their services, their real ranges, their questions, their brand, their booking link. The owner approves every number before it goes live.
- **The lead notification.** Where each lead lands: their CRM through a webhook, or an email for each lead if they have no CRM. Send a test lead together and confirm it arrived.
- **A monthly calibrate habit.** Once a month, paste their recent finished jobs into the Studio's **Train** tab and accept the corrections that make sense. It keeps the numbers honest, and gives you a reason to talk every month.

## How to think about pricing it

This guide names no figures on purpose. Price the outcome and the upkeep, not the file. Ask yourself:

- How long setup really takes you, including the back and forth on their numbers.
- Whether you are also building the workflow, the follow-up email and the pipeline.
- Whether the monthly calibration is included, and how long it takes you.
- What their average job is worth to them. You are not promising more jobs, so never sell it on a number of leads or a return.

Offer setup on its own, and setup with the monthly habit. Let them choose.

## The honest lines to keep

- It shows a **range, not a fixed price**. The small print says it is an estimate, not a final quote.
- The **example numbers must be replaced** with the owner's real ones before anyone sees it. The Studio will not publish while any are left.
- **The business owner approves every number.** You set it up, they sign off.
- It promises no leads, bookings or revenue. It answers a question customers already have, faster.

## Before it goes live

Walk `PLAYBOOK.md` with the owner, then the test checklist in `highlevel/INSTALL.md` Part 5. Check the Studio's three sample estimates together and ask: would any of these numbers embarrass you in front of a customer? Fix them before launch, not after.

---

The licence lets you build funnels with this kit for any number of clients and charge for that work. It does not let you resell or give away the kit itself. See `LICENSE.txt`.
