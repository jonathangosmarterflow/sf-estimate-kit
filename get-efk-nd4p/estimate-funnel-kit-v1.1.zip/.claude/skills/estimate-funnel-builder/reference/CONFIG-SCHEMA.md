# CONFIG SCHEMA (Estimate Funnel Kit v1.2)

The one file the funnel reads. Written by you, edited by the Studio, read by `engine.js`.
Every key below must be present, even when empty.

## The shape

```json
{
  "kit_version": "1.2",
  "business": {
    "name": "Northlake Heating & Air",
    "niche": "hvac",
    "tagline": "Get a real price range in 60 seconds",
    "currency": "USD",
    "currency_symbol": "$",
    "unit": "price",
    "hourly_rate": null,
    "booking_url": "",
    "logo_url": "",
    "brand_color": "#1d4ed8",
    "phone": "",
    "service_area": ""
  },
  "services": [
    { "key": "ac_repair", "label": "AC repair", "lo": 150, "hi": 650,
      "days_lo": 1, "days_hi": 2, "help": "Most repairs are same or next day",
      "example_data": true }
  ],
  "allow_multiple_services": true,
  "questions": [
    { "key": "home_size", "label": "How big is your home?", "type": "single",
      "applies_to": ["ac_install"],
      "options": [
        { "label": "Under 1,500 sq ft", "effect": { "type": "multiply", "value": 0.9 } },
        { "label": "Over 2,500 sq ft", "effect": { "type": "multiply", "value": 1.25 } },
        { "label": "Not sure", "effect": { "type": "widen", "value": 0.10 } }
      ] }
  ],
  "knobs": {
    "range_width": 50, "price_level": 50, "safety_buffer": 30,
    "rush_premium": 50, "rounding": 60, "detail_shown": 50
  },
  "toggles": {
    "contact_before_result": false, "show_timeline": true, "show_drivers": true,
    "timeline_style": "about"
  },
  "calibration": { "per_service": {}, "last_trained": null, "rounds": 0 },
  "lead_capture": { "destination": "none", "webhook_url": "", "email_key": "", "alert_email_key": "", "fields": ["name", "email", "phone"], "consent_text": "By submitting you agree we may text or email you about this estimate. Reply STOP to end texts.", "watch_list": [] },
  "result_copy": {
    "headline": "Your estimated range",
    "disclaimer": "This is an estimate, not a final quote. Your exact price depends on the details, which we go through with you before any work starts.",
    "cta_label": "Book your free call"
  }
}
```

## Field rules

**business**
- `unit`: `"price"`, `"hours"` or `"both"`. With `"hours"` or `"both"`, every service `lo` and `hi` is HOURS, not money. With `"both"`, `hourly_rate` is a number and converts hours to money.
- `currency_symbol` matches `currency`. Unknown currency: use the code as the symbol.
- `booking_url` and `logo_url`: https only, or `""`. Never invent one, and never keep an example.com or other placeholder link (the doctor blanks those).
- `brand_color`: a hex colour. Default `#1d4ed8`.

**services**
- `key`: lowercase_snake, unique, stable. Never rename a key after training data exists against it.
- `lo` > 0, `lo` <= `hi`. Numbers, not strings, no currency symbols, no commas.
- `days_lo` / `days_hi`: whole days from booking to done. Timeline matters to a customer as much as price.
- `help`: one short sentence shown under the service.
- `example_data`: `true` on any number the owner did not personally give you. The Studio blocks publishing until every one of these is confirmed or edited.

**questions**
- `type`: `"single"` (one choice), `"multi"` (several), `"number"` (needs `min`, `max`, `step`, `per_unit_effect`).
- `applies_to`: list of service keys. Omit it or use `[]` for "applies to everything".
- `role`: put `"urgency"` on the rush question. Its `multiply` effects are then scaled by the RUSH PREMIUM knob.
- `effect.type`:
  - `multiply` : value 0.5 to 3.0. Size, difficulty, scope factors.
  - `add` : a flat amount in the config's unit. Call-out fees, permits, trip charges.
  - `widen` : value 0 to 0.5. Adds to the range half width. This is how "not sure" answers work.
  - `none` : value 0. The neutral option.
- Every option carries its own `effect`. The question never carries one.
- Give every `single` and `multi` question a "Not sure" option with a `widen` effect.

**knobs** (all 0 to 100)
- `range_width` 50 = the range exactly as entered. Lower is tighter, higher is wider.
- `price_level` 50 = neutral. 0 shifts both ends down 20%, 100 shifts them up 20%.
- `safety_buffer` 0 to 100 adds up to 30% of the midpoint to the high end only.
- `rush_premium` scales the urgency question's effects. 0 = no premium, 50 = as written, 100 = double the premium part.
- `rounding` 0 = exact, 1 to 33 = nearest 5, 34 to 66 = nearest 25, 67 to 100 = round numbers.
- `detail_shown` 0 to 33 = range only, 34 to 66 = plus what drives the price, 67 to 100 = plus per service lines.

**toggles**
- `contact_before_result`: `false` shows the number first, then asks for contact details. `false` is the default and it is the right default: the number is what earns the contact details.
- `show_timeline`: `true`. How fast you start is half the decision.
- `show_drivers`: `true`. Showing what moves the price is what makes the number believable.
- `timeline_style`: `"about"` (the default) shows one figure, "About 4 days", from the middle of the day range. `"range"` shows "2 to 6 days". A single figure reads real, a day range reads like a guess, so leave it on `"about"` unless the owner asks.

**calibration**: leave it as `{"per_service": {}, "last_trained": null, "rounds": 0}`. Only the Studio's Train tab writes here, or the engine's `applyTraining` in CHECK MY FUNNEL mode after the owner accepts a suggestion.

**lead_capture**: leave it exactly as shown. The owner picks where leads go on the Studio's Publish tab: `destination` is `"webhook"` (with `webhook_url`), `"email"` (with `email_key`, a Web3Forms access key) or `"none"`. With `"none"` the funnel shows the price and the booking button and never collects or sends contact details. `alert_email_key` is an optional second Web3Forms access key: when the CRM webhook send fails, the lead is emailed to the address that key was made for, with an ALERT line first. Only the owner sets it, on the Publish tab. `watch_list` is a list of names or email domains the owner typed (competitors, known time-wasters). Leave it `[]`: only the owner fills it, and a match only sets `watch_match` to true in the payload, the lead still sees the estimate.

**result_copy**: no guarantee wording. The disclaimer must say this is an estimate, not a final quote.

## Never

- Never invent a price, an hours figure, a URL, a phone number, an address or a claim.
- Never put a customer's name, address, phone or email anywhere in this file.
- Never write comments, trailing commas, smart quotes or single quotes into the JSON.
- Never rename a service key that has training data behind it.
