---
name: estimate-funnel-builder
description: Builds an instant estimate or quote funnel for any business from the Smarter Flow Estimate Funnel Kit. Interviews the owner, gathers context from files and their website, writes my-config.json, and builds a ready to open my-funnel.html. Use when the user says "build my estimate funnel", "build my quote funnel", "set up my instant quote page", "make my pricing calculator", "estimate funnel kit", "use the demo data", or asks to add a service, change their ranges or retune their estimate funnel. Also use it for a health check when they say "check my funnel", "is my funnel healthy" or "monthly check".
---

# Estimate Funnel Builder

You build a working instant estimate funnel for one business. The owner opens a single HTML file at the end and it works.

**You never do the pricing maths.** The kit's engine (`engine.js`) does every calculation. You fill in a small JSON config. If you find yourself computing a price, stop: that is the engine's job.

## IF YOU CANNOT READ OR WRITE FILES, SAY SO AND USE THE FALLBACK

Some versions of Claude have no access to the folder on the owner's computer. A chat app with no file access, a phone, a locked down workspace. If you cannot read the kit folder or cannot write into it, do not pretend, do not guess at what the files contain, and do not claim you wrote something you did not write. Say it in one line: "I cannot write files in this chat, so I will give you the settings and you paste them in. It takes about thirty seconds."

Then:

1. Run the interview exactly as below (Step 1 and Step 2). Everything except reading the folder still works.
2. Skip Step 0, Step 4 and Step 5. There is no `my-config.json` and no `my-funnel.html` for you to make.
3. Output **only the config JSON, in one code block**, with no commentary inside the block. The same hard rules in Step 3 still apply: never invent a price, never invent a URL, every option list gets a "Not sure" with a `widen` effect, no guarantee wording.
4. Hand it over with exactly these words, adjusted for their business name:

   - Open `studio.html` from your kit folder (double click it).
   - You land on tab 1, **Niche**. Scroll to the card headed **Or let your AI fill it in**.
   - Paste what I gave you into the box under **Paste your AI answer here**. Extra chat around it is fine, it finds the settings.
   - Press **Check it**. It tells you in plain words what it fixed.
   - Press **Accept and use these settings**.
   - Go to tab 6, **Publish**, and press **Download funnel.html**. That is your funnel.

The Studio runs the same checks the doctor runs, in the browser, with nothing to install. Nothing is lost by going this way.

## STEP 0. FIND THE KIT

Look for the kit folder: the unzipped folder that holds `studio.html`. It is usually the folder you were started in. If this skill was copied into `.claude/skills/`, the kit root is the folder that contains `.claude`. If the skill is still inside the kit, the root is three levels up from this file. Confirm it by finding these:

- `funnel.html` (the lead facing template)
- `studio.html` (the tuning tool)
- `presets/` (niche starting points)
- `engine.js` and `tools/doctor.mjs` (the engine and its checker)

If you cannot find them, ask the user for the path to the folder they unzipped. Everything you write goes in that same kit folder, next to `studio.html`. Never write outside it.

Say one line: "Found the kit at <path>. Building your funnel now."

## STEP 1. GATHER CONTEXT YOURSELF, BEFORE ASKING ANYTHING

Fewer questions is the whole point. In this order:

1. **Files the user points at.** Price lists, past quotes, invoices, a services doc, a CSV of jobs, a knowledge base export. Read them.
2. **Files already in the folder.** If the user says "use the demo data" or wants to try it before doing it for real, read `demo-data/northlake-price-sheet.md`, `demo-data/northlake-about.md` and `demo-data/northlake-past-jobs.csv`, then go straight to Step 3 with no questions. Say "Using the Northlake Heating and Air demo data" so nobody mistakes it for their own business.
3. **Their website**, if they give a URL and you have web access. Read the services and pricing pages. If you have no web access, say so in one line and ask them to paste their services page text.
4. **Project knowledge**, if this conversation has any attached.
5. **Connected email or drive: only with explicit permission, read only, and narrow.** Ask once, plainly: "I can look through your connected [email/drive] for past quotes to get your real numbers. Want me to? I will only read, I will not send or change anything." No answer or no means skip it and move on. Never read a connected mailbox or drive without a yes in this conversation. On a yes, open only the messages and files that look like quotes, invoices, estimates or price lists, and nothing else. Take the numbers and the service names, and never copy a customer's name, address, phone, email or any part of their message into the config, into a file, or into your reply.

Then say in 3 short lines what you found (services, prices or hours, how fast they start) and ask them to correct anything wrong.

## STEP 2. AT MOST 5 QUESTIONS, ONE AT A TIME

Skip every question the context already answered. Number them out loud ("Question 2 of 4"). Every question carries a default, and you tell them once: **type "ok" to take the default**.

1. **What kind of business is this?** Default: the closest preset in `presets/`, or `generic-service`.
2. **Business name and currency?** Default: leave the name blank, use USD.
3. **Your top 3 to 6 services, with a low and a high each.** Price or hours. Default: keep the preset's example numbers, marked as examples.
4. **What makes a job cost more?** Default: size and urgency.
5. **Booking link?** Default: leave it empty, they paste it into the Studio later.

Never ask a sixth question. If something is still missing, use the preset default and say which default you used.

## STEP 3. WRITE `my-config.json`

Write it in the kit folder. Start from the closest preset in `presets/` and overwrite what the owner told you. The full schema is in `reference/CONFIG-SCHEMA.md` next to this file. Read it before you write.

Hard rules, no exceptions:

- **Never invent a price or an hours figure.** No number from the owner means the preset number stays and that service keeps `"example_data": true`. When the owner's notes (or the demo price sheet) give a price range for a service, that service gets `"example_data": false`.
- **Never invent a URL.** Unknown booking link, logo or website is `""`. Never keep an example.com or other placeholder link: the doctor blanks those anyway.
- **Keep the business name** that is already in the preset or config unless the owner gives a different one.
- **No single answer multiplies a price by more than 1.3** unless the owner's notes justify it. Several big multipliers stacking on one job make a number nobody believes.
- **Never put a customer's name, address, phone or email in the config.** Not in a label, not in help text, not in an example.
- Service keys are lowercase_snake. `lo` > 0 and `lo` <= `hi` on every service.
- `multiply` effects stay between 0.5 and 3.0. `widen` effects stay between 0 and 0.5.
- Every list of options gets a "Not sure" choice with a `widen` effect. "Not sure" is a real answer and widening the range is the honest way to handle it.
- Every service is covered by at least one question.
- No guarantee wording anywhere. The disclaimer says this is an estimate, not a final quote.

## STEP 4. BUILD `my-funnel.html`

Copy `funnel.html` to `my-funnel.html` in the same folder, then replace the config block inside the copy. Exactly this, nothing else:

1. Open `my-funnel.html` and find the line containing `id="FUNNEL_CONFIG"`. It is a single tag of the form `<script type="application/json" id="FUNNEL_CONFIG">`.
2. Replace ONLY the text between that opening tag and its matching `</script>` with the full contents of `my-config.json`.
3. Do not touch the `<script>` tag itself, its attributes, the closing tag, or one byte of the rest of the file. No other edit. No reformatting. No "while I am here" improvements.
4. The replacement is raw JSON. No code fences, no `const config =`, no trailing comma, no comment.
5. If the file has no `id="FUNNEL_CONFIG"` block, stop and tell the user their `funnel.html` looks wrong or truncated. Do not invent a place to put the config.

Never edit `funnel.html` itself. It is the template for the next build.

## STEP 5. VALIDATE

Run the doctor from the kit folder:

```
node tools/doctor.mjs my-config.json
```

It prints `OK`, a list of repairs it would make, or errors. Fix every error and run it again. Report repairs to the user in plain words ("it rounded your multiplier down to 3.0, the maximum").

If `node` is not installed, or the command fails because the engine is missing, say so in one line and check the config yourself against `reference/CONFIG-SCHEMA.md`, item by item, then say "checked by hand, no node on this machine".

## STEP 6. HAND IT OVER

Exactly this, in this order, no extra steps:

1. **Open `my-funnel.html`** (double click it). Walk it as if you were a customer. That is your funnel.
2. **Then open `studio.html`** and load `my-config.json` to tune it. Start with RANGE WIDTH. Drag it and watch the three sample estimates move.
3. **Before you go live**, open the Studio's **Publish** tab. Pick **Where should leads go?**, send a test lead, and check the three sample estimates. Then read `PLAYBOOK.md`. It is short and it is the part most people skip.

Then stop. Do not offer to host it, deploy it, push it anywhere or connect it to anything.

## REVISE MODE

When they come back with a change, do not re-interview. Read `my-config.json`, apply the change, rewrite the file, rebuild `my-funnel.html` (Step 4 again on a fresh copy of `funnel.html`), run the doctor, and say in one line what changed.

- "Add a duct cleaning service, 300 to 600" -> a new service with a new lowercase_snake key, `example_data: false`, and a check that a question applies to it.
- "Make the ranges tighter" -> `knobs.range_width` down by 15 to 25. Wider is up. Never touch the service numbers for this.
- "Make it cheaper" or "more premium" -> `knobs.price_level`. "More padding on the high end" -> `knobs.safety_buffer`.
- "Switch me to hours" -> `business.unit` to `"hours"`, and confirm the service lo and hi are now hours, not money.
- "Remove X" -> drop the service and any question whose `applies_to` then lists nothing else.

## CHECK MY FUNNEL MODE

When they say "check my funnel", "is my funnel healthy" or "monthly check", run these five steps in order. Do not re-interview, and do not build anything new. Say "Checking your funnel: numbers, lead path, pricing, then one test lead." and go.

1. **The doctor.** From the kit folder run `node tools/doctor.mjs my-config.json` and report what it says in plain words: OK, what it repaired, what is still to do. If there is no `my-config.json`, first copy the config out of `my-funnel.html` (or the funnel file they downloaded from the Studio, ask which one is live) (the JSON between `<script type="application/json" id="FUNNEL_CONFIG">` and its `</script>`) into a new `my-config.json`, and say you did. No node means you check it by hand against `reference/CONFIG-SCHEMA.md` and say so.

2. **The lead path.** Read `lead_capture` from the config inside `my-funnel.html` (that file is what visitors use, so it wins over `my-config.json` if they differ, and you say that they differ). Tell them in one line each:
   - Where leads go: `destination` `webhook` (their CRM, name the host of `webhook_url`, never paste the whole link), `email` (the Web3Forms key is set, or not), or `none` (nobody receives leads).
   - With `webhook`: whether `alert_email_key` is set. If it is empty, recommend one: "If your CRM ever stops answering, leads are lost silently today. Add a backup email on the Studio's Publish tab, under Where should leads go? It takes two minutes and the lead then reaches your inbox with an ALERT line." You never invent or fill in a key yourself.
   - With `none`: say plainly that visitors see a price and the booking button and nobody receives their details.

3. **Pricing against real jobs.** Ask once: "Paste or point me at last month's invoices or job totals, with what you quoted for each job if you have it." If the job came from the funnel, the quote is the `estimate_low` and `estimate_high` on that contact in their CRM or lead email. Then:
   - Turn what they give you into clean rows by following the rules in `prompts/CALIBRATE-PROMPT.md` exactly (header `service_key,quoted_low,quoted_high,actual`, service keys from the config, no personal data, flag instead of guess). Show the flags.
   - Let the engine do the maths, never you. Pipe the rows in, never write them to a file:
     `printf '%s\n' "service_key,quoted_low,quoted_high,actual" "<row>" "<row>" | node -e "const E=require('./engine.js'),fs=require('fs');const c=E.doctor(fs.readFileSync('my-config.json','utf8')).config;const p=E.parseJobs(fs.readFileSync(0,'utf8'));console.log(JSON.stringify(E.train(c,p.jobs),null,2))"`
   - Report per service in one line: quotes ran high or low, by about how much, over how many jobs, and the engine's own `note`. Services it skipped (fewer than 3 jobs) are listed as "not enough jobs yet".
   - Propose each suggestion separately, with its `suggested_factor` and confidence. Change nothing until the owner accepts that one suggestion. For the ones they accept, and only those, apply them with the engine (one `{service, suggested_factor}` per accepted suggestion, copied from the training output):
     `node -e "const E=require('./engine.js'),fs=require('fs');const c=E.doctor(fs.readFileSync('my-config.json','utf8')).config;fs.writeFileSync('my-config.json',JSON.stringify(E.applyTraining(c,[{service:'duct_cleaning',suggested_factor:1.15}]),null,2)+'\n')"`
     Then rebuild `my-funnel.html` (Step 4 on a fresh copy of `funnel.html`) and run the doctor again. Rejected means untouched. No usable jobs means you say so and change nothing.

4. **One test lead.** Propose exactly one test lead and tell them what to confirm:
   - `webhook`: open `my-funnel.html` (or their live page), walk it with the name "Monthly Check" and their own email, then confirm in their CRM that a contact named Monthly Check arrived with a note holding the estimate (and the tag `estimate-funnel-lead` if they followed the HighLevel guide). If they use a backup email, also press **Send a test alert email** on the Publish tab and confirm the email starting with the ALERT line arrived (check spam).
   - `email`: walk it the same way and confirm an email for Monthly Check arrived in the inbox the key was made for, spam folder included.
   - `none`: skip the test and say why.
   Then remind them to delete the test contact so it does not count as a lead.

5. **A short plain report.** At most eight lines: doctor result, where leads go, backup email set or not, pricing per service (high, low, or on target), what they accepted and what changed, the test lead to run, and the one thing to do next. Then stop.

## PRIVACY

- Never send the owner's data anywhere. No API calls with their numbers, no uploads, no pasting their pricing into a web search.
- Never write a customer name, address, phone or email into the config, into `my-funnel.html`, or into any file you create.
- Past job data stays on their machine. If they paste invoices, use them and do not copy them into another file.
