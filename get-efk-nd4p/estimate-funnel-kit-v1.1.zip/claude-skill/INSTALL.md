# The Claude path (Mac and Windows, no commands)

You do not need this file to finish. The Studio (`studio.html`) gets you a working funnel with no AI at all. This is the optional speed-up where Claude reads your notes and fills in your prices for you.

---

## Way 1. Claude Code: open the folder, say one sentence

Nothing to install. The skill already ships inside the kit, in a hidden folder called `.claude/skills/estimate-funnel-builder/`. Claude Code finds it by itself whenever you open the kit folder. The steps are the same on a Mac and on Windows.

1. **Unzip the kit** if you have not already. On Windows: right click the zip, choose **Extract All**. On a Mac: double click the zip.
2. **Open the unzipped folder in Claude Code**, the folder with `studio.html` in it. Whichever Claude Code you use:
   - **The desktop app's Code tab:** choose the folder when it asks which folder to work in.
   - **VS Code with the Claude Code extension:** **File > Open Folder**, pick the folder, then open the Claude Code panel.
   - **The terminal:** start Claude Code the way you always do, from inside that folder.
3. Say: **build my estimate funnel**

DONE looks like: Claude says it found the kit, asks you for context, then asks a handful of questions. It writes `my-config.json` and `my-funnel.html` into the same folder. Open `my-funnel.html` and walk it as a customer.

To try it on the sample business first, say: **build my quote funnel, use the demo data**

On a Mac the `.claude` folder is hidden in Finder (press Cmd+Shift+. to see it). You never need to open it.

If your Claude cannot reach files at all, it will say so and hand you the settings as one block of JSON instead. That is the fallback and it gets you to the same funnel: open `studio.html`, stay on tab 1 **Niche**, paste the block under **Paste your AI answer here**, press **Check it**, then **Accept and use these settings**, and download your funnel from tab 6 **Publish**.

**Optional: use the skill in every folder, not just this one.** Copy it into your personal skills folder once. From inside the kit folder:

- Mac or Linux (Terminal):

  ```
  mkdir -p ~/.claude/skills
  cp -R ".claude/skills/estimate-funnel-builder" ~/.claude/skills/
  ```

- Windows (PowerShell):

  ```
  New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
  Copy-Item -Recurse -Force ".claude\skills\estimate-funnel-builder" "$HOME\.claude\skills\"
  ```

---

## Way 2. Claude on the web or in the desktop chat

A chat cannot write files onto your computer, so this path ends with settings you paste into the Studio. That takes about thirty seconds.

1. If your plan shows **Skills** under **Settings > Capabilities**, you can upload the skill: zip the `estimate-funnel-builder` folder from `claude-skill/` (right click, Compress on a Mac, Send to > Compressed folder on Windows), upload it and switch it on. If you do not see a Skills section, skip this step and paste `prompts/BUILDER-PROMPT.md` into the chat instead. Both work.
2. Start a new chat, attach your price list or any notes you have, and type: **build my estimate funnel**
3. When it gives you the settings, copy them, open `studio.html` from your kit folder, and on tab 1 **Niche** paste them under **Paste your AI answer here**. Press **Check it**, then **Accept and use these settings**. Download your funnel from tab 6 **Publish**.

Uploading the skill does not put any files on your computer. The chat's job is the settings. The Studio does the rest.

---

## Way 3. A Claude Project

Good if you want it available to a whole team without installing anything.

1. Create a new Project in Claude.
2. Paste the whole contents of `prompts/BUILDER-PROMPT.md` into the project's **instructions** box.
3. Add to the project's knowledge: the `presets/` files for the niches you care about, plus `PLAYBOOK.md`.
4. Start a chat in that project and say: **build my estimate funnel**
5. Paste the settings it gives you into `studio.html`, tab 1 **Niche**, under **Paste your AI answer here**.

---

## No AI at all

You do not need any of this. Open `studio.html`, pick your niche on tab 1, and type your own services and prices on tab 3. The AI only ever fills in the same form faster.

---

## Troubleshooting

- **"Claude does not react to build my estimate funnel."** Claude Code was opened on a different folder. Open the folder that has `studio.html` and the hidden `.claude` folder in it, then start a new session.
- **"It cannot find the kit."** Tell it the full path to the folder that contains `studio.html`.
- **"It wrote the config but not the funnel file."** Say: "now build my-funnel.html from funnel.html". Or paste the config into `studio.html` on tab 1 **Niche** and download the funnel from tab 6 **Publish**.
- **"The doctor command fails."** That is Node.js missing, and it is optional. The Studio runs the same checks in your browser with no install.
