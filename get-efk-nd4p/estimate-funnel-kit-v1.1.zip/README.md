# Estimate Funnel Kit v1.1

An instant estimate funnel for any business, in any niche, built in about ten minutes, with whatever AI you already use, or with no AI at all.

**Start here: open `START-HERE.html` in your browser.** Double click it. That is the whole install. On Windows, right click the zip and choose **Extract All** first.

**Fastest: open the Studio, pick your niche, see your funnel working in about a minute. No AI needed, nothing to install.** Works on Mac, Windows and Chromebook, in any modern browser.

---

## What this is

A customer lands on your page, answers a handful of questions, and sees a real price range and a realistic timeline straight away, then books a call. No "contact us for a quote", no waiting, no back and forth.

The maths is done by code that ships with the kit, in the customer's browser, offline, with no server and no account. The AI, if you use one, only fills in a small settings file: your services, your numbers, your questions. That is deliberate. It means the funnel works the same whether you used the smartest AI on the market or the cheapest one on your phone.

## One path, two optional speed-ups

| You | Do this |
|---|---|
| **Everyone** | Open `studio.html`, pick your niche, type your prices, publish from the last tab |
| Want Claude to do it | Open this folder in Claude Code and say "build my estimate funnel". The skill is already in the folder (`.claude/skills/`), nothing to install |
| Want any other AI to do it | Paste `prompts/BUILDER-PROMPT.md` into ChatGPT, Gemini, anything, then paste its answer into the Studio on tab 1 |

All of them end in the same place: your settings, and a single funnel file you can put anywhere.

## Where your leads go

On the Publish tab, under **Where should leads go?**, pick one: your CRM or automation tool (any webhook, HighLevel included), an email to you for each lead (no CRM needed, through the free Web3Forms service), or nowhere yet (visitors see their price and your booking button). Whichever you pick, send a test lead and confirm it arrived before you go live. The funnel only tells a visitor their details were sent when they really were.

## The files

```
START-HERE.html      start here
studio.html          THE MAIN TOOL. Niche, business, prices, knobs, train, publish.
funnel.html          the template your customers see. One file. Works offline.
engine.js            the pricing engine. Pure functions, no dependencies.
presets/             starting points per niche (hvac, plumbing, cleaning, agency...)
demo-data/           a fake HVAC business to try the whole thing on
prompts/
  BUILDER-PROMPT.md          paste into any AI to build your config
  CALIBRATE-PROMPT.md        turns messy past invoices into clean training rows
  REVIEW-MY-FUNNEL-PROMPT.md has an AI play three customers and report what is broken
claude-skill/
  INSTALL.md                 the Claude path, Mac and Windows, no commands
  estimate-funnel-builder/   the skill itself
.claude/skills/        the same skill, where Claude Code finds it by itself (hidden folder)
highlevel/INSTALL.md   host it, embed it, and catch the lead in HighLevel. 5 minute quick install first.
tools/doctor.mjs       optional command line check of your config (needs Node.js)
PLAYBOOK.md            12 lessons from running a live estimate funnel. Read it.
AGENCY-PITCH.md        for agencies and freelancers: offering an instant quote page to a client
CHANGELOG.md           what changed in each version, and the evidence behind it
NICHE-IDEAS.md         40 niches this works for, and what each funnel asks
LICENSE.txt            use it for your business and your clients' businesses
```

## The six knobs

Every one is a 0 to 100 number, and the Studio tells you in plain words what each number does to your estimate.

- **RANGE WIDTH** how far apart your low and high sit. The first one you should touch.
- **PRICE LEVEL** shifts the whole range up or down.
- **SAFETY BUFFER** padding, on the high end only, never on the low end.
- **RUSH PREMIUM** how much a hurry costs.
- **ROUNDING** exact numbers, or round ones.
- **DETAIL SHOWN** the range only, or the range plus what drives it, or a full breakdown.

## Train it on your real jobs

The Train tab takes your past jobs (service, what you quoted, what it actually came to) and tells you, per service, whether you run high or low. It never changes your prices on its own. You accept or reject each suggestion.

It needs at least 3 jobs for a service before it says anything, treats 3 or 4 as low confidence, never moves more than 15% in one round, and shows you outliers instead of quietly using them. Those four rules are there because we learned each one the hard way. The Playbook explains how.

## What this kit will never do

- Invent a price. Numbers you did not give it stay flagged as examples and block publishing.
- Invent a link. An unknown booking URL stays empty rather than plausible and wrong.
- Send your data anywhere you did not choose. Everything runs in your browser, on your machine. A lead only leaves the page when a visitor presses send, and only to the place you picked on the Publish tab.
- Put the word "guaranteed" in front of a customer. It is an estimate, not a quote.
- Need an account, a subscription, an API key or an internet connection to calculate.

## Requirements

A web browser. That is it.

Node.js is optional and only powers `tools/doctor.mjs`, which does the same checks the Studio already does in your browser.

## Stuck?

Reply to your receipt email and say where you got stuck. That feedback is how this kit gets better.

---

*Built by Smarter Flow. Licence in `LICENSE.txt`: use it for your own business and your clients' businesses, do not resell the kit itself.*
