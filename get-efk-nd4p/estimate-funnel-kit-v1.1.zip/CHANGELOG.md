# Changelog

Every change names the evidence behind it. Nothing here is a hunch.

## v1.2 (2026-10-02)

Thirteen lessons from a live estimate funnel, built in. Every earlier config and webhook key still works.

- **The follow-up map.** `followup-map.html` shows every email, text and task your lead gets, in order, with a sample lead's real numbers in it, or yours when you pick your own funnel file. Linked from the Publish tab ("See what sends when"), START-HERE, the README and the HighLevel guide. `tools/followup-map-check.mjs` proves the map and the guide say the same thing, word for word. Evidence: until now the only way to see the whole sequence was to build all of it.
- **1. A two week follow-up sequence (INSTALL 3.7).** Day 1 "did it land", day 3 what waiting does to a job, day 7 how the call and the visit work, day 14 close the file and ask what held them back. It stops when the lead books, replies or opts out. Evidence: the guide stopped two minutes after the estimate; on a live funnel, follow-up after day one is where bookings came from.
- **2. Booking messages (INSTALL 3.8).** A confirmation carrying your funnel link with `?utm_source=booked` as 2 minutes of call prep, reminders 24 hours and 1 hour before, two missed call messages, a cancel message with one question, and the habit of marking no-shows right away. The map shows them as a second canvas. Evidence: learned on a live estimate funnel, where the booked call is the step that decides the job.
- **3. Hot leads (INSTALL 3.6).** A reply, a second open of the estimate email, or a price question tags the lead hot, makes a task due in 1 hour, notifies you and moves the opportunity to Hot. Evidence: learned on a live estimate funnel: an alert is not a queue.
- **4. Opt-out tests (Part 5).** Reply STOP to the SMS and "unsubscribe" to an email, and check the workflow exits. Evidence: an opt-out that does not stop the sequence is a complaint waiting to happen, and the guide never tested it.
- **5. Sending domain and one call name (Part 5).** SPF, DKIM and DMARC verified before the first real lead, and one name for the call on the page, the button, the calendar and every email. Evidence: learned on a live estimate funnel; both were missing from the test list.
- **6. Possibly fake leads.** Every lead now carries `possibly_fake` and `fake_reasons` (test names, 555-01xx and patterned phone numbers, example.com and .test emails). The estimate still shows and still sends; the guide's If/Else only skips the call task. Evidence: learned on a live estimate funnel, where test and made up leads reach the call list too.
- **7. "About 4 days".** New `toggles.timeline_style`: `"about"` (the new default) shows one figure, `"range"` keeps "2 to 6 days". The result card, `timeline_text` and the map all follow it. Evidence: learned on a live estimate funnel: a single figure reads real, a day range reads like a guess.
- **8. A calibration nudge.** The Publish tab says so when your prices have never been checked against real jobs, or not in 90 days, and points you at "check my funnel" or the Train tab. Evidence: the calibrate habit depended on the owner remembering it.
- **9. Believe the first round.** One line in the Playbook: if your first round of real jobs says go lower, believe it; first estimates almost always run high. Evidence: learned on a live estimate funnel.
- **10. A watch list.** Type names or email domains on the Publish tab and a match arrives with `watch_match` true. The visitor still sees the estimate. The published funnel holds only a scrambled copy of the list. Evidence: learned on a live estimate funnel: competitors and known time-wasters shop your prices.
- **11. A weekly speed to lead count (INSTALL 3.5).** Once a week, count the "Call this estimate lead" tasks that went overdue. Evidence: learned on a live estimate funnel: the overdue count is the simplest honest measure of speed to lead.
- **12. Test with a +test email.** Part 5 and the Playbook's launch loop use `name+test@yourdomain.com`, and say to delete test contacts before counting anything. Evidence: learned on a live estimate funnel, where test leads end up in the first week's numbers.
- **13. Call prep link.** The funnel already passes `utm_source` through to the lead, so `?utm_source=booked` marks answers given after booking. Verified in v1.2, no change needed. Evidence: the booking confirmation in item 2 depends on it.

## v1.1.2 (2026-10-02)

- **A failed CRM send now reaches you anyway.** On the Publish tab, under your CRM choice, add a backup email (a free Web3Forms key). If the CRM send fails or does not answer in 15 seconds, the funnel emails you the full lead with "ALERT: your CRM webhook failed, this lead was emailed instead. Check your funnel settings." as the first line, and the visitor is told it was sent only when that email really went through. **Send a test alert email** shows you one. Evidence: in v1.1 a failed CRM send told the visitor and nobody else, so the owner lost the lead without knowing.
- **"Check my funnel" in the Claude skill.** Once a month say it to Claude: it runs the doctor, reports where your leads go and whether a backup email is set, checks your pricing against last month's jobs with the Train tab's own maths, changes nothing until you accept each fix, and ends with one test lead to send. Evidence: the calibrate habit in the Playbook depended on the owner remembering every step of it alone.

## v1.1.1 (2026-10-02)

- **Follow-up emails show the range the way the result card does.** Every lead now also carries `estimate_low_text` and `estimate_high_text` (for example `$4,500` and `$9,500`, with your currency symbol), and the HighLevel email, SMS and Ask AI prompt use them, so a lead reads "$4,500 to $9,500" instead of "4500 to 9500". Every earlier key is unchanged. Evidence: the v1.1 payload sent only bare numbers, so the guide's own email copy produced "4500 to 9500".
- **"Use it in the field"** in the README and the Playbook: the same funnel works on a phone during a service visit, with field quotes landing where website leads do. Evidence: the funnel is one file plus a live link and works offline, which the kit docs did not say yet.

## v1.1 (2026-09-30)

**Your leads can no longer disappear quietly**

- **"Where should leads go?" on the Publish tab**, with three plain choices: your CRM or automation tool (any webhook), an email to you for each lead with no CRM needed, or nowhere yet. Evidence: two outside AI red teams (Gemini and OpenAI, 2026-09-30) both found that a buyer without HighLevel had nowhere for leads to go.
- **The funnel only says "sent" when it was sent.** With nowhere chosen, visitors see their price and your booking button, and no contact form. If a send fails, the visitor still sees their price and is never told it went through. Evidence: the same two red teams, 2026-09-30, and our own recording check on 2026-09-19, where a v1.0 preview said "Sent" while nothing had been sent.
- **"Did the test lead arrive?"** A test submission no longer turns the checklist green by itself. You confirm it landed, or get the three most likely reasons it did not. Evidence: two outside AI red teams, 2026-09-30 (a browser can report success for a request that arrives nowhere).
- **Email me each lead** uses Web3Forms, a free form to email service. Facts checked on 2026-09-30: works from a file on your computer and inside an embed, 250 leads a month on the free plan, lead details pass through their service. The Publish tab says all of this where you choose it.

**Easier to install and to connect**

- **Get my live link.** On the Publish tab: one button gives you a working link, a QR code and an embed snippet, with nothing to host. Your settings travel inside the link itself. We do not keep them, and anyone with the link can read them. Evidence: two outside AI red teams (Gemini and OpenAI, 2026-09-30) both named "the buyer ends with a file they must host" as the first wall.
- **HighLevel quick install: about 5 minutes, zero custom fields.** Every lead now carries `summary_text`, one readable block with the service, the range, the timeline and every answer, which becomes a note on the contact. The full field by field install is still there when you want it. Evidence: the v1.0 guide needed 11 custom fields before the first lead showed up.
- **Claude Code needs no install.** The skill now also ships in the hidden `.claude/skills/` folder, so opening the kit folder in Claude Code is enough, the same on Mac and Windows. Evidence: the v1.0 guide had terminal commands for a Mac and none for Windows.
- **A friendly stop sign when the kit is still inside the zip.** Windows opens files from inside a zip in a temporary folder where nothing next to them works. Evidence: that is how Windows File Explorer opens a file inside a zip, and v1.0 had no warning for it.
- **START-HERE leads with one path**: open the Studio, pick your niche, see it working. AI is an optional speed-up. Evidence: the v1.0 start page offered three equal paths and listed the fastest one, no AI at all, last.

**Better numbers before anyone sees them**

- **Three sample estimates on the Publish tab**, with one tick: would any of these embarrass you in front of a customer? Evidence: v1.0 asked you to walk your funnel three times in a note on the start page, which is easy to skip.
- **Placeholder links are removed.** A booking, logo or webhook link on example.com (or a similar placeholder) is now left empty and flagged, instead of shipping a button that goes nowhere. Evidence: tested on GPT and Gemini models, 2026-09-30, one model kept the example booking link.
- **The builder prompt is stricter** about four things: no kept placeholder link, owner-given price ranges count as real numbers, the business name stays unless you change it, and no single answer multiplies a price by more than 1.3 without a reason. Evidence: tested on GPT and Gemini models, 2026-09-30.
- **Plainer wording in the HVAC preset and every preset's small print**: "How easy is it to get to your AC or furnace?" and a disclaimer that no longer sounds like a promise. Evidence: an AI customer panel review of the HVAC funnel, 2026-09-24.
- **The review prompt now explains how the engine adds up several services**, so a reviewing AI stops reporting that as a bug. Evidence: the same review, 2026-09-24, where it was the top false alarm.

**New files**

- `AGENCY-PITCH.md`: for agencies and freelancers selling an instant quote page to a local business.
- `CHANGELOG.md`: this file.
- "Show me what you built" on the Publish tab, once your checklist is complete. Nothing is sent unless you press the button. Evidence: v1.0 had no way to tell us what you built except replying to the receipt email.

## v1.0 (2026-09-19)

First release.
