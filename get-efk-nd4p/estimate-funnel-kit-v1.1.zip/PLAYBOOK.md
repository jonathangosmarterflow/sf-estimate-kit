# 12 lessons from running a live estimate funnel

We built an instant estimate funnel for our own business before we packaged this kit. It sends real numbers to real strangers. Everything below is something we got wrong first, in public, and then fixed. Each lesson is three lines: what we did wrong, what we do now, and where it is already built into this kit so you do not have to remember it.

Read this once before you go live. It is the part everyone skips and it is the part that is worth more than the software.

---

## 1. A single number is a promise. A range is an estimate.

**The mistake.** Our first instinct was to show one clean number, because one number feels confident. It is a trap. A single number gets read as a quote. Then the job turns out to be bigger, you go back with a higher figure, and you have already lost the customer's trust before you started.

**What we do now.** Every estimate is a range, always, with the words "this is an estimate, not a final quote" right next to it. The range is not a hedge, it is the honest answer. The job genuinely costs somewhere between those two numbers until somebody looks at it properly.

**In the kit.** The engine only ever produces a range. There is no single-number mode. The disclaimer line is in the config and the funnel will not render without it, and the prompts refuse to write guarantee wording into it.

---

## 2. A range that is too tight is worse than no range at all.

**The mistake.** We tightened our ranges to look precise. Precision that is wrong is just a lie with more decimal places. We ended up in conversations where the real price was outside the range we had already put in writing, and the whole call became a negotiation about our credibility instead of about the work.

**What we do now.** Wide first, then tighten with evidence. A range wide enough to be right is worth more than a range narrow enough to be impressive. We would rather a customer says "that's a big range" and asks a question than "you said X" and walks.

**In the kit.** RANGE WIDTH is the first knob, and it is the one you should touch before any other. It is a 0 to 100 number so you can feel it, and the label tells you exactly what the number does to your low and high. Start wide. Earn your way tighter.

---

## 3. The low end is the anchor, and it decides whether they keep reading.

**The mistake.** We padded both ends of the range to protect ourselves. That pushes the low end up, and the low end is the number the customer's eye lands on first. We were scaring off people who could easily have afforded the job.

**What we do now.** Protection goes on the high end, never the low end. The low end stays honest and low enough to be inviting, because its job is to keep them on the page.

**In the kit.** SAFETY BUFFER only ever moves the high end. That is deliberate and it is not adjustable, because every time we let ourselves pad the low end "just a little", bookings dropped.

---

## 4. "Not sure" is the most common real answer, and most forms have no room for it.

**The mistake.** We wrote questions where every option assumed the customer knew something about their own job. How old is the system. How many square feet. What kind of unit. Half of them genuinely do not know, so they guessed, and a guess in means a wrong number out.

**What we do now.** Every question has a "Not sure" option, and picking it does not block anything. It widens the range. That is exactly what a real expert does when you cannot tell them something: the price gets less certain, not unavailable.

**In the kit.** `widen` is a first-class effect type alongside multiply and add. Both AI prompts are told to put a "Not sure" option with a widen effect on every question they write, and the funnel review prompt flags any question that is missing one. Widening opens the range both ways, so the low end drops and the high end rises. That is not a contradiction of lesson 3: the padding that protects you still only ever lives on the high end, and nothing here ever pushes the low end up.

---

## 5. Your estimates will run high, and you will not notice for months.

**The mistake.** Our AI-generated estimates ran meaningfully higher than what the work actually turned out to cost. Every individual estimate looked reasonable. Nobody compared them to reality, so the drift compounded quietly for weeks. The first real signal was leads going cold after the number arrived.

**What we do now.** Every finished job goes back into the engine as a data point: what we quoted, what it actually was. The comparison is the whole loop. An estimate engine that never sees the actuals is just a price list with extra steps.

**In the kit.** The Train tab. Paste in your past jobs (service, quoted, actual) and it shows you, per service, whether you run high or low and by how much. It never changes anything on its own. You accept each suggestion one at a time.

---

## 6. Never let the calibration take a big swing.

**The mistake.** Our first correction logic moved fast on thin data. Three jobs on an unusual service, and it yanked a whole category of pricing. Then the next three pulled it back the other way. Nobody trusts an engine that oscillates, and we spent more time undoing corrections than making them.

**What we do now.** Median, not average, so one weird invoice cannot drag it. At least 3 jobs before anything is suggested for a service, and 3 or 4 is labelled low confidence. Never more than a 15% move in one round. Outliers get listed for you to look at, not silently used.

**In the kit.** All four rules are in the Train tab's maths and they are not adjustable. The outliers are shown to you by name so you can decide whether that job was a fluke or a pattern.

---

## 7. Timeline is half the decision, and we left it out.

**The mistake.** We obsessed over the price and shipped a result screen with no timeline on it. Then people asked "ok, but when could you start?" and everything stalled for a day. For plenty of customers, "next week" versus "in a month" decides it before the price does.

**What we do now.** Every result shows a timeline alongside the range. Honest, wide, and never shortened by urgency. Being in a hurry is not the same as us being available.

**In the kit.** Every service carries `days_lo` and `days_hi`, the result shows a timeline by default, and the engine will not let an urgency answer shorten it. Urgency can cost more. It cannot bend physics.

---

## 8. Example numbers ship. Placeholders ship. Assume they will.

**The mistake.** We have shipped a live page with a placeholder link in it that a real person could have clicked. We have had example testimonials sitting on a page for weeks. The pattern is always the same: something is put in as a temporary stand-in, everyone knows it is temporary, and then it goes live because nobody owned removing it.

**What we do now.** A placeholder has to physically block the thing it is standing in for. Not a note, not a reminder, a block.

**In the kit.** Every preset number is flagged `example_data: true`, and the Studio will not let you publish until you have confirmed or edited every single one. The AI prompts are forbidden from inventing a price or a URL: no answer means the field stays empty rather than plausible and wrong. The booking link has a "test this link" button next to it, because an AI-invented URL that looks right is the failure that hides longest.

---

## 9. One link. Everywhere. Every time.

**The mistake.** Our follow-up emails had a booking link, a website link, a case study link and a reply prompt. Every extra link is another decision, and more links also hurt whether the email lands in the inbox at all.

**What we do now.** One call to action per message, and it is always the same one: book the call. The call is where the estimate becomes a real number, so every path leads there. If something else genuinely needs saying, it is a separate message on a separate day.

**In the kit.** The result screen has exactly one CTA button. The HighLevel follow-up email and SMS copy in `highlevel/INSTALL.md` each carry exactly one link, and the Ask AI prompt explicitly tells HighLevel's builder not to add a second one.

---

## 10. Speed to lead cannot depend on a human, or on a computer being awake.

**The mistake.** Our first version generated the estimate on a machine that was not always on. Leads arriving outside our working hours waited. We had promised "in minutes" and were quietly delivering "by morning". The promise was broken by an implementation detail nobody had thought about.

**What we do now.** The instant part is instant because nothing living is in the path. The estimate appears on the page. The confirmation email fires from the platform. A human task is created too, but it is a second layer, not the first one.

**In the kit.** The estimate is calculated in the browser, in front of the customer, with no server call. It works offline, from a file, on a plane. The follow-up email and SMS in the HighLevel workflow are sent by the platform, and the "call this lead" task sits behind them as the human layer.

---

## 11. Three people should walk your funnel before one stranger does.

**The mistake.** We tested the happy path. Then we went live and found out that the booking confirmation was going to a calendar with the wrong name on it, that one path had a question with no honest answer, and that the whole thing looked broken on a phone in one particular browser. All of it was findable in ten minutes by someone who was not us.

**What we do now.** Before launch, three different people walk it end to end as three different customers: the small easy job, the big unsure job, and the annoyed price shopper. Every problem goes on a list and the list gets cleared before traffic, not after.

**In the kit.** `prompts/REVIEW-MY-FUNNEL-PROMPT.md` makes any AI play all three customers against your config and report confusing questions, prices that look wrong, dead ends and trust problems. It takes two minutes and it is not a substitute for a human, it is what you do at midnight when no human is awake. The launch-week loop below is the human half.

---

## 12. Do not read your numbers across a change you forgot you made.

**The mistake.** We changed copy, changed the range width and changed the follow-up timing in the same week, then tried to work out why bookings moved. There was no way to know. We had destroyed our own ability to learn anything from that month.

**What we do now.** One change at a time, dated, written down. At low volume (and every business starts at low volume) you cannot run a proper split test, so you run sequential blocks: change one thing, leave it alone for at least 10 leads, then judge it on one metric. Calls booked, not clicks.

**In the kit.** The Studio stamps the config version and your knob settings into every webhook payload, in `knobs_text`. So every lead in your CRM carries the settings that produced its estimate. When you want to know whether tightening the range helped, the answer is already sitting in your contact records.

---

# One more thing worth knowing

In some places an automated price range is treated as more than a conversation starter, and the rules differ by country, by state and by trade. That is why "this is an estimate, not a final quote" sits in the config and the funnel will not render without it. Leave that line where it is, and spend ten minutes checking what your own local rules say about quoting before you send real traffic at it.

---

# The launch-week loop (do this once, in your first week)

Not a checklist you tick and forget. A loop you run for five days.

**Day 1. Walk it yourself, three times.** Once as the small easy job. Once picking "not sure" on every question. Once as the biggest, most urgent job you would actually take. Three numbers come out. Would you be happy to see any of them quoted back at you by a customer? If not, that is your first knob adjustment.

**Day 2. Get two other people to walk it.** Not employees who want to be helpful. People who will tell you it is confusing. Sit behind them and say nothing, especially when they hesitate. Every hesitation is a question that needs rewording. Write down every single thing they ask you out loud, because a stranger will not be able to ask.

**Day 3. Run the AI review.** Paste your config into `prompts/REVIEW-MY-FUNNEL-PROMPT.md` in any AI chat. Fix the confusing questions it finds and the dead ends. Ignore the suggestions you disagree with, it does not know your trade.

**Day 4. Test the whole chain, not just the funnel.** Submit as a customer, from a phone, on mobile data. Did the contact land in your CRM with every field filled? Did the email arrive, and did it land in the inbox rather than spam or promotions? Did the SMS arrive? Does the booking link open the right calendar? Book a slot from it and check the confirmation. This is where things are broken, more often than in the funnel itself.

**Day 5. Ten real leads, then hands off the knobs.** Send real traffic. Then leave it alone. Resist retuning after three leads, because three leads tell you nothing and you will be tuning to noise. Look at the first ten, then adjust once.

**Then delete your test contacts,** or your first month of numbers is mostly you.

---

# The calibrate habit (fifteen minutes)

Monthly if you are busy, quarterly at minimum. Put it in your calendar so it happens without you deciding to do it. Fifteen minutes is the difference between an estimate engine and a decorative one.

1. **Pull the finished jobs since you last did this.** What you quoted, what it actually came to. Paste the mess into `prompts/CALIBRATE-PROMPT.md` in any AI chat and it gives you clean rows.
2. **Paste the rows into the Studio's Train tab.** Read what it tells you per service. Accept the suggestions you believe. Reject the ones based on one strange job.
3. **Look at the flagged rows.** The jobs the AI could not map, and the ones that came in far outside their range. That is where you learn something. A service that is always wrong in the same direction is a pricing problem, not a calibration problem.
4. **Change one thing.** One knob, or one service's numbers. Not five. Write down what you changed and the date.
5. **Check one number:** of the people who got an estimate since last time, how many booked? That is the only metric that matters. Everything else is decoration.

A round where nothing needed changing is a good round. Do not invent a change to justify the fifteen minutes.

---

# Check my funnel (the calibrate habit, done with Claude)

Once a month say "check my funnel" to Claude and it checks the numbers, the lead path and your pricing against real jobs, and proposes fixes you accept or reject. It runs the doctor on your settings, tells you where your leads go and whether a backup email is set. It asks for last month's invoices or job totals and tells you, per service, whether your quotes ran high or low, with the Train tab's own rules doing the maths. Nothing changes until you accept each suggestion, one at a time. It ends with one test lead and exactly what to look for in your CRM or inbox.

---

# Use it in the field

Your funnel is one file, plus a live link if you made one on the Publish tab, so it does not have to live on your website. A technician or salesperson can open it on a phone during a service visit and quote from the same numbers your website uses. Set **Where should leads go?** on the Publish tab to your CRM or to email, so a quote given in the field lands in the same place as one from the website. The estimate is worked out on the device itself, so it works offline from the file. Sending the lead needs a connection, and the funnel only says "sent" when it really was.

---

# The one thing after this

An instant estimate answers "what will this cost me". The very next question every customer has is "and what do I actually get". That is the next thing we will show you how to build: an instant demo of the finished system, generated for that specific customer, right after their estimate. Same idea, same deterministic brains on our side, same "works with whatever AI you use" approach. It is the next video.

---

*Built by Smarter Flow. Use this kit for your own business and for your clients' businesses. See `LICENSE.txt`.*
