# Put your estimate funnel inside HighLevel

Zero assumed knowledge. Five parts, in order. Part 1 puts your funnel file on the internet. Part 2 puts it on a HighLevel page. Part 3 catches the lead: a 5 minute QUICK INSTALL first, then the optional FULL INSTALL. Part 4 is a shortcut that builds Part 3 for you. Part 5 is the test you do before you send anyone real.

You need one file to start: **`my-funnel.html`**, the file the Studio's Publish tab downloaded for you. It is one single file. Everything is inside it. No folder, no images, no other files.

HighLevel renames menu items from time to time. Where a name may have moved, this guide says "or similar". Look for the closest match.

---

# PART 1. Put `my-funnel.html` on the internet

Pick ONE of these four. Option A is the fastest if you have never done this before.

## Option A. A drag and drop static host (about 2 minutes)

Several well known services let you drag a folder onto a web page and give you back a live link, free tier included, no account setup beyond an email. Netlify Drop, Cloudflare Pages and Vercel all work this way. We are not promising any particular pricing, limit or free tier, they change: open the one you pick and read its own page.

The steps are the same whichever you pick:

1. On your computer, make a new folder called `funnel`.
2. Put `my-funnel.html` inside it and **rename the file to `index.html`**. This matters. `index.html` is the name a web host serves by default.
3. Open the host's drop page in your browser and sign in or sign up.
4. **Drag the whole `funnel` folder** onto the drop area. Not the file, the folder.
5. Wait for it to finish and copy the link it gives you. It looks like `https://something-random.netlify.app`.
6. **Open that link in a new tab and walk your funnel as if you were a customer.** If you see your funnel, Part 1 is done.

Keep that link. You will paste it in Part 2.

## Option B. GitHub Pages (free, permanent, about 5 minutes)

1. Create a free account at github.com.
2. Click **+** at the top right, then **New repository**. Name it `my-funnel`. Choose **Public**. Click **Create repository**.
3. On the next screen click **uploading an existing file**.
4. Drag `my-funnel.html` in, **renamed to `index.html`** first.
5. Click **Commit changes**.
6. Click **Settings** (top of the repository), then **Pages** in the left sidebar.
7. Under **Branch**, pick `main`, leave the folder as `/ (root)`, click **Save**.
8. Wait about a minute, refresh the page, and copy the link it shows at the top.

## Option C. Your own website

If you already have a website with any kind of file manager or FTP access:

1. Upload `my-funnel.html` into your site's public folder, for example into a new folder called `estimate`.
2. Your link is then `https://yoursite.com/estimate/my-funnel.html`.
3. Open it in a browser and check it loads.

## Option D. Paste the code straight into a HighLevel page (no hosting at all)

This works and it is the only option with nothing to sign up for, but it is the fiddliest. Use it if the others failed.

1. In HighLevel, go to **Sites** (or **Funnels & Websites**, or similar), open the funnel or website page you want.
2. Add an element: **Custom JS/HTML** (it may be called **Custom Code**, or similar). Drag it onto the page.
3. Click the element, then **Open Code Editor**.
4. Open `my-funnel.html` in a plain text editor (TextEdit on a Mac, set to plain text; Notepad on Windows). Select all, copy.
5. Paste it into the code editor. Save. Save the page. **Publish** the page.

**The gotchas, all four of which have bitten us:**

- The page editor can strip or mangle parts of a full HTML document (the `<html>`, `<head>` and `<body>` tags). If your funnel looks broken after pasting, that is why. Go back to Option A.
- HighLevel's own page styles can leak into your funnel and change your fonts, button shapes and spacing. The iframe in Part 2 is immune to this. A pasted block is not.
- Every time you change your config you have to redo this paste. With Options A to C you replace one file and every page updates at once.
- The page builder's autosave sometimes reformats pasted code. Always re-open the page after publishing and check the funnel still works.

---

# PART 2. Embed it on a HighLevel page

Skip this if you used Option D above. Your funnel is already on the page.

The Studio's **Publish** tab generates this snippet with your link already in it. Here it is anyway, so you can see what it does. Replace `YOUR-FUNNEL-URL` with the link from Part 1.

**📋 COPY THIS, you will paste it into a HighLevel Custom JS/HTML element at step 3 below:**

```html
<div id="efk-wrap" style="max-width:720px;margin:0 auto;">
  <iframe
    id="efk-frame"
    src="YOUR-FUNNEL-URL"
    title="Instant estimate"
    style="width:100%;border:0;display:block;min-height:640px;"
    loading="lazy"
    scrolling="no"></iframe>
</div>
<script>
(function () {
  var f = document.getElementById('efk-frame');
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.efk !== 'height') return;
    if (f.contentWindow && e.source !== f.contentWindow) return;
    var h = parseInt(d.value, 10);
    if (h > 200 && h < 20000) f.style.height = h + 'px';
  });
  // ask once in case the funnel loaded before this script did
  f.addEventListener('load', function () {
    try { f.contentWindow.postMessage({ efk: 'height?' }, '*'); } catch (err) {}
  });
})();
</script>
```

Steps:

1. In HighLevel, open **Sites** (or **Funnels & Websites**, or similar) and open the page where the funnel should live.
2. Drag in a **Custom JS/HTML** element (or **Custom Code**, or similar) where you want the funnel to appear.
3. Click it, choose **Open Code Editor**, and paste the block above.
4. Replace `YOUR-FUNNEL-URL` with your real link. Keep the quotes around it.
5. Save the element, save the page, click **Publish**.
6. Open the live page **on your phone** and walk the funnel. The frame should grow and shrink as you move through the questions, with no scrollbar inside it.

**If the frame stays 640px tall and gets its own scrollbar:** the auto-height message is not arriving. The funnel still works, it just does not resize. Raise `min-height` to `900px` and move on. Do not let this block your launch.

---

# PART 3. Catch the lead (the workflow)

Your funnel sends one webhook when someone submits. This part receives it. Do the QUICK INSTALL first. It gets every lead into HighLevel today with nothing to map but a name, an email and a phone. Do the FULL INSTALL later, only if you want each answer in its own field.

## QUICK INSTALL (about 5 minutes, zero custom fields)

Every lead carries `summary_text`: one readable block with your business, the service or services, the estimate from low to high with the currency, the timeline, and every question with its answer. You drop that block into a note on the contact and you are done.

1. Go to **Automation > Workflows**, click **+ Create Workflow**, choose **Start from Scratch**. Name it **Estimate Funnel Lead**.
2. Click **Add New Trigger**, choose **Inbound Webhook**. Copy the **Webhook URL** it shows you. **Keep this tab open.**
3. In another tab open your **Studio**, go to the **Publish** tab. Under **Where should leads go?** pick **My CRM or automation tool**, paste the webhook URL, and press **Send a test lead**.
4. Back in HighLevel, click **Fetch Sample Request** (or similar) on the trigger. You should see a sample named **Test Submission** with all the keys listed further down. Save the trigger.
5. Click **+** and add **Create/Update Contact** (it may be called **Update Contact**, or similar). Map First Name and Last Name from `name`, Email from `email`, Phone from `phone`. Pick each one from the dropdown, never type it.
6. Add **Add Note** (it may be called **Add Contact Note**, or similar). For the note body, pick `summary_text` from the webhook fields in the dropdown (it shows as something like `inboundWebhookRequest.summary_text`).
7. Add **Add Contact Tag**. Tag: **`estimate-funnel-lead`**. All lowercase, with the hyphens.
8. Add **Internal Notification** > **Email**, to yourself. Subject: `New estimate lead`. Body: pick `summary_text` again, plus the contact link. This is your speed to lead alarm.
9. Click **Publish** at the top right. A saved workflow that is not published does nothing.
10. Back in the Studio, press **Send a test lead** once more. When the contact, the note and your notification all show up, answer **Yes, I got it** under **Did the test lead arrive?**. Download your funnel again and re-upload it.

That is a working lead catcher. The follow-up email and SMS in 3.3 and 3.4 work with the quick install too: use `{{contact.first_name}}` and paste your booking link, and leave out the custom field placeholders.

## FULL INSTALL (optional, when you want each answer in its own field)

Everything below builds on the quick install. It gives you number fields you can filter and report on, an opportunity in your pipeline, and the instant email and SMS.

**The payload keys never change.** They are the same for every business, every niche and every config, on purpose, so one workflow mapping works forever. These are all of them:

| Key | What it holds |
|---|---|
| `name` | full name |
| `email` | email address |
| `phone` | phone number |
| `business_name` | your business name from the config |
| `niche` | your niche key, for example `hvac` |
| `services_text` | what they picked, as one line |
| `estimate_low` | the low end, a number |
| `estimate_high` | the high end, a number |
| `estimate_low_text` | the low end ready to read, with your currency symbol, for example `$4,500` (or `12 hours`). Added in v1.1.1 |
| `estimate_high_text` | the high end ready to read, for example `$9,500`. Added in v1.1.1 |
| `estimate_unit` | `price`, `hours` or `both` |
| `currency` | for example `USD` |
| `timeline_text` | the timeline they were shown |
| `answers_text` | every question and answer as `Q: A` lines |
| `knobs_text` | your knob settings at the moment of the estimate |
| `page_url` | the page they submitted from |
| `utm_source` | where they came from, if it was on the link |
| `utm_medium` | same |
| `utm_campaign` | same |
| `submitted_at` | timestamp |
| `kit_version` | the kit version that produced it |
| `summary_text` | everything above in one readable block, for a note or an email (added in v1.1) |

## 3.1 Create the custom fields first

Do this before the workflow, or the mapping dropdowns will be empty.

Go to **Settings > Custom Fields**, click **Add Field**, and create these on the **Contact** object. Use the exact names, they are what you will look for in the mapping dropdown.

| Field name | Type |
|---|---|
| Estimate Low | Number |
| Estimate High | Number |
| Estimate Low Text | Single line text |
| Estimate High Text | Single line text |
| Estimate Unit | Single line text |
| Estimate Currency | Single line text |
| Estimate Services | Single line text |
| Estimate Timeline | Single line text |
| Estimate Answers | Multi line text |
| Estimate Niche | Single line text |
| Estimate Page URL | Single line text |
| Estimate Submitted At | Single line text |
| Estimate Knobs | Single line text |

Use Single line text where you are unsure. Date and number types are strict about format and a mismatch silently drops the value.

**The most common mistake in this whole install happens right here.** Create the fields exactly as they are written above, one at a time, and check the Type column on each one as you save it. Later, when the workflow asks you to map them, **pick the field from the dropdown, never type its name into the box.** A typed name looks identical on screen and stores nothing at all. Then run the test checklist in Part 5: the check that every custom field on your test contact has a value in it is the check that catches this.

## 3.2 Build the workflow

1. Go to **Automation > Workflows**, click **+ Create Workflow**, choose **Start from Scratch**. Name it **Estimate Funnel Lead**.
2. Click **Add New Trigger**, choose **Inbound Webhook**.
3. Copy the **Webhook URL** it shows you. **Keep this tab open.**
4. In another tab open your **Studio**, go to the **Publish** tab, pick **My CRM or automation tool** under **Where should leads go?**, paste the webhook URL, and download `my-funnel.html` again. Re-upload it to your host from Part 1 (drag the new file over the old one).
5. Open your live funnel and **submit one test estimate** with your own name and email. This is not optional: HighLevel needs to see one real payload before it can show you the field names in the mapping dropdowns.
6. Back in the workflow, the trigger should now show your sample payload with all the keys above. If it does not, click **Fetch Sample Request** (or similar) and submit again.
7. Click **+** and add **Create/Update Contact** (it may be called **Update Contact**, or similar). Map:
   - First Name and Last Name from `name`
   - Email from `email`
   - Phone from `phone`
   - Estimate Low from `estimate_low`, Estimate High from `estimate_high`
   - Estimate Low Text from `estimate_low_text`, Estimate High Text from `estimate_high_text`
   - Estimate Unit from `estimate_unit`, Estimate Currency from `currency`
   - Estimate Services from `services_text`, Estimate Timeline from `timeline_text`
   - Estimate Answers from `answers_text`, Estimate Niche from `niche`
   - Estimate Page URL from `page_url`, Estimate Submitted At from `submitted_at`
   - Estimate Knobs from `knobs_text`
   - Source from `utm_source`
8. Add **Add Contact Tag**. Tag: **`estimate-funnel-lead`**. Type it exactly, all lowercase, with the hyphens. Everything downstream keys off this tag.
9. Add **Create Opportunity**. Pipeline: your sales pipeline (make one called **Estimates** if you have none). Stage: **New Estimate**. Opportunity name: `{{contact.first_name}} {{contact.last_name}} estimate`. Value: the `estimate_low` field (the low end, so your pipeline never flatters itself).
10. Add **Internal Notification** > **Email**, to yourself. Subject: `New estimate lead: {{contact.first_name}} {{contact.last_name}}`. Body: put `{{contact.estimate_low_text}}` to `{{contact.estimate_high_text}}`, the services line and the answers line in it, plus the contact link. This is your speed to lead alarm.
11. Add **Send Email** (the one to the lead, copy below).
12. Add **Wait** > 2 minutes. Then add **Send SMS** (copy below). Two minutes apart means two notifications instead of one, which is the point.

    > **⚠️ Do not switch the SMS step on until this sub-account's A2P registration is approved.** A2P is the carrier registration that makes business texting legal in the US and Canada, and approval takes days, sometimes weeks. Sending before it is approved gets your messages blocked and can put the number itself at risk. Until the approval lands, either leave the SMS step out of the workflow entirely or build it and leave the action **disabled**. Nothing else breaks: the email step works on its own, and it is the one that does the work. Start the registration today at **Settings > Phone Numbers > Trust Center** (or similar), then come back and enable the step.

13. Click **Publish** at the top right. A saved workflow that is not published does nothing.

## 3.3 The follow-up email

Send it immediately, from a real person's address, not `noreply@`.

**📧 SUBJECT:**

```
Your estimate: {{contact.estimate_low_text}} to {{contact.estimate_high_text}}, {{contact.first_name}}
```

**📧 BODY:**

```
Hi {{contact.first_name}},

Here is your estimate again so you have it in writing:

{{contact.estimate_services}}
{{contact.estimate_low_text}} to {{contact.estimate_high_text}}
Typical timeline: {{contact.estimate_timeline}}

That range is based on what you told us. It is an estimate, not a final quote. The exact number depends on what we find when we look at the job properly, and we will not surprise you with it.

The fastest way to turn this into a real number is a short call. Pick any time that suits you here:
YOUR-BOOKING-LINK

If anything about the range looks off, just reply to this email and tell me what I have got wrong.

[Your name]
[Your business]
```

The `_text` fields read like the result card, so the email says "$4,500 to $9,500", not "4500 to 9500". Keep the number fields (Estimate Low, Estimate High) for filters, reports and the opportunity value.

Replace `YOUR-BOOKING-LINK` with your calendar link. One link in the email. Only one. Every extra link is a fork in the road that is not the one you want.

## 3.4 The follow-up SMS

**📱 SMS:**

```
{{contact.first_name}}, [your business] here. Your estimate came out at {{contact.estimate_low_text}} to {{contact.estimate_high_text}}. It is an estimate, not a final quote, and the details are in your email. Want to lock in a real number? Grab a time: YOUR-BOOKING-LINK Reply STOP to opt out.
```

Keep it under 160 characters where you can. One link. Include the opt out. Say your business name in the first few words so you are not a mystery number.

**Never write in either message:** "guaranteed", "final price", "fixed price", "this price is locked". You do not know the job yet. A number that reads as a promise is a refund argument later.

## 3.5 Speed to lead

The whole point of an instant estimate is that nothing waits on you. Two rules:

1. **The email and the SMS are sent by HighLevel, not by you.** They fire whether you are asleep, driving or on another job. Never replace them with a task that says "call this lead".
2. **Add a task anyway, due in 1 hour**, assigned to whoever calls people. The automation buys you the hour. It does not replace the human call. Leads that get a human touch within the hour book at a completely different rate to leads that get one tomorrow.

---

# PART 4. Let HighLevel's AI build the workflow for you

HighLevel has a built in AI workflow builder (look for **Ask AI**, or **Create with AI**, or similar, when you create a new workflow). It does not always exist on every plan and it does not always get it right, so check its work against Part 3.

**📋 COPY THIS, paste it into the Ask AI box when you create a new workflow:**

```
Build a workflow named "Estimate Funnel Lead".

Trigger: Inbound Webhook.

The webhook payload has these exact keys, always the same, for every lead:
name, email, phone, business_name, niche, services_text, estimate_low, estimate_high,
estimate_unit, currency, timeline_text, answers_text, knobs_text, page_url,
utm_source, utm_medium, utm_campaign, submitted_at, kit_version, summary_text,
estimate_low_text, estimate_high_text

Steps, in this order:

1. Create or update a contact. Map name to first and last name, email to email,
   phone to phone. Map estimate_low, estimate_high, estimate_unit, currency,
   services_text, timeline_text, answers_text, niche, page_url and submitted_at
   into contact custom fields named Estimate Low, Estimate High, Estimate Unit,
   Estimate Currency, Estimate Services, Estimate Timeline, Estimate Answers,
   Estimate Niche, Estimate Page URL and Estimate Submitted At. Map
   estimate_low_text and estimate_high_text into contact custom fields named
   Estimate Low Text and Estimate High Text, and knobs_text into Estimate Knobs.
   Map utm_source to the contact source.
2. Add a note to the contact with the text of summary_text.
3. Add the contact tag: estimate-funnel-lead
4. Create an opportunity in my main sales pipeline, first stage, named
   "{{contact.first_name}} {{contact.last_name}} estimate", with the value set
   from estimate_low.
5. Send me an internal notification email with the lead's name, the estimate range
   (from Estimate Low Text and Estimate High Text), the services they picked and a
   link to the contact.
6. Send the lead an email immediately. Subject: "Your estimate:
   {{contact.estimate_low_text}} to {{contact.estimate_high_text}}, {{contact.first_name}}".
   The body restates the range (use the Estimate Low Text and Estimate High Text
   fields, never the number fields, so it reads "$4,500 to $9,500") and the
   timeline, says clearly that it is an estimate and not a final quote, and has
   exactly one link, to my booking calendar. No guarantee wording anywhere.
7. Wait 2 minutes.
8. Send the lead an SMS under 160 characters that names my business, restates the
   range from Estimate Low Text and Estimate High Text, says it is an estimate and
   not a final quote, has one booking link, and ends with "Reply STOP to opt out".
9. Create a task assigned to me, due in 1 hour: "Call this estimate lead".

Do not add any other steps. Do not add a second link to any message. Do not use the
words guaranteed, final price or fixed price anywhere.
```

Separately, once and outside this workflow (a workflow step would make one per lead): in **Tasks**, add a task for yourself named "Check your estimate funnel", toggle **Recurring Task** on and set it to repeat monthly, then say "check my funnel" to Claude when it comes due.

Then open every step it built and check it against Part 3. The two things it most often gets wrong are the custom field mapping (it invents field names) and the tag (it capitalises it). Fix those two and publish.

---

# PART 5. Test it before anyone real sees it

Walk this list. Every line, in order, before you put the link anywhere.

- [ ] Your funnel link opens on a phone, on mobile data, not just on your own wifi.
- [ ] You walked the whole funnel yourself as a customer and got a number.
- [ ] You walked it a second time picking "not sure" on every question. The range got wider and nothing broke.
- [ ] You walked it a third time picking the biggest, most urgent job. The number is one you would actually be happy to see a customer quote back at you.
- [ ] The estimate that appears on screen is the same as the one in the email. If they differ, your host has an old file, upload the new one.
- [ ] The contact appeared in HighLevel with the tag `estimate-funnel-lead`.
- [ ] Every custom field on that contact has a value in it. An empty field is a broken mapping, fix it now.
- [ ] The opportunity appeared in the pipeline.
- [ ] Your internal notification arrived.
- [ ] If you set a backup email on the Publish tab, you pressed **Send a test alert email** and an email starting with "ALERT: your CRM webhook failed" arrived (check spam). If the CRM send ever fails, the lead is emailed to you with an alert, so no lead is lost and you know the same minute.
- [ ] The lead email arrived, **check the spam and promotions folders too**, and the booking link in it opens your real calendar.
- [ ] The SMS arrived, or you have confirmed A2P is still pending and the step is disabled.
- [ ] You booked a slot from that calendar link and the booking confirmation arrived.
- [ ] Nothing in either message reads as a guaranteed or final price.
- [ ] Someone who is not you walked the funnel and did not ask you a single question to get through it.

That last line is the one people skip. It is also the one that finds the real problems.

**Then delete your test contacts** before you start counting anything, or your first week of numbers will be you.
