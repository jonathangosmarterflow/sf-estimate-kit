# Put your estimate funnel inside HighLevel

Zero assumed knowledge. Five parts, in order. Part 1 puts your funnel file on the internet. Part 2 puts it on a HighLevel page. Part 3 catches the lead: a 5 minute QUICK INSTALL first, then the optional FULL INSTALL. Part 4 is a shortcut that builds Part 3 for you. Part 5 is the test you do before you send anyone real.

You need one file to start: **`my-funnel.html`**, the file the Studio's Publish tab downloaded for you. It is one single file. Everything is inside it. No folder, no images, no other files.

HighLevel renames menu items from time to time. Where a name may have moved, this guide says "or similar". Look for the closest match.

This guide is a US setup. Outside the US, check your local rules on consent for email and text (for example CASL in Canada, PECR and GDPR in the UK and EU) before you turn on any follow-up.

---

# PART 1. Put `my-funnel.html` on the internet

Pick ONE of these four. Option A is the fastest if you have never done this before.

## Option A. A drag and drop static host (about 2 minutes)

Several well known services let you drag a folder onto a web page and give you back a live link, free tier included, no account setup beyond an email. Netlify Drop, Cloudflare Pages and Vercel all work this way. We are not promising any particular pricing, limit or free tier, they change: open the one you pick and read its own page.

The steps are the same whichever you pick:

1. On your computer, make a new folder called `funnel`.
2. Put `my-funnel.html` inside it and **rename the file to `index.html`**. This matters. `index.html` is the name a web host serves by default.
3. Open the host's drop page in your browser and sign in or sign up.
4. **Drag the whole `funnel` folder** onto the drop area. Not the file, the folder.
5. Wait for it to finish and copy the link it gives you. It looks like `https://something-random.netlify.app`.
6. **Open that link in a new tab and walk your funnel as if you were a customer.** If you see your funnel, Part 1 is done.

Keep that link. You will paste it in Part 2.

## Option B. GitHub Pages (free, permanent, about 5 minutes)

1. Create a free account at github.com.
2. Click **+** at the top right, then **New repository**. Name it `my-funnel`. Choose **Public**. Click **Create repository**.
3. On the next screen click **uploading an existing file**.
4. Drag `my-funnel.html` in, **renamed to `index.html`** first.
5. Click **Commit changes**.
6. Click **Settings** (top of the repository), then **Pages** in the left sidebar.
7. Under **Branch**, pick `main`, leave the folder as `/ (root)`, click **Save**.
8. Wait about a minute, refresh the page, and copy the link it shows at the top.

## Option C. Your own website

If you already have a website with any kind of file manager or FTP access:

1. Upload `my-funnel.html` into your site's public folder, for example into a new folder called `estimate`.
2. Your link is then `https://yoursite.com/estimate/my-funnel.html`.
3. Open it in a browser and check it loads.

## Option D. Paste the code straight into a HighLevel page (no hosting at all)

This works and it is the only option with nothing to sign up for, but it is the fiddliest. Use it if the others failed.

1. In HighLevel, go to **Sites** (or **Funnels & Websites**, or similar), open the funnel or website page you want.
2. Add an element: **Custom JS/HTML** (it may be called **Custom Code**, or similar). Drag it onto the page.
3. Click the element, then **Open Code Editor**.
4. Open `my-funnel.html` in a plain text editor (TextEdit on a Mac, set to plain text; Notepad on Windows). Select all, copy.
5. Paste it into the code editor. Save. Save the page. **Publish** the page.

**The gotchas, all four of which have bitten us:**

- The page editor can strip or mangle parts of a full HTML document (the `<html>`, `<head>` and `<body>` tags). If your funnel looks broken after pasting, that is why. Go back to Option A.
- HighLevel's own page styles can leak into your funnel and change your fonts, button shapes and spacing. The iframe in Part 2 is immune to this. A pasted block is not.
- Every time you change your config you have to redo this paste. With Options A to C you replace one file and every page updates at once.
- The page builder's autosave sometimes reformats pasted code. Always re-open the page after publishing and check the funnel still works.

---

# PART 2. Embed it on a HighLevel page

Skip this if you used Option D above. Your funnel is already on the page.

The Studio's **Publish** tab generates this snippet with your link already in it. Here it is anyway, so you can see what it does. Replace `YOUR-FUNNEL-URL` with the link from Part 1.

**📋 COPY THIS, you will paste it into a HighLevel Custom JS/HTML element at step 3 below:**

```html
<div id="efk-wrap" style="max-width:720px;margin:0 auto;">
  <iframe
    id="efk-frame"
    src="YOUR-FUNNEL-URL"
    title="Instant estimate"
    style="width:100%;border:0;display:block;min-height:640px;"
    loading="lazy"
    scrolling="no"></iframe>
</div>
<script>
(function () {
  var f = document.getElementById('efk-frame');
  // pass utm_ values on this page's link (for example utm_source=booked) to the funnel
  try {
    var u = new URL(f.getAttribute('src'), location.href), n = 0;
    new URLSearchParams(location.search).forEach(function (v, k) {
      if (/^utm_/.test(k)) { u.searchParams.set(k, v); n++; }
    });
    if (n) f.src = u.toString();
  } catch (err) {}
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.efk !== 'height') return;
    if (f.contentWindow && e.source !== f.contentWindow) return;
    var h = parseInt(d.value, 10);
    if (h > 200 && h < 20000) f.style.height = h + 'px';
  });
  // ask once in case the funnel loaded before this script did
  f.addEventListener('load', function () {
    try { f.contentWindow.postMessage({ efk: 'height?' }, '*'); } catch (err) {}
  });
})();
</script>
```

Steps:

1. In HighLevel, open **Sites** (or **Funnels & Websites**, or similar) and open the page where the funnel should live.
2. Drag in a **Custom JS/HTML** element (or **Custom Code**, or similar) where you want the funnel to appear.
3. Click it, choose **Open Code Editor**, and paste the block above.
4. Replace `YOUR-FUNNEL-URL` with your real link. Keep the quotes around it.
5. Save the element, save the page, click **Publish**.
6. Open the live page **on your phone** and walk the funnel. The frame should grow and shrink as you move through the questions, with no scrollbar inside it.

**About `?utm_source=` on this page.** The snippet passes `utm_` values from the page's own link on to the funnel, so `YOUR-HIGHLEVEL-PAGE?utm_source=facebook` still tells you where a lead came from. We have not confirmed that every HighLevel page keeps the query when it loads, so for the call prep link in 3.8 use the direct link to your funnel (your Part 1 link or your live link), never this page.

**If the frame stays 640px tall and gets its own scrollbar:** the auto-height message is not arriving. The funnel still works, it just does not resize. Raise `min-height` to `900px` and move on. Do not let this block your launch.

---

# PART 3. Catch the lead (the workflow)

Before you build anything here, open **`followup-map.html`** from the kit folder. It is a preview of the documented workflows in this part: the emails, texts and tasks, in order, with a sample lead's real numbers already in it. It is not a readout of what is installed in your HighLevel, so Part 5 is still the test.

Your funnel sends one webhook when someone submits. This part receives it. Do the QUICK INSTALL first. It gets every lead into HighLevel today with nothing to map but a name, an email and a phone. Do the FULL INSTALL later, only if you want each answer in its own field.

## QUICK INSTALL (about 5 minutes, zero custom fields)

Every lead carries `summary_text`: one readable block with your business, the service or services, the estimate from low to high with the currency, the timeline, and every question with its answer. You drop that block into a note on the contact and you are done.

1. Go to **Automation > Workflows**, click **+ Create Workflow**, choose **Start from Scratch**. Name it **Estimate Funnel Lead**.
2. Click **Add New Trigger**, choose **Inbound Webhook**. Copy the **Webhook URL** it shows you. **Keep this tab open.**
3. In another tab open your **Studio**, go to the **Publish** tab. Under **Where should leads go?** pick **My CRM or automation tool**, paste the webhook URL, and press **Send a test lead**.
4. Back in HighLevel, click **Fetch Sample Request** (or similar) on the trigger. You should see a sample named **Test Submission** with all the keys listed further down. Save the trigger.
5. Click **+** and add **Create/Update Contact** (it may be called **Update Contact**, or similar). Map First Name and Last Name from `name`, Email from `email`, Phone from `phone`. Pick each one from the dropdown, never type it.
6. Add **Add Note** (it may be called **Add Contact Note**, or similar). For the note body, pick `summary_text` from the webhook fields in the dropdown (it shows as something like `inboundWebhookRequest.summary_text`).
7. Add **Add Contact Tag**. Tag: **`estimate-funnel-lead`**. All lowercase, with the hyphens.
8. Add **Internal Notification** > **Email**, to yourself. Subject: `New estimate lead`. Body: pick `summary_text` again, plus the contact link. This is your speed to lead alarm.
9. Click **Publish** at the top right. A saved workflow that is not published does nothing.
10. Back in the Studio, press **Send a test lead** once more. When the contact, the note and your notification all show up, answer **Yes, I got it** under **Did the test lead arrive?**. Download your funnel again and re-upload it.

That is a working lead catcher. What the quick install can and cannot do:

- **It has no estimate fields on the contact.** The 3.3 email, the 3.4 SMS and the day 1 and day 3 follow-ups in 3.7 quote the range from those fields, so they need the full install. With the quick install, use the two finished messages below instead, plus the day 7 and day 14 follow-ups, which quote no numbers. 3.8 works as written.
- **It calls every lead, test and made up ones included.** If you add the 1 hour call task from 3.5, it is made for every lead. The note says "Possibly a test or made up lead" when the funnel flagged one, so look before you call. Skipping the task by itself, in 3.5 and in the hot lead workflow in 3.6, needs the full install, because the If/Else reads the Estimate Possibly Fake field.

**📧 QUICK INSTALL EMAIL, SUBJECT:**

```
Your estimate from [Your business], {{contact.first_name}}
```

**📧 QUICK INSTALL EMAIL, BODY:**

```
Hi {{contact.first_name}},

Thank you for checking your estimate with us. We have your answers, so you do not need to explain the job twice.

The range you saw is an estimate, not a final quote. The exact number depends on what we find when we look at the job properly.

The next step is a short call to check the scope. Pick any time that suits you here:
YOUR-BOOKING-LINK

If anything about the range looked off, just reply to this email and tell me.

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**📱 QUICK INSTALL SMS** (the same two conditions as 3.2 step 12: A2P approved, and the lead agreed to texts):

```
{{contact.first_name}}, [your business] here. Your estimate is in your email. Want to check the scope? Book a short call: YOUR-BOOKING-LINK Reply STOP to opt out.
```

## FULL INSTALL (optional, when you want each answer in its own field)

Everything below builds on the quick install. It gives you number fields you can filter and report on, an opportunity in your pipeline, and the instant email and SMS.

**The payload keys never change.** They are the same for every business, every niche and every config, on purpose, so one workflow mapping works forever. These are all of them:

| Key | What it holds |
|---|---|
| `name` | full name |
| `email` | email address |
| `phone` | phone number |
| `business_name` | your business name from the config |
| `niche` | your niche key, for example `hvac` |
| `services_text` | what they picked, as one line |
| `estimate_low` | the low end, a number |
| `estimate_high` | the high end, a number |
| `estimate_low_text` | the low end ready to read, with your currency symbol, for example `$4,500` (or `12 hours`). Added in v1.1.1 |
| `estimate_high_text` | the high end ready to read, for example `$9,500`. Added in v1.1.1 |
| `estimate_unit` | `price`, `hours` or `both` |
| `currency` | for example `USD` |
| `timeline_text` | the timeline they were shown |
| `answers_text` | every question and answer as `Q: A` lines |
| `knobs_text` | your knob settings at the moment of the estimate |
| `page_url` | the page they submitted from |
| `utm_source` | where they came from, if it was on the link |
| `utm_medium` | same |
| `utm_campaign` | same |
| `submitted_at` | timestamp |
| `kit_version` | the kit version that produced it |
| `summary_text` | everything above in one readable block, for a note or an email (added in v1.1) |
| `possibly_fake` | `true` when the lead looks like a test or made up: a name like "test" or "john doe", a 555-01xx phone number, a phone that is one digit repeated or digits in a row, or an email at example.com or ending in .test. The estimate still showed and still sent. Added in v1.2 |
| `fake_reasons` | why, in plain words, for example `the name looks like a test (test)`. Empty when `possibly_fake` is `false`. Added in v1.2 |
| `watch_match` | `true` when the lead's name or email domain is on the watch list you typed in the Studio. Added in v1.2 |

## 3.1 Create the custom fields first

Do this before the workflow, or the mapping dropdowns will be empty.

Go to **Settings > Custom Fields**, click **Add Field**, and create these on the **Contact** object. Use the exact names, they are what you will look for in the mapping dropdown.

| Field name | Type |
|---|---|
| Estimate Low | Number |
| Estimate High | Number |
| Estimate Low Text | Single line text |
| Estimate High Text | Single line text |
| Estimate Unit | Single line text |
| Estimate Currency | Single line text |
| Estimate Services | Single line text |
| Estimate Timeline | Single line text |
| Estimate Answers | Multi line text |
| Estimate Niche | Single line text |
| Estimate Page URL | Single line text |
| Estimate Submitted At | Single line text |
| Estimate Knobs | Single line text |
| Estimate Possibly Fake | Single line text |
| Estimate Fake Reasons | Single line text |
| Estimate Watch Match | Single line text |

Use Single line text where you are unsure. Date and number types are strict about format and a mismatch silently drops the value.

**The most common mistake in this whole install happens right here.** Create the fields exactly as they are written above, one at a time, and check the Type column on each one as you save it. Later, when the workflow asks you to map them, **pick the field from the dropdown, never type its name into the box.** A typed name looks identical on screen and stores nothing at all. Then run the test checklist in Part 5: the check that every custom field on your test contact has a value in it is the check that catches this.

## 3.2 Build the workflow

1. Go to **Automation > Workflows**, click **+ Create Workflow**, choose **Start from Scratch**. Name it **Estimate Funnel Lead**.
2. Click **Add New Trigger**, choose **Inbound Webhook**.
3. Copy the **Webhook URL** it shows you. **Keep this tab open.**
4. In another tab open your **Studio**, go to the **Publish** tab, pick **My CRM or automation tool** under **Where should leads go?**, paste the webhook URL, and download `my-funnel.html` again. Re-upload it to your host from Part 1 (drag the new file over the old one).

   Your webhook link sits inside your funnel page, so anyone who reads the page can find it and send made up leads into this workflow, texts included. Keep the SMS step behind the two conditions in step 12, leave **Allow Duplicate Contact** off (**Settings > Business Profile**, or similar), and if strange leads arrive in a burst, make a new Inbound Webhook trigger, paste its link in the Studio and republish.
5. Open your live funnel and **submit one test estimate** with your own name and email. This is not optional: HighLevel needs to see one real payload before it can show you the field names in the mapping dropdowns.
6. Back in the workflow, the trigger should now show your sample payload with all the keys above. If it does not, click **Fetch Sample Request** (or similar) and submit again.
7. Click **+** and add **Create/Update Contact** (it may be called **Update Contact**, or similar). Map:
   - First Name and Last Name from `name`
   - Email from `email`
   - Phone from `phone`
   - Estimate Low from `estimate_low`, Estimate High from `estimate_high`
   - Estimate Low Text from `estimate_low_text`, Estimate High Text from `estimate_high_text`
   - Estimate Unit from `estimate_unit`, Estimate Currency from `currency`
   - Estimate Services from `services_text`, Estimate Timeline from `timeline_text`
   - Estimate Answers from `answers_text`, Estimate Niche from `niche`
   - Estimate Page URL from `page_url`, Estimate Submitted At from `submitted_at`
   - Estimate Knobs from `knobs_text`
   - Estimate Possibly Fake from `possibly_fake`, Estimate Fake Reasons from `fake_reasons`, Estimate Watch Match from `watch_match`
   - Source from `utm_source`
8. Add **Add Contact Tag**. Tag: **`estimate-funnel-lead`**. Type it exactly, all lowercase, with the hyphens. Everything downstream keys off this tag.
9. Add **Create Opportunity**. Pipeline: your sales pipeline (make one called **Estimates** if you have none). Stage: **New Estimate**. Opportunity name: `{{contact.first_name}} {{contact.last_name}} estimate`. Value: the `estimate_low` field (the low end, so your pipeline never flatters itself).
10. Add **Internal Notification** > **Email**, to yourself. Subject: `New estimate lead: {{contact.first_name}} {{contact.last_name}}`. Body: put `{{contact.estimate_low_text}}` to `{{contact.estimate_high_text}}`, the services line and the answers line in it, plus the contact link. This is your speed to lead alarm.
11. Add **Send Email** (the one to the lead, copy below).
12. Add **Wait** > 2 minutes. Then add **Send SMS** (copy below). Two minutes apart means two notifications instead of one, which is the point.

    > **⚠️ The SMS step stays off until two things are true: this sub-account's A2P registration is approved, and the lead agreed to texts.** A2P is the carrier registration for business texting in the US and Canada, and approval takes days, sometimes weeks. Sending before it is approved gets your messages blocked and can put the number itself at risk. Until the approval lands, either leave the SMS step out of the workflow entirely or build it and leave the action **disabled**. Nothing else breaks: the email step works on its own, and it is the one that does the work. Start the registration today at **Settings > Phone Numbers > Trust Center** (or similar), then come back and enable the step.
    >
    > A2P approval is not the lead's permission. The lead agrees on your funnel: every preset shows this line under the contact step, "By submitting you agree we may text or email you about this estimate. Reply STOP to end texts." Keep it (it is `lead_capture.consent_text` in your settings). Never text a contact on DND. In your A2P campaign, describe that same opt in, say how often you text (one estimate text, and one reminder for each booked call), and set a reply for HELP that names your business and how to reach you.

13. Click **Publish** at the top right. A saved workflow that is not published does nothing.

## 3.3 The follow-up email

Send it immediately, from a real person's address, not `noreply@`.

**📧 SUBJECT:**

```
Your estimate: {{contact.estimate_low_text}} to {{contact.estimate_high_text}}, {{contact.first_name}}
```

**📧 BODY:**

```
Hi {{contact.first_name}},

Here is your estimate again so you have it in writing:

{{contact.estimate_services}}
{{contact.estimate_low_text}} to {{contact.estimate_high_text}}
Typical timeline: {{contact.estimate_timeline}}

That range is based on what you told us. It is an estimate, not a final quote. The exact number depends on what we find when we look at the job properly.

The next step is a short call to check the scope. Pick any time that suits you here:
YOUR-BOOKING-LINK

If anything about the range looks off, just reply to this email and tell me what I have got wrong.

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

The `_text` fields read like the result card, so the email says "$4,500 to $9,500", not "4500 to 9500". Keep the number fields (Estimate Low, Estimate High) for filters, reports and the opportunity value.

Replace `YOUR-BOOKING-LINK` with your calendar link. One booking link in the email, plus the unsubscribe link and postal address the law asks for (the footer, explained in 3.7). Every extra link is a fork in the road that is not the one you want.

## 3.4 The follow-up SMS

**📱 SMS:**

```
{{contact.first_name}}, [your business] here. Your estimate: {{contact.estimate_low_text}} to {{contact.estimate_high_text}}, details in your email. Want to check the scope? Book a short call: YOUR-BOOKING-LINK Reply STOP to opt out.
```

With a sample business name and a 45 character booking link this comes to about 205 characters, which sends as 2 text segments (one segment holds 160 plain characters). A shorter business name or booking link brings it down. One link. Keep the STOP line. Say your business name in the first few words so you are not a mystery number. Only on when both conditions in 3.2 step 12 are true.

**Never write in either message:** "guaranteed", "final price", "fixed price", "this price is locked". You do not know the job yet. A number that reads as a promise is a refund argument later.

## 3.5 Speed to lead

An instant estimate should never wait on you. Three rules:

1. **The email and the SMS are sent by HighLevel, not by you.** They fire whether you are asleep, driving or on another job. Never replace them with a task that says "call this lead".
2. **Add a task anyway, due in 1 hour**, assigned to whoever calls people. The automation buys you the hour. It does not replace the human call. Prompt human follow-up tends to book more leads than a call the next day.
3. **Put the task behind one If/Else (full install only).** If the contact field Estimate Possibly Fake contains `true`, skip the task. Check what HighLevel stored first: open your Part 5 test contact named "Test" and look at that field. It should read `true`; if it reads something else, match that instead. Everything else still runs: the visitor saw the estimate, and the email and SMS still go, so a real person with an odd phone number still hears from you. Only the call waits until you have looked at the lead yourself. The quick install has no field to check, so there every lead gets the task.

**Once a week, open the task list and count the "Call this estimate lead" tasks that went overdue.** That is your overdue call task count, the simplest weekly check that leads are being called.

## 3.6 Hot leads

Some leads tell you they are ready. Catch them in a second workflow, named **Estimate Hot Lead**:

1. Trigger: **Customer Replied** (any channel), filtered to contacts with the tag `estimate-funnel-lead`.
2. **Opt-outs first.** Start the workflow with an If/Else: if the contact is on DND for any channel, or the reply says STOP, stop, unsubscribe or cancel, end there. A reply like that is a request to stop, never a hot lead: it ends every sequence (3.7) and never creates a task.
3. Then an If/Else: if the contact already has the tag `hot-lead`, end there, so one lead never makes five tasks.
4. Then an If/Else (full install only): if Estimate Possibly Fake contains `true`, end there, the same check as 3.5.
5. Everything else counts: a reply, and a price question in a reply counts the same. Add the tag **`hot-lead`**, create a task **"Hot lead: call within the hour"** due in 1 hour, send yourself an **Internal Notification** with the subject `Hot estimate lead: {{contact.first_name}} {{contact.last_name}}`, and move the opportunity to a stage called **Hot** (add it to your Estimates pipeline). It stays in Hot until you move it to won or lost.

Email opens do not make a lead hot. Some email apps open every email by themselves, so an open is a weak signal. If you want to see them, add a second trigger, **Email Events > Opened** (or similar), that only adds the tag `estimate-opened` and ends there: no task, no notification.

An alert is not a queue. A notification tells you something happened. It does not make anybody pick up the phone. Name the person who owns the hour, assign the task to them, and check on Friday that every Hot lead got its call.

## 3.7 Follow-up sequence

Most leads do not book on day one. These four emails go out over two weeks, in the same **Estimate Funnel Lead** workflow, after the task. Each one comes from a real person's address, has one link at most, and that link is your booking link.

**When it stops:** the sequence ends the moment the lead books, replies, or opts out. Set all three:

- **Booked:** add a **Goal Event** (or similar) set to "appointment booked". A lead who books jumps out of the workflow.
- **Replied:** open the workflow **Settings** and turn on **Stop on response** (or similar).
- **Opted out:** HighLevel never emails or texts a contact on DND (do not disturb) for that channel, and a STOP reply puts them on DND. A reply of "unsubscribe" to an email is a reply, so Stop on response ends the sequence; also put that contact's email on DND the same day, so no other workflow emails them. An opt-out ends every sequence and never creates a task (the hot lead workflow in 3.6 checks for it first).

**The footer, on every email to a lead.** Every email in this guide ends with your name, your business, `{{your business postal address}}` and the line "Not interested? Reply "unsubscribe" and we will stop emailing you." US law (CAN-SPAM) requires a real mailing address and a working way to unsubscribe in marketing email, so replace `{{your business postal address}}` with your business's postal address in every email, and turn on HighLevel's unsubscribe link for these emails (in the email step or under **Settings > Email Services**, or similar). The address and the unsubscribe link do not count against the one link rule.

Add **Wait** > 1 day, then the first email. Then **Wait** 2 more days, 4 more days and 7 more days before the next three. That lands them 1 day, 3 days, 1 week and 2 weeks after the lead submitted.

**📧 DAY 1, SUBJECT:**

```
Did your estimate land, {{contact.first_name}}?
```

**📧 DAY 1, BODY:**

```
Hi {{contact.first_name}},

Quick check that yesterday's estimate reached you: {{contact.estimate_low_text}} to {{contact.estimate_high_text}} for {{contact.estimate_services}}.

Did that range look about right for what you had in mind? A one line reply is plenty. If something looks off, I will tell you why.

If you would rather talk it through, pick a time here:
YOUR-BOOKING-LINK

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**📧 DAY 3, SUBJECT:**

```
A question about timing, {{contact.first_name}}
```

**📧 DAY 3, BODY:**

```
Hi {{contact.first_name}},

No rush from our side. If timing matters for your job, reply with the dates that suit you and we will tell you what is open.

If you would rather check the scope of your estimate of {{contact.estimate_low_text}} to {{contact.estimate_high_text}} first, a short call does that:
YOUR-BOOKING-LINK

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**📧 DAY 7, SUBJECT:**

```
How the call and the visit work
```

**📧 DAY 7, BODY:**

```
Hi {{contact.first_name}},

In case it helps to know what happens next, here is how we work.

The call is short. We go through what you told us, ask the few questions the form could not, and tell you what we think the job needs.

If the job needs eyes on it, we book a visit at a time that suits you. We look properly, explain what we found in plain words, and tell you the price before any work starts. You decide after that, with no pressure either way.

If that sounds useful, pick a time here:
YOUR-BOOKING-LINK

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**📧 DAY 14, SUBJECT:**

```
Should I close your file, {{contact.first_name}}?
```

**📧 DAY 14, BODY:**

```
Hi {{contact.first_name}},

I have not heard back since your estimate, so I will close your file and stop emailing you about it.

Before I do, one question: what held you back? A one word answer is fine. Price, timing, someone else, or just not now, all of it helps.

If you ever want to pick it up again, reply to this email.

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

Day 14 has no link on purpose. It asks one question and welcomes a reply. The answers tell you more about your price and your offer than any report.

## 3.8 Booking messages

When a lead books, a different set of messages takes over. Build three small workflows on your estimate call calendar.

**Workflow "Estimate Call Booked".** Trigger: **Customer Booked Appointment** (or similar), on that calendar.

1. Send the confirmation email straight away. Its one link is your call prep link: your funnel link with `utm_source=booked` in it, so the lead can run through the questions before the call. Those answers reach you marked `utm_source = booked`.
2. Add an If/Else: if the call is more than 24 hours away, **Wait** until 24 hours before the appointment (or similar), then send the 24 hour reminder. If they booked inside 24 hours, skip it.
3. **Wait** until 1 hour before the appointment, then send the 1 hour reminder. Send it as an SMS once your A2P registration is approved and the lead agreed to texts (3.2 step 12). Until then, send the same words as an email with the subject `Our call starts in about an hour`.

**📧 CONFIRMATION, SUBJECT:**

```
You are booked, {{contact.first_name}}
```

**📧 CONFIRMATION, BODY:**

```
Hi {{contact.first_name}},

You are booked for {{appointment.start_time}}. Thank you.

One thing that helps us prepare, and takes about 2 minutes: run through the estimate questions here if you have not already. Your answers come straight to us, so the call can start with your job instead of the basics.
YOUR-FUNNEL-LINK?utm_source=booked

If the time stops working, reply to this email.

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

Replace `YOUR-FUNNEL-LINK?utm_source=booked` with your call prep link:

- **Live link:** copy **Your call prep link** from the Studio's Publish tab. It puts `?utm_source=booked` before the `#`, where it belongs. (A live link with `?utm_source=booked` typed on the very end also works from v1.2.1.)
- **Hosted file (Part 1):** your Part 1 link with `?utm_source=booked` on the end, for example `https://yoursite.com/estimate/?utm_source=booked`.
- **Not the HighLevel page from Part 2.** Use the direct link to the funnel itself (see the note in Part 2).

`{{appointment.start_time}}` is HighLevel's appointment time field: pick it from the merge field list (or similar) rather than typing it.

**When a booked lead runs the call prep link,** the same webhook fires again, into Estimate Funnel Lead. Without a branch it would make a second opportunity, a new call task and restart the follow-ups for someone who already booked. Map Source from `utm_source` in the Create/Update Contact step (the full install already does), then add an If/Else right after that step: if the contact's Source is `booked`, add the note, notify yourself, and end there. HighLevel only runs a workflow again for the same contact when **Allow re-entry** is on in the workflow settings (or similar). We have not tested every HighLevel setting for this, so Part 5 has a test for it.

**📧 24 HOURS BEFORE, SUBJECT:**

```
Tomorrow: your call with [Your business]
```

**📧 24 HOURS BEFORE, BODY:**

```
Hi {{contact.first_name}},

A reminder that we are talking {{appointment.start_time}}.

Nothing to prepare. If you have photos of the job, keep them handy.

If the time no longer works, reply and tell me.

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**📱 1 HOUR BEFORE, SMS:**

```
{{contact.first_name}}, [your business] here. A reminder that our call starts in about an hour. Reply here if anything changed. Reply STOP to opt out.
```

**Workflow "Estimate Call Missed".** Trigger: **Appointment Status** is **No Show** (or similar), on the same calendar. **Wait** 1 hour, send the first email. **Wait** 2 days, send the second. Turn on **Stop on response**, and add a Goal Event for a new booking. An opt-out ends it, the same as 3.7.

The reminders are about a call the lead booked, so they are transactional. The missed call emails ask for a new booking, so treat them as marketing. Every email here carries the footer from 3.7 either way.

**📧 MISSED CALL, 1 HOUR AFTER, SUBJECT:**

```
Sorry we missed you, {{contact.first_name}}
```

**📧 MISSED CALL, 1 HOUR AFTER, BODY:**

```
Hi {{contact.first_name}},

We were set to talk at {{appointment.start_time}} and could not reach you. No problem, things come up.

If you still want to go over the job, pick a new time here:
YOUR-BOOKING-LINK

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**📧 MISSED CALL, 2 DAYS AFTER, SUBJECT:**

```
Still want to go over the job, {{contact.first_name}}?
```

**📧 MISSED CALL, 2 DAYS AFTER, BODY:**

```
Hi {{contact.first_name}},

This is my last note about the call we missed. If the job is still on your list, a new time is quick to book:
YOUR-BOOKING-LINK

If it is not, no reply needed.

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**Workflow "Estimate Call Cancelled".** Trigger: **Appointment Status** is **Cancelled** (or similar), on the same calendar. Send this straight away. It asks one question and has no link.

**📧 CANCELLED, SUBJECT:**

```
Your call is cancelled, {{contact.first_name}}
```

**📧 CANCELLED, BODY:**

```
Hi {{contact.first_name}},

Your call is cancelled. There is nothing else you need to do.

One question, if you have a moment: what made you cancel? A one line reply is plenty.

[Your name]
[Your business]
{{your business postal address}}
Not interested? Reply "unsubscribe" and we will stop emailing you.
```

**The owner habit that makes this work: mark no-shows right away.** The missed call messages only start when the appointment is marked **No Show** in the calendar. Mark it the minute the call is missed, not at the end of the week.

---

# PART 4. Let HighLevel's AI build the workflow for you

HighLevel has a built in AI workflow builder (look for **Ask AI**, or **Create with AI**, or similar, when you create a new workflow). It does not always exist on every plan and it does not always get it right, so check its work against Part 3.

Open `followup-map.html` to see this sequence with your numbers before you paste anything.

**📋 COPY THIS, paste it into the Ask AI box when you create a new workflow:**

```
Build a workflow named "Estimate Funnel Lead".

Trigger: Inbound Webhook.

The webhook payload has these exact keys, always the same, for every lead:
name, email, phone, business_name, niche, services_text, estimate_low, estimate_high,
estimate_unit, currency, timeline_text, answers_text, knobs_text, page_url,
utm_source, utm_medium, utm_campaign, submitted_at, kit_version, summary_text,
estimate_low_text, estimate_high_text, possibly_fake, fake_reasons, watch_match

Steps, in this order:

1. Create or update a contact. Map name to first and last name, email to email,
   phone to phone. Map estimate_low, estimate_high, estimate_unit, currency,
   services_text, timeline_text, answers_text, niche, page_url and submitted_at
   into contact custom fields named Estimate Low, Estimate High, Estimate Unit,
   Estimate Currency, Estimate Services, Estimate Timeline, Estimate Answers,
   Estimate Niche, Estimate Page URL and Estimate Submitted At. Map
   estimate_low_text and estimate_high_text into contact custom fields named
   Estimate Low Text and Estimate High Text, and knobs_text into Estimate Knobs.
   Map possibly_fake, fake_reasons and watch_match into contact custom fields
   named Estimate Possibly Fake, Estimate Fake Reasons and Estimate Watch Match.
   Map utm_source to the contact source.
2. Add a note to the contact with the text of summary_text.
3. Add the contact tag: estimate-funnel-lead
4. Create an opportunity in my main sales pipeline, first stage, named
   "{{contact.first_name}} {{contact.last_name}} estimate", with the value set
   from estimate_low.
5. Send me an internal notification email with the lead's name, the estimate range
   (from Estimate Low Text and Estimate High Text), the services they picked and a
   link to the contact.
6. Send the lead an email immediately. Subject: "Your estimate:
   {{contact.estimate_low_text}} to {{contact.estimate_high_text}}, {{contact.first_name}}".
   The body restates the range (use the Estimate Low Text and Estimate High Text
   fields, never the number fields, so it reads "$4,500 to $9,500") and the
   timeline, says clearly that it is an estimate and not a final quote, and has
   exactly one link, to my booking calendar. No guarantee wording anywhere.
7. Wait 2 minutes.
8. Send the lead a short SMS that names my business, restates the range from
   Estimate Low Text and Estimate High Text, says the details are in their email,
   invites them to check the scope on a short call, has one booking link, and ends
   with "Reply STOP to opt out". Leave this step disabled until my A2P
   registration is approved. Never text a contact on DND.
9. If/Else: if the contact field Estimate Possibly Fake contains true, skip this
   step. Otherwise create a task assigned to me, due in 1 hour: "Call this
   estimate lead".
10. Wait 1 day. Send the lead an email with the subject "Did your estimate land,
    {{contact.first_name}}?" that asks whether the range looked about right.
11. Wait 2 more days. Send the email "A question about timing, {{contact.first_name}}".
12. Wait 4 more days. Send the email "How the call and the visit work".
13. Wait 7 more days. Send the email "Should I close your file,
    {{contact.first_name}}?" that asks one question: what held them back.
14. Add a goal: when the contact books an appointment, they leave this workflow.
    In the workflow settings, turn on stop on response, so a reply ends it too.
    A contact on DND, or a reply of STOP or unsubscribe, ends it and creates no task.

Every email to the lead ends with my name, my business, my postal address and the
line: Not interested? Reply "unsubscribe" and we will stop emailing you.
Do not add any other steps. Do not add a second booking link to any message. Do
not use the words guaranteed, final price or fixed price anywhere.
```

Then paste the four bodies from 3.7 into steps 10 to 13 yourself.

**📋 COPY THIS, for the hot lead workflow in 3.6 (a second new workflow):**

```
Build a workflow named "Estimate Hot Lead".

Trigger: Customer Replied on any channel, only for contacts with the tag
estimate-funnel-lead.

Steps, in this order:

1. If the contact is on DND for any channel, or the reply says STOP, stop,
   unsubscribe or cancel, end here. Never make a task for an opt-out.
2. If the contact already has the tag hot-lead, end here.
3. If the contact field Estimate Possibly Fake contains true, end here.
4. Add the tag hot-lead.
5. Create a task assigned to me, due in 1 hour: "Hot lead: call within the hour".
6. Send me an internal notification email: "Hot estimate lead:
   {{contact.first_name}} {{contact.last_name}}", with a link to the contact.
7. Move the contact's opportunity in my Estimates pipeline to the stage Hot.

Email opens never make a lead hot.

Do not send the lead anything from this workflow.
```

**📋 COPY THIS, for the booking messages in 3.8 (three more workflows):**

```
Build three workflows on my estimate call calendar.

Workflow 1, "Estimate Call Booked". Trigger: Customer Booked Appointment.
1. Send the contact an email right away with the subject
   "You are booked, {{contact.first_name}}". It confirms the appointment time and
   has one link: my call prep link (my funnel link with utm_source=booked in it).
2. If the appointment is more than 24 hours away, wait until 24 hours before it
   and send a short reminder email. Otherwise skip this step.
3. Wait until 1 hour before the appointment and send a reminder SMS that ends with
   "Reply STOP to opt out". If my A2P registration is not approved, or the contact
   is on DND for texts, send it as an email instead.

Workflow 2, "Estimate Call Missed". Trigger: Appointment Status is No Show.
1. Wait 1 hour, then send an email with one link, to my booking calendar.
2. Wait 2 days, then send one last email with the same single link.
Stop this workflow when the contact books again or replies.

Workflow 3, "Estimate Call Cancelled". Trigger: Appointment Status is Cancelled.
1. Send an email right away that asks one question, what made them cancel. No link.

Every email ends with my name, my business, my postal address and the line:
Not interested? Reply "unsubscribe" and we will stop emailing you.
No guarantee wording anywhere. No second booking link in any message.
```

Then paste the subjects and bodies from 3.8 into each message yourself.

Separately, once and outside this workflow (a workflow step would make one per lead): in **Tasks**, add a task for yourself named "Check your estimate funnel", toggle **Recurring Task** on and set it to repeat monthly, then say "check my funnel" to Claude when it comes due.

Then open every step it built and check it against Part 3. The two things it most often gets wrong are the custom field mapping (it invents field names) and the tag (it capitalises it). Fix those two and publish.

---

# PART 5. Test it before anyone real sees it

Walk this list. Every line, in order, before you put the link anywhere.

**Use a test email for every test lead:** your own address with `+test` before the @, for example `name+test@yourdomain.com`. If your email supports plus addressing (Gmail, Outlook and Google Workspace do), it still lands in your inbox, and it makes test contacts easy to find and filter out of your numbers. If it does not, use a second address you own.

- [ ] Your sending domain is set up in HighLevel (**Settings > Email Services**, or similar) and SPF, DKIM and DMARC all show as verified, before the first real lead. Without them, your follow-ups land in spam.
- [ ] You picked one name for the call and used it everywhere: the funnel button, the calendar, and every email. If the button says "free estimate call", the calendar and the emails say "free estimate call" too.
- [ ] Your funnel link opens on a phone, on mobile data, not just on your own wifi.
- [ ] You walked the whole funnel yourself as a customer and got a number.
- [ ] You walked it a second time picking "not sure" on every question. The range got wider and nothing broke.
- [ ] You walked it a third time picking the biggest, most urgent job. The number is one you would actually be happy to see a customer quote back at you.
- [ ] The estimate that appears on screen is the same as the one in the email. If they differ, check in this order: the field mapping in 3.2, then whether your host still has an old file (upload the new one), then old values left on the contact by an earlier test.
- [ ] The contact appeared in HighLevel with the tag `estimate-funnel-lead`.
- [ ] Every custom field on that contact has a value in it, except the ones that are empty on purpose (Estimate Fake Reasons on a clean lead, Phone if you left it blank). Any other empty field is almost always a broken mapping, fix it now.
- [ ] The opportunity appeared in the pipeline.
- [ ] Your internal notification arrived.
- [ ] If you set a backup email on the Publish tab, you pressed **Send a test alert email** and an email starting with "ALERT: your CRM did not confirm this lead" arrived (check spam). That tests the email route, not the switch over. The backup sends when your CRM cannot be reached or does not answer within 15 seconds, and with a HighLevel webhook also when HighLevel answers with an error. Neither route guarantees delivery, so check your CRM and inbox on your first real leads.
- [ ] The lead email arrived, **check the spam and promotions folders too**, and the booking link in it opens your real calendar.
- [ ] Every email to the lead ends with your real postal address (not the placeholder, not an empty line) and the unsubscribe line, and HighLevel's unsubscribe link works.
- [ ] The consent line shows under the contact step of your funnel.
- [ ] The SMS arrived, or you have confirmed A2P is still pending and the step is disabled.
- [ ] You booked a slot from that calendar link and the booking confirmation arrived, with your call prep link in it.
- [ ] You opened that call prep link as the booked test contact and sent it. You got a note and a notification, and no second opportunity, task, text or follow-up email.
- [ ] You rescheduled that test booking, and the reminders moved to the new time.
- [ ] You cancelled it, and the cancelled email arrived with its one question.
- [ ] You marked a test booking **No Show**, and the missed call email arrived an hour later.
- [ ] You replied **STOP** to the test SMS. The contact went on DND, nothing else was texted to it, and no hot lead task was made.
- [ ] You replied "unsubscribe" to a test follow-up email, the follow-up workflow stopped for that contact, and no hot lead task was made. Treat a reply like that as a request to stop: switch email to DND on the contact, and the workflow skips them from then on.
- [ ] You sent one lead with the name "Test" and a 555-0100 phone number. It arrived with Estimate Possibly Fake set to `true`, the email still went, and no "Call this estimate lead" task was made (full install; the quick install makes the task for every lead).
- [ ] Nothing in either message reads as a guaranteed or final price.
- [ ] Someone who is not you walked the funnel and did not ask you a single question to get through it.

That last line is the one people skip. It is also the one that finds the real problems.

**Then delete your test contacts** before you start counting anything, or your first week of numbers will be you. Search contacts for `+test` and they are all in one list.
