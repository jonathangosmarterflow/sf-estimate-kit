/* Estimate Funnel Kit - engine.js - v1.2
 * Pure functions. No dependencies. Runs in node and in the browser.
 * Nothing in here ever throws. If something is wrong you get plain English back.
 * Attaches to globalThis.EFK and also exports for node.
 */
(function (root) {
  'use strict';

  var VERSION = '1.2.1';

  /* The one email relay the kit supports (option "Email me each lead"). Facts
   * checked 2026-09-30: JSON POST from a browser, CORS open to any origin
   * including file:// and a null origin iframe, free plan 250 submissions a month.
   * It is a constant on purpose: a config can never point the relay elsewhere. */
  var RELAY_URL = 'https://api.web3forms.com/submit';
  var LEAD_MODES = ['webhook', 'email', 'none'];
  var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  /* ------------------------------------------------------------------ *
   * 0. Small helpers
   * ------------------------------------------------------------------ */

  function isObj(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
  function isArr(v) { return Array.isArray(v); }
  function isStr(v) { return typeof v === 'string'; }
  function isFiniteNum(v) { return typeof v === 'number' && isFinite(v); }

  function clamp(n, lo, hi) {
    if (!isFiniteNum(n)) return lo;
    if (n < lo) return lo;
    if (n > hi) return hi;
    return n;
  }

  /* Turn almost anything into a number. Handles "$1,200", "1 200 USD",
   * "from 450", "12.5 hrs", "40%", true/false, null. Returns null if hopeless. */
  function toNum(v) {
    if (isFiniteNum(v)) return v;
    if (typeof v === 'boolean') return v ? 1 : 0;
    if (v === null || v === undefined) return null;
    if (typeof v === 'object') return null;
    var s = String(v);
    s = s.replace(/[\u2212\u2013\u2014]/g, '-');           // unicode minus / dashes
    s = s.replace(/[^0-9eE+\-.,]/g, ' ');                   // drop currency words + symbols
    s = s.replace(/(\d)[ ,](?=\d{3}\b)/g, '$1');            // 1,200 and 1 200 -> 1200
    var m = s.match(/-?\d*\.?\d+(?:[eE][+-]?\d+)?/);
    if (!m) return null;
    var n = parseFloat(m[0]);
    return isFinite(n) ? n : null;
  }

  /* Pull every number out of a string, e.g. "150 to 650" -> [150, 650] */
  function allNums(v) {
    if (isFiniteNum(v)) return [v];
    if (!isStr(v)) return [];
    var s = String(v).replace(/(\d)[ ,](?=\d{3}\b)/g, '$1');
    var out = [], m, re = /-?\d*\.?\d+/g;
    while ((m = re.exec(s)) !== null) {
      var n = parseFloat(m[0]);
      if (isFinite(n)) out.push(n);
      if (out.length > 8) break;
    }
    return out;
  }

  function slugify(v, fallback) {
    var s = (v === null || v === undefined) ? '' : String(v);
    s = s.toLowerCase()
      .replace(/['\u2019]/g, '')
      .replace(/&/g, ' and ')
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 48);
    return s || (fallback || 'item');
  }

  function titleCase(s) {
    s = String(s || '').replace(/[_-]+/g, ' ').trim();
    if (!s) return '';
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function deepClone(v, seen) {
    seen = seen || [];
    if (v === null || typeof v !== 'object') return v;
    for (var i = 0; i < seen.length; i++) if (seen[i] === v) return null; // cycle guard
    seen = seen.concat([v]);
    if (isArr(v)) {
      var a = [];
      for (var j = 0; j < v.length; j++) a.push(deepClone(v[j], seen));
      return a;
    }
    var o = {};
    for (var k in v) if (Object.prototype.hasOwnProperty.call(v, k)) o[k] = deepClone(v[k], seen);
    return o;
  }

  function median(list) {
    if (!list || !list.length) return null;
    var a = list.slice().sort(function (x, y) { return x - y; });
    var mid = Math.floor(a.length / 2);
    return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
  }

  function uniqPush(arr, msg) {
    if (!msg) return;
    for (var i = 0; i < arr.length; i++) if (arr[i] === msg) return;
    arr.push(msg);
  }

  /* ------------------------------------------------------------------ *
   * 1. Lenient JSON reader (the Config Doctor's front door)
   * ------------------------------------------------------------------ */

  var QUOTE_PAIRS = { '"': '"', "'": "'", '`': '`', '\u201c': '\u201d', '\u2018': '\u2019', '\u201d': '\u201d', '\u2019': '\u2019' };

  function isQuote(ch) { return Object.prototype.hasOwnProperty.call(QUOTE_PAIRS, ch); }

  /* Find the first balanced {...} in arbitrary text, ignoring braces that live
   * inside strings or comments. Returns the substring, or '' if there is no '{'. */
  function firstBalanced(text) {
    var s = String(text || '');
    var start = -1, depth = 0, i = 0, n = s.length;
    while (i < n) {
      var ch = s[i];
      if (start === -1) {
        if (ch === '{') { start = i; depth = 1; i++; continue; }
        i++; continue;
      }
      if (isQuote(ch)) {
        var close = QUOTE_PAIRS[ch];
        i++;
        while (i < n) {
          if (s[i] === '\\') { i += 2; continue; }
          if (s[i] === close) { i++; break; }
          i++;
        }
        continue;
      }
      if (ch === '/' && s[i + 1] === '/') { while (i < n && s[i] !== '\n') i++; continue; }
      if (ch === '#') { while (i < n && s[i] !== '\n') i++; continue; }
      if (ch === '/' && s[i + 1] === '*') { i += 2; while (i < n && !(s[i] === '*' && s[i + 1] === '/')) i++; i += 2; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') { depth--; if (depth === 0) return s.slice(start, i + 1); }
      i++;
    }
    if (start !== -1) return s.slice(start); // truncated: parser auto-closes
    return '';
  }

  /* A forgiving JSON reader. Accepts: comments, trailing commas, missing commas,
   * single quotes, smart quotes, unquoted keys, unquoted bare-word values,
   * NaN / Infinity / undefined, numbers written as "$1,200", truncated tails. */
  function lenientParse(text, notes) {
    var s = String(text || '');
    var i = 0, n = s.length;
    notes = notes || [];

    function ws() {
      while (i < n) {
        var ch = s[i];
        if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r' || ch === '\ufeff' || ch === '\u00a0') { i++; continue; }
        if (ch === '/' && s[i + 1] === '/') { while (i < n && s[i] !== '\n') i++; continue; }
        if (ch === '#') { while (i < n && s[i] !== '\n') i++; continue; }
        if (ch === '/' && s[i + 1] === '*') { i += 2; while (i < n && !(s[i] === '*' && s[i + 1] === '/')) i++; i += 2; continue; }
        break;
      }
    }

    function readString() {
      var open = s[i], close = QUOTE_PAIRS[open];
      i++;
      var out = '';
      while (i < n) {
        var ch = s[i];
        if (ch === '\\') {
          var nx = s[i + 1];
          if (nx === 'n') out += '\n';
          else if (nx === 't') out += '\t';
          else if (nx === 'r') out += '\r';
          else if (nx === 'b') out += '\b';
          else if (nx === 'f') out += '\f';
          else if (nx === 'u') { var hex = s.slice(i + 2, i + 6); var cp = parseInt(hex, 16); out += isFinite(cp) ? String.fromCharCode(cp) : ''; i += 6; continue; }
          else out += (nx === undefined ? '' : nx);
          i += 2; continue;
        }
        if (ch === close) { i++; return out; }
        if ((open === '"' || open === "'") && ch === '\n') { i++; return out; } // unterminated line string
        out += ch; i++;
      }
      return out;
    }

    function readBareWord() {
      var start = i;
      while (i < n && /[A-Za-z0-9_$.+\-%\/#]/.test(s[i])) i++;
      return s.slice(start, i);
    }

    function readValue(depth) {
      ws();
      if (i >= n) return undefined;
      var ch = s[i];
      if (ch === '{') return readObject(depth + 1);
      if (ch === '[') return readArray(depth + 1);
      if (isQuote(ch)) return readString();
      if (ch === ',' || ch === '}' || ch === ']' || ch === ':') return undefined;
      var word = readBareWord();
      if (word === '') { i++; return undefined; }
      var lw = word.toLowerCase();
      if (lw === 'true') return true;
      if (lw === 'false') return false;
      if (lw === 'null' || lw === 'none' || lw === 'nil') return null;
      if (lw === 'undefined') { uniqPush(notes, 'Some values came back as "undefined" and were left empty.'); return null; }
      if (lw === 'nan' || lw === '-nan') { uniqPush(notes, 'A value came back as NaN (not a number) and was left empty.'); return null; }
      if (lw === 'infinity' || lw === '-infinity') { uniqPush(notes, 'A value came back as Infinity and was left empty.'); return null; }
      if (/^[+-]?\$?\d*\.?\d+(?:[eE][+-]?\d+)?%?$/.test(word)) {
        var num = toNum(word);
        return num === null ? word : num;
      }
      return word; // bare word treated as text
    }

    function readObject(depth) {
      var obj = {}, seenKeys = {};
      i++; // consume {
      if (depth > 40) { uniqPush(notes, 'The pasted text was nested very deeply, so the deepest parts were skipped.'); return obj; }
      while (i < n) {
        ws();
        if (i >= n) break;
        if (s[i] === '}') { i++; break; }
        if (s[i] === ',' || s[i] === ':') { i++; continue; }
        var key;
        if (isQuote(s[i])) key = readString();
        else key = readBareWord();
        if (key === '') { i++; continue; }
        ws();
        if (s[i] === ':' || s[i] === '=') i++;
        var val = readValue(depth);
        if (Object.prototype.hasOwnProperty.call(seenKeys, key)) {
          uniqPush(notes, 'The setting "' + key + '" was listed more than once. We kept the last one.');
          if (val === undefined || val === null || val === '') { continue; }
        }
        seenKeys[key] = 1;
        if (val !== undefined) obj[key] = val;
      }
      return obj;
    }

    function readArray(depth) {
      var arr = [];
      i++; // consume [
      if (depth > 40) return arr;
      while (i < n) {
        ws();
        if (i >= n) break;
        if (s[i] === ']') { i++; break; }
        if (s[i] === ',') { i++; continue; }
        var v = readValue(depth);
        if (v === undefined) { if (i < n && s[i] !== ']' && s[i] !== ',') i++; continue; }
        arr.push(v);
        if (arr.length > 500) { uniqPush(notes, 'That list was very long, so we kept the first 500 items.'); break; }
      }
      return arr;
    }

    ws();
    var out = readValue(0);
    return out;
  }

  /* ------------------------------------------------------------------ *
   * 2. Defaults
   * ------------------------------------------------------------------ */

  var KNOB_KEYS = ['range_width', 'price_level', 'safety_buffer', 'rush_premium', 'rounding', 'detail_shown'];
  var KNOB_DEFAULTS = { range_width: 50, price_level: 50, safety_buffer: 30, rush_premium: 50, rounding: 60, detail_shown: 50 };
  var ALLOWED_FIELDS = ['name', 'email', 'phone', 'address', 'message', 'company'];

  function defaults() {
    return {
      kit_version: VERSION,
      business: {
        name: 'Your business',
        niche: 'generic-service',
        tagline: 'Get a real price range in about a minute',
        currency: 'USD',
        currency_symbol: '$',
        unit: 'price',
        hourly_rate: null,
        booking_url: '',
        logo_url: '',
        brand_color: '#1d4ed8',
        phone: '',
        service_area: ''
      },
      services: [],
      allow_multiple_services: true,
      questions: [],
      knobs: {
        range_width: 50, price_level: 50, safety_buffer: 30,
        rush_premium: 50, rounding: 60, detail_shown: 50
      },
      toggles: { contact_before_result: false, show_timeline: true, show_drivers: true, timeline_style: 'about' },
      calibration: { per_service: {}, last_trained: null, rounds: 0 },
      lead_capture: { destination: 'none', webhook_url: '', email_key: '', alert_email_key: '', fields: ['name', 'email', 'phone'], consent_text: '', watch_list: [] },
      result_copy: {
        headline: 'Your estimated range',
        disclaimer: 'This is an estimate, not a final quote. Your exact price depends on the details, which we go through with you before any work starts.',
        cta_label: 'Book your free call'
      },
      demo_banner: false,
      demo_banner_url: ''
    };
  }

  /* ------------------------------------------------------------------ *
   * 3. The Config Doctor
   * ------------------------------------------------------------------ */

  var HEX_RE = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
  var NAMED_COLORS = {
    blue: '#1d4ed8', red: '#dc2626', green: '#15803d', orange: '#ea580c', purple: '#7c3aed',
    teal: '#0d9488', black: '#111827', navy: '#1e3a8a', gold: '#b45309', gray: '#374151', grey: '#374151'
  };

  function normalizeColor(v, repairs) {
    if (!isStr(v) || !v.trim()) return null;
    var s = v.trim();
    if (HEX_RE.test(s)) {
      if (s.length === 4) s = '#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3];
      return s.toLowerCase();
    }
    if (/^[0-9a-fA-F]{6}$/.test(s)) return ('#' + s).toLowerCase();
    var low = s.toLowerCase().replace(/[^a-z]/g, '');
    if (NAMED_COLORS[low]) {
      uniqPush(repairs, 'Your brand color was written as "' + s + '". We used the closest standard color. You can change it on the Your business tab.');
      return NAMED_COLORS[low];
    }
    return null;
  }

  function checkUrl(v, label, repairs, errors, required, warnings) {
    if (!isStr(v)) v = '';
    var s = v.trim();
    if (!s) {
      if (required) uniqPush(errors, 'Your ' + label + ' is empty. Open the Your business tab and paste the link people use to book you.');
      return '';
    }
    if (/^\/\//.test(s)) s = 'https:' + s;
    if (/^http:\/\//i.test(s)) {
      uniqPush(repairs, 'Your ' + label + ' started with http:// so we changed it to https://. Click "Test this link" to be sure it opens.');
      s = 'https://' + s.slice(7);
    }
    if (!/^https:\/\//i.test(s)) {
      if (/^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}(\/|$)/i.test(s)) {
        uniqPush(repairs, 'Your ' + label + ' was missing https:// so we added it. Click "Test this link" to be sure it opens.');
        s = 'https://' + s;
      } else {
        uniqPush(errors, 'Your ' + label + ' does not look like a web address ("' + s.slice(0, 60) + '"). Open the Your business tab and paste the full link, starting with https://.');
        return '';
      }
    }
    if (/[\s"'<>`\\]/.test(s) || !/^https:\/\/[^\/?#]+\.[^\/?#]+/i.test(s)) {
      uniqPush(errors, 'Your ' + label + ' does not look like a web address ("' + s.slice(0, 60).replace(/[<>"]/g, '') + '"). Open the Your business tab and paste the full link, starting with https://.');
      return '';
    }
    if (isPlaceholderUrl(s)) {
      uniqPush(warnings || errors, 'Your ' + label + ' was a placeholder link (' + hostOf(s) + '), so we left it empty. Replace it with the real link you use today.');
      return '';
    }
    return s;
  }

  /* An AI loves to keep or invent example.com. Those links go nowhere, so the
   * doctor treats them like an invalid link and blanks them. */
  function hostOf(s) {
    var m = /^https?:\/\/([^\/?#:]+)/i.exec(String(s || ''));
    return m ? m[1].toLowerCase() : '';
  }
  function isPlaceholderUrl(s) {
    var h = hostOf(s);
    if (!h) return false;
    if (/(^|\.)example\.(com|org|net)$/.test(h)) return true;
    if (/(^|\.)(example|invalid|localhost)$/.test(h)) return true;
    if (/yourdomain|your-domain|yoursite|your-site|yourwebsite|placeholder|changeme|lorem/.test(h)) return true;
    return /yourdomain|your-domain|placeholder|changeme|your-booking-link|your-link-here/i.test(String(s));
  }

  /* Looks like a modifier, not a service? */
  function looksLikeModifier(raw) {
    if (!isObj(raw)) return false;
    var hasRange = toNum(raw.lo) !== null || toNum(raw.hi) !== null || toNum(raw.price) !== null || toNum(raw.low) !== null;
    if (hasRange) return false;
    if (isObj(raw.effect)) return true;
    var t = isStr(raw.type) ? raw.type.toLowerCase() : '';
    if (t === 'multiply' || t === 'multiplier' || t === 'add' || t === 'modifier' || t === 'widen') return true;
    if (toNum(raw.multiplier) !== null || toNum(raw.factor) !== null) return true;
    return false;
  }

  function readEffect(raw, repairs, where) {
    var e = { type: 'none', value: 0 };
    if (raw === null || raw === undefined) return e;
    if (isFiniteNum(raw) || isStr(raw)) {
      var n0 = toNum(raw);
      if (n0 === null) return e;
      if (n0 > 0 && n0 < 5) { e.type = 'multiply'; e.value = n0; }
      else { e.type = 'add'; e.value = n0; }
      return e;
    }
    if (!isObj(raw)) return e;
    var t = isStr(raw.type) ? raw.type.toLowerCase().trim() : '';
    if (t === 'multiplier' || t === 'multiply' || t === 'x' || t === 'percent') t = 'multiply';
    if (t === 'add' || t === 'flat' || t === 'plus' || t === 'addition') t = 'add';
    if (t === 'widen' || t === 'wider' || t === 'unsure' || t === 'not_sure') t = 'widen';
    if (t !== 'multiply' && t !== 'add' && t !== 'widen' && t !== 'none') {
      var guess = toNum(raw.value);
      if (guess !== null && guess > 0 && guess < 5) t = 'multiply';
      else if (guess !== null) t = 'add';
      else t = 'none';
    }
    var v = toNum(raw.value);
    if (v === null) v = toNum(raw.amount);
    if (v === null) v = toNum(raw.factor);
    if (v === null) v = (t === 'multiply' ? 1 : 0);
    if (t === 'multiply') {
      if (v > 5 && v <= 100) {
        uniqPush(repairs, 'An answer ' + where + ' was set to multiply the price by ' + v + ' times. That reads like a percent, so we used ' + (1 + v / 100).toFixed(2) + ' instead.');
        v = 1 + v / 100;
      }
      var cv = clamp(v, 0.5, 3.0);
      if (Math.abs(cv - v) > 0.0001) {
        uniqPush(repairs, 'An answer ' + where + ' would have changed the price by ' + v + ' times. We limited it to ' + cv + ' times so no customer ever sees a wild number.');
      }
      v = cv;
    } else if (t === 'widen') {
      var wv = clamp(v, 0, 0.5);
      if (Math.abs(wv - v) > 0.0001) uniqPush(repairs, 'A "not sure" answer ' + where + ' widened the range too far. We limited it.');
      v = wv;
    } else if (t === 'add') {
      if (!isFiniteNum(v)) v = 0;
      if (Math.abs(v) > 1000000) { v = v < 0 ? -1000000 : 1000000; uniqPush(repairs, 'A flat amount ' + where + ' was extremely large, so we limited it.'); }
    } else {
      v = 0;
    }
    e.type = t; e.value = v;
    if (isStr(raw.label) && raw.label.trim()) e.label = raw.label.trim();
    return e;
  }

  /* What the doctor hands back when the paste was unusable: a valid, empty-ish
   * config with one placeholder row, so the Studio always has something to show. */
  function skeleton() {
    var d = defaults();
    d.services = [{ key: 'main_service', label: 'Main service', lo: 250, hi: 900, days_lo: 1, days_hi: 3, help: '', example_data: true }];
    return d;
  }

  function doctor(input) {
    var repairs = [], warnings = [], errors = [], setup = [];
    var out;
    try {
      out = doctorInner(input, repairs, warnings, errors, setup);
    } catch (err) {
      out = skeleton();
      uniqPush(errors, 'We could not read that config at all. Go back to the Niche tab, pick a preset, and try again. (Details: ' + String(err && err.message ? err.message : err).slice(0, 120) + ')');
    }
    return {
      config: out,
      repairs: repairs,
      warnings: warnings,
      errors: errors,
      /* additive: things that are not wrong, just not finished yet. The Publish
       * checklist owns these, so a shipped preset stays warning free. */
      setup: setup,
      ok: errors.length === 0
    };
  }

  function doctorInner(input, repairs, warnings, errors, setup) {
    setup = setup || [];
    var raw = null;

    if (isStr(input)) {
      var text = input;
      if (!text.trim()) {
        uniqPush(errors, 'Nothing was pasted. Copy your AI answer and paste it into the box, then press Check it.');
        return skeleton();
      }
      var fenced = text.match(/```(?:json|JSON|js|javascript)?\s*([\s\S]*?)```/);
      var body = fenced ? fenced[1] : text;
      var block = firstBalanced(body);
      if (!block) block = firstBalanced(text);
      if (!block) {
        uniqPush(errors, 'We could not find any settings in what you pasted. Your AI answered in plain words instead of the settings block. Ask it: "Reply with the JSON config only, nothing else." then paste again.');
        return skeleton();
      }
      /* a code block, a greeting or a sign off around the settings is normal and
       * expected, so it is handled silently. Only real changes get reported. */
      var notes = [];
      raw = lenientParse(block, notes);
      for (var ni = 0; ni < notes.length; ni++) uniqPush(repairs, notes[ni]);
      if (!isObj(raw)) {
        uniqPush(errors, 'What you pasted was not a settings block. Ask your AI: "Reply with the JSON config only, nothing else." then paste again.');
        return skeleton();
      }
      try { JSON.parse(block); } catch (e2) {
        uniqPush(repairs, 'The settings had small formatting mistakes (things like extra commas or curly quotes). We fixed them.');
      }
    } else if (isArr(input)) {
      var found = null;
      for (var ai = 0; ai < input.length; ai++) {
        if (isObj(input[ai])) { found = input[ai]; break; }
      }
      if (found) {
        uniqPush(repairs, 'Your settings arrived inside a list. We used the first set of settings in it.');
        raw = found;
      } else {
        uniqPush(errors, 'Your settings arrived as a list with nothing usable in it. Pick a preset on the Niche tab and start from there.');
        return skeleton();
      }
    } else if (isObj(input)) {
      raw = deepClone(input);
    } else {
      uniqPush(errors, 'There were no settings to read. Pick a preset on the Niche tab to start.');
      return skeleton();
    }

    /* Unwrap {"config": {...}} style answers */
    var topKeys = ['business', 'services', 'questions', 'knobs', 'toggles', 'result_copy'];
    var hasTop = false;
    for (var tk = 0; tk < topKeys.length; tk++) if (raw[topKeys[tk]] !== undefined) hasTop = true;
    if (!hasTop) {
      for (var rk in raw) {
        if (!Object.prototype.hasOwnProperty.call(raw, rk)) continue;
        if (isObj(raw[rk])) {
          for (var tk2 = 0; tk2 < topKeys.length; tk2++) {
            if (raw[rk][topKeys[tk2]] !== undefined) { raw = raw[rk]; hasTop = true; break; }
          }
        }
        if (hasTop) { uniqPush(repairs, 'Your settings were wrapped inside another box. We unwrapped them.'); break; }
      }
    }

    var d = defaults();
    var cfg = defaults();

    /* ---- business ---- */
    var b = isObj(raw.business) ? raw.business : (isObj(raw.company) ? raw.company : {});
    if (!isObj(raw.business) && !isObj(raw.company) && (raw.business_name || raw.name)) b = raw;
    var biz = cfg.business;
    biz.name = isStr(b.name) && b.name.trim() ? b.name.trim().slice(0, 90)
      : (isStr(b.business_name) && b.business_name.trim() ? b.business_name.trim().slice(0, 90) : '');
    if (!biz.name) { biz.name = d.business.name; uniqPush(warnings, 'We could not find your business name. Add it on the Your business tab so customers know whose price they are seeing.'); }
    biz.niche = slugify(b.niche || b.industry || raw.niche, 'generic-service');
    biz.tagline = isStr(b.tagline) ? b.tagline.trim().slice(0, 140) : d.business.tagline;
    if (!biz.tagline) biz.tagline = d.business.tagline;

    var cur = isStr(b.currency) ? b.currency.trim().toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3) : '';
    biz.currency = cur.length === 3 ? cur : 'USD';
    if (isStr(b.currency) && biz.currency !== b.currency.trim().toUpperCase()) {
      uniqPush(repairs, 'Your currency code was written as "' + String(b.currency).slice(0, 12) + '". We used ' + biz.currency + '. Change it on the Your business tab if that is wrong.');
    }
    biz.currency_symbol = isStr(b.currency_symbol) && b.currency_symbol.trim() ? b.currency_symbol.trim().slice(0, 4)
      : ({ USD: '$', CAD: '$', AUD: '$', NZD: '$', GBP: '\u00a3', EUR: '\u20ac', INR: '\u20b9', ZAR: 'R', MXN: '$', BRL: 'R$', PHP: '\u20b1', SGD: '$' }[biz.currency] || '$');

    var unit = isStr(b.unit) ? b.unit.trim().toLowerCase() : '';
    if (unit === 'hour' || unit === 'hrs' || unit === 'hourly') unit = 'hours';
    if (unit === 'prices' || unit === 'money' || unit === 'dollars' || unit === 'fixed') unit = 'price';
    if (unit !== 'price' && unit !== 'hours' && unit !== 'both') {
      if (unit) uniqPush(repairs, 'We did not understand the setting "' + unit + '" for price or hours, so we used price. You can switch it on the Your business tab.');
      unit = 'price';
    }
    biz.unit = unit;

    var rate = toNum(b.hourly_rate);
    if (rate !== null && rate <= 0) rate = null;
    if (rate !== null) rate = clamp(rate, 1, 100000);
    biz.hourly_rate = rate;
    if ((unit === 'both') && rate === null) {
      uniqPush(errors, 'You chose to show hours and price, but there is no hourly rate. Add your hourly rate on the Your business tab.');
    }

    biz.booking_url = checkUrl(b.booking_url || b.booking_link || b.calendar_url, 'booking link', repairs, errors, false, setup);
    if (!biz.booking_url) uniqPush(setup, 'There is no booking link yet. Add it on the Your business tab, or the button at the end of your funnel goes nowhere.');

    if (isStr(b.logo_url) && b.logo_url.trim()) {
      var logoErrs = [];
      var logo = checkUrl(b.logo_url, 'logo link', repairs, logoErrs, false, logoErrs);
      if (logoErrs.length) {
        uniqPush(repairs, 'Your logo link did not look like a real web address, so we left the logo off and show your business name instead.');
        logo = '';
      }
      biz.logo_url = logo;
    } else biz.logo_url = '';

    var col = normalizeColor(b.brand_color || b.color, repairs);
    if (!col && (b.brand_color || b.color)) {
      uniqPush(repairs, 'We did not recognise your brand color, so we used the default blue. Pick your color on the Your business tab.');
    }
    biz.brand_color = col || d.business.brand_color;
    biz.phone = isStr(b.phone) ? b.phone.trim().slice(0, 40) : '';
    biz.service_area = isStr(b.service_area) ? b.service_area.trim().slice(0, 120) : '';

    /* ---- services ---- */
    var rawServices = isArr(raw.services) ? raw.services : [];
    if (!isArr(raw.services) && isObj(raw.services)) {
      rawServices = [];
      for (var sk in raw.services) if (Object.prototype.hasOwnProperty.call(raw.services, sk)) {
        var sv = raw.services[sk];
        if (isObj(sv)) { sv = deepClone(sv); if (!sv.key) sv.key = sk; if (!sv.label) sv.label = titleCase(sk); rawServices.push(sv); }
      }
      if (rawServices.length) uniqPush(repairs, 'Your services were written as a list of names instead of rows. We turned them into rows.');
    }

    var services = [], usedKeys = {}, movedModifiers = [];
    for (var si = 0; si < rawServices.length && services.length < 40; si++) {
      var r = rawServices[si];
      if (isStr(r)) r = { label: r };
      if (!isObj(r)) continue;

      if (looksLikeModifier(r)) { movedModifiers.push(r); continue; }

      var label = isStr(r.label) && r.label.trim() ? r.label.trim()
        : (isStr(r.name) && r.name.trim() ? r.name.trim() : titleCase(r.key || ''));
      label = label.slice(0, 80);
      if (!label) label = 'Service ' + (services.length + 1);

      var lo = toNum(r.lo); if (lo === null) lo = toNum(r.low); if (lo === null) lo = toNum(r.min); if (lo === null) lo = toNum(r.price_low);
      var hi = toNum(r.hi); if (hi === null) hi = toNum(r.high); if (hi === null) hi = toNum(r.max); if (hi === null) hi = toNum(r.price_high);
      if (lo === null || hi === null) {
        var pool = allNums(r.price !== undefined ? r.price : (r.range !== undefined ? r.range : r.cost));
        if (pool.length >= 2) { if (lo === null) lo = pool[0]; if (hi === null) hi = pool[1]; }
        else if (pool.length === 1) { if (lo === null) lo = pool[0]; if (hi === null) hi = pool[0] * 1.6; }
      }
      if (lo === null && hi !== null) lo = hi * 0.6;
      if (hi === null && lo !== null) hi = lo * 1.6;
      if (lo === null && hi === null) {
        uniqPush(repairs, 'The service "' + label + '" had no price on it. We put a placeholder in. Open the Prices tab and type your own low and high.');
        lo = biz.unit === 'price' ? 100 : 2;
        hi = biz.unit === 'price' ? 500 : 6;
      }
      if (lo > hi) {
        uniqPush(repairs, '"' + label + '" had a low of ' + lo + ' sitting above its high of ' + hi + ', so we swapped them around for you.');
        var tmp = lo; lo = hi; hi = tmp;
      }
      if (lo <= 0) {
        uniqPush(repairs, 'The low price on "' + label + '" was zero or less. We set it just above zero. Open the Prices tab and type your real low.');
        lo = biz.unit === 'price' ? 1 : 0.25;
        if (hi <= lo) hi = lo * 2;
      }
      lo = clamp(lo, 0.01, 10000000); hi = clamp(hi, lo, 10000000);

      var key = slugify(r.key || label, 'service_' + (services.length + 1));
      if (usedKeys[key]) {
        var bump = 2;
        while (usedKeys[key + '_' + bump]) bump++;
        uniqPush(repairs, 'Two of your services shared the id "' + key + '", which would have made them share a price. We renamed the second one to "' + key + '_' + bump + '" so they stay separate.');
        key = key + '_' + bump;
      }
      usedKeys[key] = 1;

      var dlo = toNum(r.days_lo); if (dlo === null) dlo = 1;
      var dhi = toNum(r.days_hi); if (dhi === null) dhi = Math.max(dlo, 2);
      dlo = Math.round(clamp(dlo, 0, 365)); dhi = Math.round(clamp(dhi, 0, 365));
      if (dlo > dhi) { var td = dlo; dlo = dhi; dhi = td; }

      services.push({
        key: key,
        label: label,
        lo: Math.round(lo * 100) / 100,
        hi: Math.round(hi * 100) / 100,
        days_lo: dlo,
        days_hi: dhi,
        help: isStr(r.help) ? r.help.trim().slice(0, 160) : '',
        example_data: r.example_data === false ? false : (r.example_data === true ? true : true)
      });
    }

    if (!services.length) {
      uniqPush(errors, 'There are no services yet. Open the Prices tab and add at least one thing you sell, with a low and a high price.');
      services.push({ key: 'main_service', label: 'Main service', lo: biz.unit === 'price' ? 250 : 4, hi: biz.unit === 'price' ? 900 : 10, days_lo: 1, days_hi: 3, help: '', example_data: true });
    }
    cfg.services = services;
    cfg.allow_multiple_services = raw.allow_multiple_services === false ? false : true;

    /* ---- questions ---- */
    var validKeys = {};
    for (var vk = 0; vk < services.length; vk++) validKeys[services[vk].key] = services[vk].label;

    var rawQuestions = isArr(raw.questions) ? raw.questions : [];
    if (!isArr(raw.questions) && isObj(raw.questions)) {
      rawQuestions = [];
      for (var qk in raw.questions) if (Object.prototype.hasOwnProperty.call(raw.questions, qk)) {
        var qv = raw.questions[qk];
        if (isObj(qv)) { qv = deepClone(qv); if (!qv.key) qv.key = qk; rawQuestions.push(qv); }
      }
    }

    /* Any modifier we pulled out of services becomes its own yes/no question. */
    for (var mi = 0; mi < movedModifiers.length; mi++) {
      var mo = movedModifiers[mi];
      var mlabel = isStr(mo.label) && mo.label.trim() ? mo.label.trim() : (isStr(mo.name) ? mo.name.trim() : 'Extra');
      var meff = isObj(mo.effect) ? mo.effect : { type: (isStr(mo.type) ? mo.type : 'multiply'), value: (mo.value !== undefined ? mo.value : (mo.multiplier !== undefined ? mo.multiplier : mo.factor)) };
      rawQuestions.push({
        key: slugify(mo.key || mlabel, 'extra_' + (mi + 1)),
        label: 'Does this job need ' + mlabel.toLowerCase() + '?',
        type: 'single',
        applies_to: [],
        options: [
          { label: 'Yes', effect: meff },
          { label: 'No', effect: { type: 'none', value: 0 } },
          { label: 'Not sure', effect: { type: 'widen', value: 0.1 } }
        ]
      });
      uniqPush(repairs, 'We moved "' + mlabel + '" out of your services list. It changes a price instead of being something you sell, so it is now a question.');
    }

    var questions = [], usedQKeys = {}, hasUrgency = false;
    for (var qi = 0; qi < rawQuestions.length && questions.length < 30; qi++) {
      var q = rawQuestions[qi];
      if (isStr(q)) q = { label: q, type: 'single', options: [{ label: 'Yes' }, { label: 'No' }] };
      if (!isObj(q)) continue;

      var qlabel = isStr(q.label) && q.label.trim() ? q.label.trim().slice(0, 160)
        : (isStr(q.question) ? q.question.trim().slice(0, 160) : titleCase(q.key || ''));
      if (!qlabel) continue;

      var qtype = isStr(q.type) ? q.type.trim().toLowerCase() : 'single';
      if (qtype === 'radio' || qtype === 'select' || qtype === 'choice' || qtype === 'dropdown' || qtype === 'one') qtype = 'single';
      if (qtype === 'checkbox' || qtype === 'multiple' || qtype === 'multiselect' || qtype === 'many') qtype = 'multi';
      if (qtype === 'num' || qtype === 'integer' || qtype === 'count' || qtype === 'quantity') qtype = 'number';
      if (qtype !== 'single' && qtype !== 'multi' && qtype !== 'number') qtype = 'single';

      var qkey = slugify(q.key || qlabel, 'question_' + (questions.length + 1));
      if (usedQKeys[qkey]) {
        var qb = 2; while (usedQKeys[qkey + '_' + qb]) qb++;
        qkey = qkey + '_' + qb;
        uniqPush(repairs, 'Two questions shared the same id. We renamed one so both still work.');
      }
      usedQKeys[qkey] = 1;

      var applies = [];
      var rawApplies = isArr(q.applies_to) ? q.applies_to : (isStr(q.applies_to) ? [q.applies_to] : []);
      var droppedApplies = 0;
      for (var pi = 0; pi < rawApplies.length; pi++) {
        var ak = slugify(rawApplies[pi], '');
        if (validKeys[ak]) { if (applies.indexOf(ak) === -1) applies.push(ak); }
        else if (ak) droppedApplies++;
      }
      if (droppedApplies) {
        uniqPush(repairs, 'The question "' + qlabel + '" pointed at ' + droppedApplies + ' service(s) that do not exist. We removed those links.');
      }
      if (rawApplies.length && !applies.length) {
        uniqPush(repairs, 'The question "' + qlabel + '" was linked only to services that do not exist, so it now shows for every service.');
      }

      var qq = { key: qkey, label: qlabel, type: qtype, applies_to: applies };

      var role = isStr(q.role) ? q.role.trim().toLowerCase() : '';
      if (role === 'urgency' || /urgen|how soon|rush|emergen|when do you need/i.test(qlabel)) {
        qq.role = 'urgency';
        hasUrgency = true;
      }
      if (isStr(q.help) && q.help.trim()) qq.help = q.help.trim().slice(0, 160);

      if (qtype === 'number') {
        var mn = toNum(q.min); var mx = toNum(q.max); var st = toNum(q.step);
        qq.min = mn === null ? 0 : clamp(mn, 0, 1000000);
        qq.max = mx === null ? Math.max(qq.min + 10, 10) : clamp(mx, qq.min + 1, 1000000);
        qq.step = st === null || st <= 0 ? 1 : clamp(st, 0.01, 1000);
        qq.per_unit_effect = readEffect(q.per_unit_effect || q.effect, repairs, 'on "' + qlabel + '"');
        if (qq.per_unit_effect.type === 'widen') qq.per_unit_effect = { type: 'none', value: 0 };
        questions.push(qq);
        continue;
      }

      var rawOpts = isArr(q.options) ? q.options : (isArr(q.choices) ? q.choices : (isArr(q.answers) ? q.answers : []));
      var opts = [];
      for (var oi = 0; oi < rawOpts.length && opts.length < 20; oi++) {
        var o = rawOpts[oi];
        if (isStr(o) || isFiniteNum(o)) o = { label: String(o) };
        if (!isObj(o)) continue;
        var olabel = isStr(o.label) && o.label.trim() ? o.label.trim().slice(0, 90)
          : (isStr(o.text) ? o.text.trim().slice(0, 90) : (isStr(o.value) ? o.value.trim().slice(0, 90) : ''));
        if (!olabel) continue;
        var eff = readEffect(o.effect !== undefined ? o.effect : (o.multiplier !== undefined ? o.multiplier : o.value), repairs, 'under "' + qlabel + '"');
        if (/not sure|unsure|don'?t know|no idea|not certain/i.test(olabel) && eff.type === 'none') {
          eff = { type: 'widen', value: 0.10 };
          uniqPush(repairs, 'The "' + olabel + '" answer under "' + qlabel + '" did nothing. We made it widen the range a little, which is what a not-sure answer should do.');
        }
        opts.push({ label: olabel, effect: eff });
      }
      if (opts.length < 2) {
        uniqPush(repairs, 'The question "' + qlabel + '" had fewer than two answers, so we left it out. Add it back on the Prices tab if you need it.');
        continue;
      }
      qq.options = opts;
      questions.push(qq);
    }
    cfg.questions = questions;
    if (!hasUrgency) uniqPush(setup, 'You have no "how soon do you need this" question. Adding one lets the Rush premium knob do its job.');

    /* ---- knobs ---- */
    var rawKnobs = isObj(raw.knobs) ? raw.knobs : {};
    for (var ki = 0; ki < KNOB_KEYS.length; ki++) {
      var kk = KNOB_KEYS[ki];
      var kv = toNum(rawKnobs[kk]);
      if (kv === null) { cfg.knobs[kk] = KNOB_DEFAULTS[kk]; continue; }
      if (kv > 0 && kv <= 1 && kv !== 1) { kv = kv * 100; uniqPush(repairs, 'The ' + kk.replace(/_/g, ' ') + ' knob was set as a fraction. We changed it to the 0 to 100 scale.'); }
      var ck = Math.round(clamp(kv, 0, 100));
      if (Math.abs(ck - kv) > 0.5) uniqPush(repairs, 'The ' + kk.replace(/_/g, ' ') + ' knob was outside 0 to 100. We moved it to ' + ck + '.');
      cfg.knobs[kk] = ck;
    }

    /* ---- toggles ---- */
    var rawTog = isObj(raw.toggles) ? raw.toggles : {};
    cfg.toggles.contact_before_result = truthy(rawTog.contact_before_result, false);
    cfg.toggles.show_timeline = truthy(rawTog.show_timeline, true);
    cfg.toggles.show_drivers = truthy(rawTog.show_drivers, true);
    /* v1.2: "about" shows one figure from the middle of the day range, "range" shows "X to Y days" */
    var ts = isStr(rawTog.timeline_style) ? rawTog.timeline_style.trim().toLowerCase() : '';
    if (ts && TIMELINE_STYLES.indexOf(ts) === -1) {
      uniqPush(repairs, 'The timeline style was not "about" or "range", so we set it to "about", which shows one number of days.');
      ts = '';
    }
    cfg.toggles.timeline_style = ts || 'about';

    /* ---- calibration ---- */
    var rawCal = isObj(raw.calibration) ? raw.calibration : {};
    var per = isObj(rawCal.per_service) ? rawCal.per_service : {};
    var cleanPer = {};
    for (var ck2 in per) {
      if (!Object.prototype.hasOwnProperty.call(per, ck2)) continue;
      var sKey = slugify(ck2, '');
      if (!validKeys[sKey]) continue;
      var f = toNum(per[ck2]);
      if (f === null || f <= 0) continue;
      var cf = clamp(f, 0.5, 2.0);
      if (Math.abs(cf - f) > 0.0001) uniqPush(repairs, 'A learned price adjustment was outside safe limits. We pulled it back to ' + cf.toFixed(2) + '.');
      cleanPer[sKey] = Math.round(cf * 1000) / 1000;
    }
    cfg.calibration.per_service = cleanPer;
    cfg.calibration.last_trained = isStr(rawCal.last_trained) ? rawCal.last_trained.slice(0, 40) : null;
    var rounds = toNum(rawCal.rounds);
    cfg.calibration.rounds = rounds === null ? 0 : Math.round(clamp(rounds, 0, 1000));

    /* ---- lead capture ---- */
    var rawLead = isObj(raw.lead_capture) ? raw.lead_capture : {};
    var whErrs = [];
    var wh = isStr(rawLead.webhook_url) && rawLead.webhook_url.trim()
      ? checkUrl(rawLead.webhook_url, 'webhook link', repairs, whErrs, false, setup) : '';
    if (whErrs.length) {
      uniqPush(warnings, 'Your webhook link did not look like a web address, so we left it empty. Your funnel still works and still shows the price. Paste the link again on the Publish tab if you want the answers sent somewhere.');
      wh = '';
    }
    cfg.lead_capture.webhook_url = wh;

    /* the email relay key (Web3Forms access key). Public by design, shaped like a UUID. */
    var ek = isStr(rawLead.email_key) ? rawLead.email_key.trim().replace(/^["'\s]+|["'\s]+$/g, '') : '';
    if (ek && !UUID_RE.test(ek)) {
      uniqPush(repairs, 'Your email access key did not look right (it should look like 8-4-4-4-12 letters and numbers), so we left it empty. Copy it again from the Web3Forms email and paste it on the Publish tab.');
      ek = '';
    }
    cfg.lead_capture.email_key = ek.toLowerCase();

    /* v1.1.2: the backup email when the CRM send fails. Also a Web3Forms access key,
     * because Web3Forms sends to the address the key was made for. */
    var alk = isStr(rawLead.alert_email_key) ? rawLead.alert_email_key.trim().replace(/^["'\s]+|["'\s]+$/g, '') : '';
    if (alk && !UUID_RE.test(alk)) {
      uniqPush(repairs, 'Your backup email key did not look right (it should look like 8-4-4-4-12 letters and numbers), so we left it empty. Copy it again from the Web3Forms email and paste it on the Publish tab.');
      alk = '';
    }
    cfg.lead_capture.alert_email_key = alk.toLowerCase();

    /* where leads go. Older configs have no destination: a webhook link means
     * webhook, otherwise nowhere. Nowhere is honest, the funnel then never says sent. */
    var dest = isStr(rawLead.destination) ? rawLead.destination.trim().toLowerCase() : '';
    if (dest === 'crm' || dest === 'zapier' || dest === 'make' || dest === 'highlevel') dest = 'webhook';
    if (dest === 'relay' || dest === 'web3forms' || dest === 'inbox') dest = 'email';
    if (dest === 'nowhere' || dest === 'off' || dest === '') dest = dest === '' ? '' : 'none';
    if (LEAD_MODES.indexOf(dest) === -1) dest = wh ? 'webhook' : (ek ? 'email' : 'none');
    cfg.lead_capture.destination = dest;
    if (dest === 'webhook' && !wh) uniqPush(setup, 'You chose to send leads to your CRM or automation tool, but there is no webhook link yet. Paste it on the Publish tab, or nobody receives your leads.');
    if (dest === 'email' && !ek) uniqPush(setup, 'You chose to get each lead by email, but there is no access key yet. Follow the three steps on the Publish tab, or nobody receives your leads.');

    var fields = [];
    var rawFields = isArr(rawLead.fields) ? rawLead.fields : ['name', 'email', 'phone'];
    for (var fi = 0; fi < rawFields.length; fi++) {
      var fname = slugify(rawFields[fi], '');
      if (fname === 'full_name' || fname === 'first_name') fname = 'name';
      if (fname === 'email_address') fname = 'email';
      if (fname === 'phone_number' || fname === 'mobile') fname = 'phone';
      if (ALLOWED_FIELDS.indexOf(fname) !== -1 && fields.indexOf(fname) === -1) fields.push(fname);
    }
    if (!fields.length) fields = ['name', 'email'];
    if (fields.indexOf('email') === -1) {
      fields.push('email');
      uniqPush(repairs, 'We added the email box back to your contact step. Without it you cannot follow up with anyone.');
    }
    cfg.lead_capture.fields = fields;
    cfg.lead_capture.consent_text = isStr(rawLead.consent_text) ? rawLead.consent_text.trim().slice(0, 300) : '';
    cfg.lead_capture.watch_list = cleanWatchList(rawLead.watch_list);

    /* ---- result copy ---- */
    var rawCopy = isObj(raw.result_copy) ? raw.result_copy : {};
    cfg.result_copy.headline = cleanCopy(rawCopy.headline, d.result_copy.headline, 90, repairs);
    cfg.result_copy.disclaimer = cleanCopy(rawCopy.disclaimer, d.result_copy.disclaimer, 320, repairs);
    cfg.result_copy.cta_label = cleanCopy(rawCopy.cta_label, d.result_copy.cta_label, 50, repairs);

    /* ---- demo banner + version ---- */
    cfg.demo_banner = truthy(raw.demo_banner, false);
    cfg.demo_banner_url = isStr(raw.demo_banner_url) ? raw.demo_banner_url.trim().slice(0, 300) : '';
    if (cfg.demo_banner_url && (!/^https:\/\/[^\/?#]+\.[^\/?#]+/i.test(cfg.demo_banner_url) || /[\s"'<>`\\]/.test(cfg.demo_banner_url))) cfg.demo_banner_url = '';
    cfg.kit_version = VERSION;

    /* ---- math bounds check (PROJECT.md 2b) ---- */
    try {
      var stack = worstStack(cfg);
      if (stack.factor > 2.5) {
        uniqPush(warnings, 'Your questions can multiply one ' + stack.service + ' job by up to ' + (Math.round(stack.factor * 100) / 100) +
          ' times on their own, which is a bigger jump than most customers will believe. The biggest pushers are ' + stack.blame +
          '. Open the Prices tab and lower those "multiply" answers to about 1.3 or less.');
      }
    } catch (e3) { /* never block on the warning */ }

    /* ---- example data gate ---- */
    var exampleCount = 0;
    for (var ei = 0; ei < cfg.services.length; ei++) if (cfg.services[ei].example_data) exampleCount++;
    if (exampleCount) {
      uniqPush(setup, exampleCount + ' of your ' + cfg.services.length + ' services still use example numbers. Open the Prices tab and confirm each one before you publish.');
    }

    return cfg;
  }

  function cleanCopy(v, fallback, max, repairs) {
    if (!isStr(v) || !v.trim()) return fallback;
    var s = v.trim().slice(0, max);
    if (/\u2014|\u2013/.test(s)) {
      s = s.replace(/\s*[\u2014\u2013]\s*/g, ', ');
      uniqPush(repairs, 'We replaced some long dashes in your wording with commas so it reads plainly.');
    }
    if (/\bguarantee(d|s)?\b/i.test(s)) {
      uniqPush(repairs, 'Your wording promised a guarantee. We took that word out, because an estimate is not a promise.');
      s = s.replace(/\bguaranteed\b/gi, 'estimated').replace(/\bguarantees\b/gi, 'estimates').replace(/\bguarantee\b/gi, 'estimate');
    }
    return s;
  }

  function truthy(v, dflt) {
    if (v === undefined || v === null) return dflt;
    if (typeof v === 'boolean') return v;
    if (isFiniteNum(v)) return v !== 0;
    if (isStr(v)) {
      var s = v.trim().toLowerCase();
      if (s === 'true' || s === 'yes' || s === 'on' || s === '1') return true;
      if (s === 'false' || s === 'no' || s === 'off' || s === '0' || s === '') return false;
    }
    return dflt;
  }

  /* The worst multiplier stack that can land on ONE service. This is the number a
   * customer actually feels, so it is what the bounds warning judges. Services are
   * never summed for this, and the rush knob is read at its neutral setting. */
  function worstStack(cfg) {
    var best = { factor: 1, service: 'job', blame: '' };
    for (var i = 0; i < cfg.services.length; i++) {
      var svc = cfg.services[i];
      var factor = 1, parts = [];
      for (var q = 0; q < cfg.questions.length; q++) {
        var qq = cfg.questions[q];
        var ap = isArr(qq.applies_to) ? qq.applies_to : [];
        if (ap.length && ap.indexOf(svc.key) === -1) continue;
        var m = 1;
        if (qq.type === 'number') {
          var e = qq.per_unit_effect || { type: 'none', value: 0 };
          if (e.type === 'multiply') {
            var span = Math.max(0, (toNum(qq.max) || 0) - (toNum(qq.min) || 0));
            m = clamp(1 + (toNum(e.value) || 0) * span, 0.5, 3.0);
          }
        } else {
          for (var o = 0; o < (qq.options || []).length; o++) {
            var ef = qq.options[o].effect || {};
            if (ef.type !== 'multiply') continue;
            var v = toNum(ef.value);
            if (v === null || v <= 1) continue;
            if (qq.type === 'multi') m *= v; else m = Math.max(m, v);
          }
        }
        if (m > 1.0001) { factor *= m; parts.push({ label: qq.label, m: m }); }
      }
      if (factor > best.factor) {
        parts.sort(function (a, b) { return b.m - a.m; });
        var names = [];
        for (var n = 0; n < parts.length && n < 3; n++) names.push('"' + parts[n].label + '"');
        best = {
          factor: factor,
          service: '"' + svc.label + '"',
          blame: names.length > 1 ? names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1] : (names[0] || 'your questions')
        };
      }
    }
    return best;
  }

  function calFactor(cfg, key) {
    var per = (cfg.calibration && cfg.calibration.per_service) || {};
    var f = toNum(per[key]);
    if (f === null || f <= 0) return 1;
    return clamp(f, 0.5, 2.0);
  }

  /* ------------------------------------------------------------------ *
   * 4. Formatting
   * ------------------------------------------------------------------ */

  function groupDigits(n) {
    var s = String(n);
    var neg = s.charAt(0) === '-';
    if (neg) s = s.slice(1);
    var parts = s.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (neg ? '-' : '') + parts.join('.');
  }

  function fmtMoney(n, cfg) {
    if (!isFiniteNum(n)) n = 0;
    var sym = (cfg && cfg.business && cfg.business.currency_symbol) || '$';
    var rounded = Math.abs(n) < 10 && n % 1 !== 0 ? Math.round(n * 100) / 100 : Math.round(n);
    return sym + groupDigits(rounded);
  }

  function fmtHours(n) {
    if (!isFiniteNum(n)) n = 0;
    var r = Math.round(n * 10) / 10;
    if (Math.abs(r - Math.round(r)) < 0.05) r = Math.round(r);
    return groupDigits(r);
  }

  function fmtPlain(n, cfg) {
    var unit = cfg && cfg.business ? cfg.business.unit : 'price';
    if (unit === 'price') return fmtMoney(n, cfg);
    return fmtHours(n) + ' hours';
  }

  /* ------------------------------------------------------------------ *
   * 5. Rounding
   * ------------------------------------------------------------------ */

  function roundStep(r, value, isHours) {
    if (isHours) {
      if (r <= 0) return 0.1;
      if (r <= 66) return 0.5;
      return 1;
    }
    if (r <= 0) return 1;
    if (r <= 33) return 5;
    if (r <= 66) return 25;
    return value < 1000 ? 50 : 100;
  }

  function roundDown(v, step) {
    if (!(step > 0)) return v;
    var out = Math.floor((v + 1e-9) / step) * step;
    return Math.round(out * 1000) / 1000;
  }
  function roundUp(v, step) {
    if (!(step > 0)) return v;
    var out = Math.ceil((v - 1e-9) / step) * step;
    return Math.round(out * 1000) / 1000;
  }

  /* ------------------------------------------------------------------ *
   * 6. Which questions apply
   * ------------------------------------------------------------------ */

  function applicableQuestions(config, selectedServiceKeys) {
    var out = [];
    if (!config || !isArr(config.questions)) return out;
    var sel = isArr(selectedServiceKeys) ? selectedServiceKeys : [];
    for (var i = 0; i < config.questions.length; i++) {
      var q = config.questions[i];
      if (!q) continue;
      var ap = isArr(q.applies_to) ? q.applies_to : [];
      if (!ap.length) { out.push(q); continue; }
      for (var j = 0; j < sel.length; j++) {
        if (ap.indexOf(sel[j]) !== -1) { out.push(q); break; }
      }
    }
    return out;
  }

  /* ------------------------------------------------------------------ *
   * 7. The estimate
   * ------------------------------------------------------------------ */

  function emptyEstimate(config, note) {
    var unit = config && config.business ? config.business.unit : 'price';
    return {
      lo: 0, hi: 0, unit: unit,
      price_lo: null, price_hi: null,
      days_lo: 0, days_hi: 0,
      drivers: [], line_items: [],
      text: note || 'Pick what you need to see your range.',
      timeline_text: '',
      services_text: ''
    };
  }

  function estimate(config, answers) {
    try {
      return estimateInner(config, answers);
    } catch (e) {
      return emptyEstimate(config, 'We could not work out a price from those answers. Go back a step and try again.');
    }
  }

  function estimateInner(config, answers) {
    var cfg = isObj(config) ? config : defaults();
    if (!isArr(cfg.services) || !cfg.services.length) return emptyEstimate(cfg, 'No services are set up yet.');
    var knobs = isObj(cfg.knobs) ? cfg.knobs : KNOB_DEFAULTS;
    var K = {};
    for (var kn = 0; kn < KNOB_KEYS.length; kn++) {
      var v = toNum(knobs[KNOB_KEYS[kn]]);
      K[KNOB_KEYS[kn]] = v === null ? KNOB_DEFAULTS[KNOB_KEYS[kn]] : clamp(v, 0, 100);
    }
    var ans = isObj(answers) ? answers : {};
    var wanted = isArr(ans.services) ? ans.services : (isStr(ans.services) ? [ans.services] : []);
    var qAns = isObj(ans.q) ? ans.q : {};

    var byKey = {};
    for (var s0 = 0; s0 < cfg.services.length; s0++) byKey[cfg.services[s0].key] = cfg.services[s0];

    var selected = [];
    for (var w = 0; w < wanted.length; w++) {
      var sk = isStr(wanted[w]) ? wanted[w] : String(wanted[w] || '');
      if (byKey[sk] && selected.indexOf(sk) === -1) selected.push(sk);
    }
    if (cfg.allow_multiple_services === false && selected.length > 1) selected = [selected[0]];
    if (!selected.length) return emptyEstimate(cfg, 'Pick what you need to see your range.');

    var isHours = cfg.business && (cfg.business.unit === 'hours' || cfg.business.unit === 'both');

    /* base */
    var baseLo = 0, baseHi = 0, perService = [];
    for (var s1 = 0; s1 < selected.length; s1++) {
      var svc = byKey[selected[s1]];
      var f = calFactor(cfg, svc.key);
      var l = svc.lo * f, h = svc.hi * f;
      baseLo += l; baseHi += h;
      perService.push({ key: svc.key, label: svc.label, lo: l, hi: h, days_lo: svc.days_lo, days_hi: svc.days_hi });
    }
    if (!(baseHi > 0)) return emptyEstimate(cfg, 'Those services have no prices on them yet.');

    /* effects */
    var mult = 1, add = 0, widen = 0, drivers = [];
    var qs = applicableQuestions(cfg, selected);
    for (var qi = 0; qi < qs.length; qi++) {
      var q = qs[qi];
      var a = qAns[q.key];
      if (a === undefined || a === null || a === '') continue;

      if (q.type === 'number') {
        var nval = toNum(a);
        if (nval === null) continue;
        nval = clamp(nval, isFiniteNum(q.min) ? q.min : 0, isFiniteNum(q.max) ? q.max : 1000000);
        var pe = q.per_unit_effect || { type: 'none', value: 0 };
        if (pe.type === 'multiply') {
          var mfac = clamp(1 + (toNum(pe.value) || 0) * nval, 0.5, 3.0);
          mult *= mfac;
          if (Math.abs(mfac - 1) > 0.005) drivers.push({ label: q.label, answer: String(nval), detail: pctWord(mfac) });
        } else if (pe.type === 'add') {
          var amt = (toNum(pe.value) || 0) * nval;
          add += amt;
          if (Math.abs(amt) > 0.005) drivers.push({ label: q.label, answer: String(nval), detail: (amt > 0 ? 'adds ' : 'takes off ') + fmtPlain(Math.abs(amt), cfg) });
        }
        continue;
      }

      var picks = [];
      if (q.type === 'multi') {
        var list = isArr(a) ? a : [a];
        for (var li = 0; li < list.length; li++) {
          var idx = Math.round(toNum(list[li]));
          if (isFiniteNum(idx) && q.options && q.options[idx]) picks.push(idx);
        }
      } else {
        var one = Math.round(toNum(a));
        if (isFiniteNum(one) && q.options && q.options[one]) picks.push(one);
      }

      for (var pk = 0; pk < picks.length; pk++) {
        var opt = q.options[picks[pk]];
        var eff = opt.effect || { type: 'none', value: 0 };
        var val = toNum(eff.value); if (val === null) val = eff.type === 'multiply' ? 1 : 0;

        if (eff.type === 'multiply') {
          var m = val;
          if (q.role === 'urgency') {
            var scale = K.rush_premium / 50;
            m = 1 + (val - 1) * scale;
            m = clamp(m, 0.5, 3.0);
          }
          mult *= m;
          if (Math.abs(m - 1) > 0.005) drivers.push({ label: q.label, answer: opt.label, detail: pctWord(m) });
        } else if (eff.type === 'add') {
          add += val;
          if (Math.abs(val) > 0.005) drivers.push({ label: q.label, answer: opt.label, detail: (val > 0 ? 'adds ' : 'takes off ') + fmtPlain(Math.abs(val), cfg) });
        } else if (eff.type === 'widen') {
          widen += clamp(val, 0, 0.5);
          drivers.push({ label: q.label, answer: opt.label, detail: 'widens the range at both ends while this is unknown' });
        }
      }
    }

    mult = clamp(mult, 0.4, 4.0);
    widen = clamp(widen, 0, 1.0);

    var lo = baseLo * mult + add;
    var hi = baseHi * mult + add;
    if (!isFiniteNum(lo)) lo = 0;
    if (!isFiniteNum(hi)) hi = 0;
    if (hi < lo) { var sw = lo; lo = hi; hi = sw; }

    /* price level */
    var levelF = 1 + (K.price_level - 50) / 50 * 0.20;
    lo *= levelF; hi *= levelF;

    /* range width + widen */
    var mid = (lo + hi) / 2;
    var half = (hi - lo) / 2;
    half = half * (0.25 + 1.5 * K.range_width / 100);
    half += widen * mid;
    lo = mid - half; hi = mid + half;

    /* safety buffer on the high end */
    hi += mid * (K.safety_buffer / 100 * 0.30);

    if (lo < 0) lo = 0;
    if (hi < lo) hi = lo;

    /* rounding */
    var stepLo = roundStep(K.rounding, lo, isHours);
    var stepHi = roundStep(K.rounding, hi, isHours);
    var rLo = roundDown(lo, stepLo);
    var rHi = roundUp(hi, stepHi);
    if (rLo < 0) rLo = 0;
    if (rHi < rLo) rHi = rLo;

    /* line items keep the same shape as the total */
    var scaleLo = baseLo > 0 ? rLo / baseLo : 0;
    var scaleHi = baseHi > 0 ? rHi / baseHi : 0;
    var lineItems = [];
    for (var pi2 = 0; pi2 < perService.length; pi2++) {
      var ps = perService[pi2];
      var ilo = ps.lo * scaleLo, ihi = ps.hi * scaleHi;
      var istep = roundStep(K.rounding, ilo, isHours);
      lineItems.push({
        key: ps.key,
        label: ps.label,
        lo: roundDown(ilo, istep),
        hi: roundUp(ihi, roundStep(K.rounding, ihi, isHours))
      });
    }

    /* timeline */
    var dLo = 0, dHi = 0;
    for (var d1 = 0; d1 < perService.length; d1++) {
      dLo = Math.max(dLo, perService[d1].days_lo || 0);
      dHi += (perService[d1].days_hi || 0);
    }
    if (dHi > 120) dHi = 120;
    if (dHi < dLo) dHi = dLo;

    /* unit conversion */
    var rate = cfg.business ? toNum(cfg.business.hourly_rate) : null;
    var unit = cfg.business ? cfg.business.unit : 'price';
    var priceLo = null, priceHi = null;
    if (unit === 'price') { priceLo = rLo; priceHi = rHi; }
    else if (unit === 'both' && rate) {
      priceLo = roundDown(rLo * rate, roundStep(K.rounding, rLo * rate, false));
      priceHi = roundUp(rHi * rate, roundStep(K.rounding, rHi * rate, false));
    }

    var text;
    if (unit === 'price') text = fmtMoney(rLo, cfg) + ' to ' + fmtMoney(rHi, cfg);
    else if (unit === 'hours') text = fmtHours(rLo) + ' to ' + fmtHours(rHi) + ' hours';
    else text = fmtHours(rLo) + ' to ' + fmtHours(rHi) + ' hours' + (priceLo !== null ? ' (' + fmtMoney(priceLo, cfg) + ' to ' + fmtMoney(priceHi, cfg) + ')' : '');

    var tStyle = cfg.toggles && cfg.toggles.timeline_style === 'range' ? 'range' : 'about';
    var tDays = tStyle === 'about' ? Math.round((dLo + dHi) / 2) : dLo;
    var timelineText = (dLo === dHi || tStyle === 'about')
      ? (tDays === 1 ? 'About 1 day on site' : 'About ' + tDays + ' days')
      : dLo + ' to ' + dHi + ' days';

    var names = [];
    for (var nn = 0; nn < perService.length; nn++) names.push(perService[nn].label);

    return {
      lo: rLo, hi: rHi, unit: unit,
      price_lo: priceLo, price_hi: priceHi,
      days_lo: dLo, days_hi: dHi,
      drivers: drivers,
      line_items: lineItems,
      text: text,
      timeline_text: timelineText,
      services_text: names.join(', ')
    };
  }

  function pctWord(m) {
    var pct = Math.round((m - 1) * 100);
    if (pct === 0) return 'no change';
    if (pct > 0) return 'adds about ' + pct + '%';
    return 'takes off about ' + Math.abs(pct) + '%';
  }

  /* ------------------------------------------------------------------ *
   * 8. Knob explanations, in plain words
   * ------------------------------------------------------------------ */

  function explainKnob(name, value) {
    var v = toNum(value);
    if (v === null) v = 50;
    v = Math.round(clamp(v, 0, 100));
    var n = String(name || '').toLowerCase();

    if (n === 'range_width') {
      var k = 0.25 + 1.5 * v / 100;
      if (Math.abs(k - 1) < 0.02) return 'Range width ' + v + ': your low and high stay exactly as you typed them.';
      if (k < 1) return 'Range width ' + v + ': both ends move ' + Math.round((1 - k) * 100) + '% closer to the middle, so your low goes up and your high comes down. Tighter reads as more confident and gives you less room to be wrong.';
      return 'Range width ' + v + ': both ends move ' + Math.round((k - 1) * 100) + '% further from the middle, so your low comes down and your high goes up. Wider leaves room for a job that turns out bigger than it looked.';
    }
    if (n === 'price_level') {
      var p = Math.round((v - 50) / 50 * 20);
      if (p === 0) return 'Price level ' + v + ': prices show exactly as you typed them.';
      if (p > 0) return 'Price level ' + v + ': every price shows ' + p + '% higher than what you typed.';
      return 'Price level ' + v + ': every price shows ' + Math.abs(p) + '% lower than what you typed.';
    }
    if (n === 'safety_buffer') {
      var b = Math.round(v / 100 * 30);
      if (b === 0) return 'Safety buffer 0: no padding at all, your high end stays where the range put it.';
      return 'Safety buffer ' + v + ': your high end gets about ' + b + '% more room so surprises are covered. Your low end never moves.';
    }
    if (n === 'rush_premium') {
      if (v === 0) return 'Rush premium 0: urgent jobs cost the same as any other job.';
      if (v === 50) return 'Rush premium 50: urgent jobs cost exactly the extra you typed.';
      if (v < 50) return 'Rush premium ' + v + ': urgent jobs get ' + Math.round(v / 50 * 100) + '% of the extra you typed.';
      return 'Rush premium ' + v + ': urgent jobs get ' + Math.round(v / 50 * 100) + '% of the extra you typed, so rush work costs more.';
    }
    if (n === 'rounding') {
      if (v <= 0) return 'Rounding 0: prices show to the exact dollar, like 1,247.';
      if (v <= 33) return 'Rounding ' + v + ': prices round to the nearest 5, like 1,245.';
      if (v <= 66) return 'Rounding ' + v + ': prices round to the nearest 25, like 1,250.';
      return 'Rounding ' + v + ': prices round to the nearest 50 (or nearest 100 above 1,000), like 1,300.';
    }
    if (n === 'detail_shown') {
      if (v <= 33) return 'Detail shown ' + v + ': customers see the price range only.';
      if (v <= 66) return 'Detail shown ' + v + ': customers see the range plus what drives their price.';
      return 'Detail shown ' + v + ': customers see the range, the drivers, and a price per service.';
    }
    return 'This setting is on ' + v + ' out of 100.';
  }

  /* ------------------------------------------------------------------ *
   * 9. Train on past jobs
   * ------------------------------------------------------------------ */

  function train(config, jobs) {
    try {
      return trainInner(config, jobs);
    } catch (e) {
      return { suggestions: [], skipped: [{ service: '', reason: 'We could not read those past jobs. Check the columns are service, quoted low, quoted high, actual.' }] };
    }
  }

  function trainInner(config, jobs) {
    var cfg = isObj(config) ? config : defaults();
    var list = isArr(jobs) ? jobs : [];
    var byKey = {}, byLabel = {};
    for (var i = 0; i < (cfg.services || []).length; i++) {
      byKey[cfg.services[i].key] = cfg.services[i];
      byLabel[slugify(cfg.services[i].label, '')] = cfg.services[i];
    }

    var groups = {}, unknown = {};
    for (var j = 0; j < list.length; j++) {
      var row = list[j];
      if (!isObj(row)) continue;
      var nameRaw = row.service !== undefined ? row.service : row.key;
      var key = slugify(nameRaw, '');
      var svc = byKey[key] || byLabel[key] || null;
      if (!svc) {
        var lbl = String(nameRaw === undefined || nameRaw === null ? '' : nameRaw).slice(0, 60);
        unknown[lbl || '(blank)'] = (unknown[lbl || '(blank)'] || 0) + 1;
        continue;
      }
      var ql = toNum(row.quoted_lo); if (ql === null) ql = toNum(row.quoted_low);
      var qh = toNum(row.quoted_hi); if (qh === null) qh = toNum(row.quoted_high);
      var act = toNum(row.actual);
      if (act === null || act <= 0) continue;
      if (ql === null && qh === null) continue;
      if (ql === null) ql = qh;
      if (qh === null) qh = ql;
      if (ql > qh) { var t = ql; ql = qh; qh = t; }
      var mid = (ql + qh) / 2;
      if (!(mid > 0)) continue;
      var ratio = act / mid;
      if (!isFiniteNum(ratio) || ratio <= 0) continue;
      if (!groups[svc.key]) groups[svc.key] = { service: svc.key, label: svc.label, rows: [] };
      groups[svc.key].rows.push({ ratio: ratio, quoted_lo: ql, quoted_hi: qh, actual: act });
    }

    var suggestions = [], skipped = [];
    for (var uk in unknown) {
      if (!Object.prototype.hasOwnProperty.call(unknown, uk)) continue;
      skipped.push({ service: uk, n: unknown[uk], reason: 'We do not have a service called "' + uk + '". Check the spelling on the Prices tab, or rename it in your pasted data.' });
    }

    for (var gk in groups) {
      if (!Object.prototype.hasOwnProperty.call(groups, gk)) continue;
      var g = groups[gk];
      var allRatios = [];
      for (var r0 = 0; r0 < g.rows.length; r0++) allRatios.push(g.rows[r0].ratio);
      var med0 = median(allRatios);
      var kept = [], outliers = [];
      for (var r1 = 0; r1 < g.rows.length; r1++) {
        var rr = g.rows[r1];
        if (med0 && (rr.ratio > med0 * 2.5 || rr.ratio < med0 / 2.5)) {
          outliers.push({ quoted_lo: rr.quoted_lo, quoted_hi: rr.quoted_hi, actual: rr.actual, ratio: Math.round(rr.ratio * 100) / 100 });
        } else kept.push(rr);
      }
      var n = kept.length;
      if (n < 3) {
        skipped.push({
          service: g.service, label: g.label, n: n, outliers: outliers,
          reason: n === 0
            ? 'Every ' + g.label + ' job looked like a one-off, so we changed nothing.'
            : 'Only ' + n + ' usable ' + g.label + ' job' + (n === 1 ? '' : 's') + '. We need at least 3 before we touch a price.'
        });
        continue;
      }
      var keptRatios = [];
      for (var r2 = 0; r2 < kept.length; r2++) keptRatios.push(kept[r2].ratio);
      var medR = median(keptRatios);
      var current = calFactor(cfg, g.service);
      var wanted = current * medR;
      var capLo = current * 0.85, capHi = current * 1.15;
      var capped = clamp(wanted, capLo, capHi);
      var wasCapped = Math.abs(capped - wanted) > 0.0005;
      capped = clamp(capped, 0.5, 2.0);
      suggestions.push({
        service: g.service,
        label: g.label,
        n: n,
        median_ratio: Math.round(medR * 1000) / 1000,
        current_factor: Math.round(current * 1000) / 1000,
        suggested_factor: Math.round(capped * 1000) / 1000,
        change_pct: Math.round((capped / current - 1) * 1000) / 10,
        capped: wasCapped,
        confidence: n <= 4 ? 'low' : 'ok',
        outliers: outliers,
        note: plainTrainNote(g.label, medR, capped, current, n, wasCapped, outliers.length)
      });
    }

    suggestions.sort(function (a, b) { return Math.abs(b.change_pct) - Math.abs(a.change_pct); });
    return { suggestions: suggestions, skipped: skipped };
  }

  function plainTrainNote(label, medR, next, current, n, wasCapped, outCount) {
    var dir = medR > 1 ? 'over' : 'under';
    var pct = Math.abs(Math.round((medR - 1) * 100));
    var movePct = Math.round((next / current - 1) * 100);
    var s = 'Across ' + n + ' jobs, ' + label + ' came in about ' + pct + '% ' + dir + ' your quote on average.';
    if (movePct === 0) s += ' That is close enough that we suggest no change.';
    else s += ' We suggest moving this price ' + (movePct > 0 ? 'up ' : 'down ') + Math.abs(movePct) + '%.';
    if (wasCapped) s += ' We capped the move at 15% so nothing jumps too far in one go.';
    if (outCount) s += ' We left ' + outCount + ' odd job' + (outCount === 1 ? '' : 's') + ' out of the maths.';
    return s;
  }

  function applyTraining(config, accepted) {
    try {
      var cfg = deepClone(isObj(config) ? config : defaults());
      if (!isObj(cfg.calibration)) cfg.calibration = { per_service: {}, last_trained: null, rounds: 0 };
      if (!isObj(cfg.calibration.per_service)) cfg.calibration.per_service = {};
      var list = isArr(accepted) ? accepted : (accepted ? [accepted] : []);
      var applied = 0;
      var valid = {};
      for (var v = 0; v < (cfg.services || []).length; v++) valid[cfg.services[v].key] = 1;
      for (var i = 0; i < list.length; i++) {
        var a = list[i];
        if (!isObj(a)) continue;
        var key = slugify(a.service || a.key, '');
        if (!valid[key]) continue;
        var f = toNum(a.suggested_factor);
        if (f === null || f <= 0) continue;
        cfg.calibration.per_service[key] = Math.round(clamp(f, 0.5, 2.0) * 1000) / 1000;
        applied++;
      }
      if (applied) {
        cfg.calibration.rounds = (toNum(cfg.calibration.rounds) || 0) + 1;
        cfg.calibration.last_trained = new Date().toISOString().slice(0, 10);
      }
      return cfg;
    } catch (e) {
      return config;
    }
  }

  /* ------------------------------------------------------------------ *
   * 9b. v1.2: possibly fake leads and the owner's watch list
   * ------------------------------------------------------------------ */

  var TIMELINE_STYLES = ['about', 'range'];
  var FAKE_NAME_WORDS = ['test', 'testing', 'tester', 'asdf', 'asdfg', 'asdfgh', 'qwerty', 'fake', 'dummy', 'sample', 'xxx'];
  var FAKE_FULL_NAMES = ['john doe', 'jane doe'];
  var FAKE_EMAIL_DOMAINS = ['example.com', 'example.org', 'example.net'];
  var FAKE_EMAIL_TLDS = ['test', 'example', 'invalid', 'localhost'];

  function normWords(v) {
    return str(v).toLowerCase().replace(/[^a-z0-9@.\s'-]/g, ' ').replace(/[\s]+/g, ' ').trim();
  }

  /* The estimate ALWAYS still shows and sends. This only labels the lead, so the
   * owner's workflow can skip the call task. Plain reasons, one per rule hit. */
  function fakeCheck(contact) {
    var c = isObj(contact) ? contact : {};
    var reasons = [];
    var name = normWords(c.name).replace(/[.'-]/g, ' ').replace(/\s+/g, ' ').trim();
    if (name) {
      var words = name.split(' ');
      var hit = '';
      for (var i = 0; i < words.length && !hit; i++) {
        if (FAKE_NAME_WORDS.indexOf(words[i]) !== -1) hit = words[i];
        else if (/^([a-z])\1{2,}$/.test(words[i])) hit = words[i];
      }
      if (!hit && FAKE_FULL_NAMES.indexOf(name) !== -1) hit = name;
      if (hit) reasons.push('the name looks like a test (' + hit + ')');
    }
    var email = str(c.email).trim().toLowerCase();
    var at = email.lastIndexOf('@');
    if (at > 0) {
      var dom = email.slice(at + 1);
      var tld = dom.split('.').pop();
      if (FAKE_EMAIL_DOMAINS.indexOf(dom) !== -1 || FAKE_EMAIL_TLDS.indexOf(tld) !== -1) reasons.push('the email address is a test address (' + dom + ')');
    }
    var digits = str(c.phone).replace(/\D/g, '');
    if (digits.length === 11 && digits.charAt(0) === '1') digits = digits.slice(1);
    if (digits.length >= 7) {
      var local7 = digits.slice(-7);
      if (/^55501\d\d$/.test(local7)) reasons.push('the phone number is a 555-01xx number, which is kept for films and tests');
      else if (/^(\d)\1+$/.test(digits)) reasons.push('the phone number is one digit repeated');
      else if ('01234567890123456789'.indexOf(digits) !== -1 || '98765432109876543210'.indexOf(digits) !== -1) reasons.push('the phone number is digits in a row');
    }
    return { possibly_fake: reasons.length > 0, reasons: reasons };
  }

  /* The watch list: names or email domains the owner types. It never ships as
   * plain text: the funnel file and a live link carry a short fingerprint of each
   * entry (#xxxxxxxx), because anyone can read a web page's source. */
  var WATCH_HASH_RE = /^#[0-9a-f]{8}$/;
  function watchNorm(v) {
    return str(v).toLowerCase().replace(/^[\s@]+/, '').replace(/[^a-z0-9@.&'\s-]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function watchHash(v) {
    var s = 'efk-watch:' + v, h = 0x811c9dc5;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul ? Math.imul(h, 0x01000193) : (h * 0x01000193) | 0; }
    return '#' + ('0000000' + (h >>> 0).toString(16)).slice(-8);
  }
  function cleanWatchList(raw) {
    var list = isArr(raw) ? raw : (isStr(raw) ? raw.split(/[\n,;]+/) : []);
    var out = [];
    for (var i = 0; i < list.length && out.length < 200; i++) {
      if (!isStr(list[i])) continue;
      var t = list[i].trim().toLowerCase();
      var v = WATCH_HASH_RE.test(t) ? t : watchNorm(t).slice(0, 80);
      if (v && out.indexOf(v) === -1) out.push(v);
    }
    return out;
  }
  function watchHashes(list) {
    var set = {};
    var l = cleanWatchList(list);
    for (var i = 0; i < l.length; i++) set[WATCH_HASH_RE.test(l[i]) ? l[i] : watchHash(l[i])] = true;
    return set;
  }
  function watchMatch(config, contact) {
    var lc = config && isObj(config.lead_capture) ? config.lead_capture : {};
    var set = watchHashes(lc.watch_list);
    if (!Object.keys(set).length) return false;
    var c = isObj(contact) ? contact : {};
    var cands = [watchNorm(c.name), watchNorm(c.company)];
    var email = watchNorm(c.email).replace(/\s/g, '');
    if (email) {
      cands.push(email);
      var at = email.lastIndexOf('@');
      if (at > 0) {
        var parts = email.slice(at + 1).split('.');
        for (var p = 0; p < parts.length - 1; p++) cands.push(parts.slice(p).join('.'));
      }
    }
    for (var j = 0; j < cands.length; j++) if (cands[j] && set[watchHash(cands[j])]) return true;
    return false;
  }
  /* The config as it may be published: the watch list as fingerprints only. */
  function publicConfig(config) {
    var c = deepClone(isObj(config) ? config : defaults());
    if (isObj(c.lead_capture) && c.lead_capture.watch_list !== undefined) {
      c.lead_capture.watch_list = Object.keys(watchHashes(c.lead_capture.watch_list)).sort();
    }
    return c;
  }

  /* ------------------------------------------------------------------ *
   * 10. The webhook payload - these keys NEVER change
   * ------------------------------------------------------------------ */

  function payload(config, answers, contact, meta) {
    var out = {
      name: '', email: '', phone: '',
      business_name: '', niche: '',
      services_text: '',
      estimate_low: 0, estimate_high: 0, estimate_unit: 'price',
      currency: 'USD',
      timeline_text: '',
      answers_text: '',
      knobs_text: '',
      page_url: '', utm_source: '', utm_medium: '', utm_campaign: '',
      submitted_at: '', kit_version: VERSION,
      /* v1.1, additive: one human readable block for a CRM note or an email */
      summary_text: '',
      /* v1.1.1, additive: the two ends ready to read, as the result card shows
       * them ("$4,500", or "12 hours"), so an email never says "4500 to 9500" */
      estimate_low_text: '', estimate_high_text: '',
      /* v1.2, additive: a lead that looks like a test or made up (the estimate still
       * shows and still sends), and a match on the owner's watch list */
      possibly_fake: false, fake_reasons: '',
      watch_match: false
    };
    try {
      var cfg = isObj(config) ? config : defaults();
      var c = isObj(contact) ? contact : {};
      var m = isObj(meta) ? meta : {};
      var est = estimate(cfg, answers);

      out.name = str(c.name).slice(0, 120);
      out.email = str(c.email).slice(0, 160);
      out.phone = str(c.phone).slice(0, 40);
      out.business_name = str(cfg.business && cfg.business.name).slice(0, 120);
      out.niche = str(cfg.business && cfg.business.niche).slice(0, 60);
      out.services_text = est.services_text || '';
      out.estimate_low = est.lo;
      out.estimate_high = est.hi;
      if (est.hi > 0) {
        out.estimate_low_text = fmtPlain(est.lo, cfg);
        out.estimate_high_text = fmtPlain(est.hi, cfg);
      }
      out.estimate_unit = est.unit;
      out.currency = str(cfg.business && cfg.business.currency) || 'USD';
      out.timeline_text = est.timeline_text || '';

      var lines = [];
      var ans = isObj(answers) ? answers : {};
      var sel = isArr(ans.services) ? ans.services : [];
      lines.push('Q: What do you need? A: ' + (est.services_text || '(none picked)'));
      var qs = applicableQuestions(cfg, sel);
      var qAns = isObj(ans.q) ? ans.q : {};
      for (var i = 0; i < qs.length; i++) {
        var q = qs[i];
        var a = qAns[q.key];
        if (a === undefined || a === null || a === '') continue;
        var text = '';
        if (q.type === 'number') text = String(a);
        else if (q.type === 'multi') {
          var arr = isArr(a) ? a : [a], picked = [];
          for (var j = 0; j < arr.length; j++) {
            var ix = Math.round(toNum(arr[j]));
            if (q.options && q.options[ix]) picked.push(q.options[ix].label);
          }
          text = picked.join(', ');
        } else {
          var one = Math.round(toNum(a));
          text = (q.options && q.options[one]) ? q.options[one].label : '';
        }
        if (text) lines.push('Q: ' + q.label + ' A: ' + text);
      }
      out.answers_text = lines.join('\n');

      var sum = [];
      sum.push('Estimate request for ' + (out.business_name || 'your business'));
      sum.push('Service(s): ' + (est.services_text || '(none picked)'));
      sum.push('Estimate: ' + estimateLine(est, cfg));
      if (out.timeline_text) sum.push('Timeline: ' + out.timeline_text);

      var fk = fakeCheck(c);
      out.possibly_fake = fk.reasons.length > 0;
      out.fake_reasons = fk.reasons.join('; ').slice(0, 300);
      out.watch_match = watchMatch(cfg, c);
      if (out.possibly_fake) sum.push('Possibly a test or made up lead: ' + out.fake_reasons);
      if (out.watch_match) sum.push('On your watch list');
      sum.push('');
      out.summary_text = (sum.join('\n') + '\n' + out.answers_text).slice(0, 4000);

      var kbits = [];
      for (var k = 0; k < KNOB_KEYS.length; k++) {
        var kv = cfg.knobs && cfg.knobs[KNOB_KEYS[k]];
        kbits.push(KNOB_KEYS[k] + '=' + (toNum(kv) === null ? KNOB_DEFAULTS[KNOB_KEYS[k]] : Math.round(toNum(kv))));
      }
      out.knobs_text = kbits.join(' ');

      out.page_url = str(m.page_url).slice(0, 400);
      out.utm_source = str(m.utm_source).slice(0, 120);
      out.utm_medium = str(m.utm_medium).slice(0, 120);
      out.utm_campaign = str(m.utm_campaign).slice(0, 120);
      out.submitted_at = str(m.submitted_at) || new Date().toISOString();
    } catch (e) { /* the shape above still ships */ }
    return out;
  }

  /* "$3,825 to $8,675 USD", "12 to 20 hours", "12 to 20 hours ($1,500 to $2,500 USD)" */
  function estimateLine(est, cfg) {
    var cur = str(cfg && cfg.business && cfg.business.currency) || 'USD';
    if (!est || !(est.hi > 0)) return '(no estimate)';
    if (est.unit === 'price') return est.text + ' ' + cur;
    if (est.unit === 'both' && est.price_lo !== null) return est.text.replace(/\)$/, ' ' + cur + ')');
    return est.text;
  }

  /* ------------------------------------------------------------------ *
   * 10b. Where leads go (v1.1)
   * ------------------------------------------------------------------ */

  /* The mode the funnel really runs in. Anything half set up is 'none', so the
   * funnel never tells a visitor their details went somewhere they did not. */
  function leadMode(config) {
    var lc = config && isObj(config.lead_capture) ? config.lead_capture : {};
    var dest = isStr(lc.destination) ? lc.destination : '';
    var wh = isStr(lc.webhook_url) ? lc.webhook_url : '';
    var ek = isStr(lc.email_key) ? lc.email_key : '';
    if (!dest) dest = wh ? 'webhook' : (ek ? 'email' : 'none');
    if (dest === 'webhook' && /^https:\/\/[^\s"'<>`\\]+$/i.test(wh)) return 'webhook';
    if (dest === 'email' && UUID_RE.test(ek)) return 'email';
    return 'none';
  }

  /* The body the email relay gets: the lead's own fields plus summary_text as
   * the message, so the email reads like a note, not a data dump. */
  function relayBody(config, answers, contact, meta) {
    var p = payload(config, answers, contact, meta);
    var cfg = isObj(config) ? config : defaults();
    var lc = isObj(cfg.lead_capture) ? cfg.lead_capture : {};
    var est = estimate(cfg, answers);
    return {
      access_key: isStr(lc.email_key) ? lc.email_key : '',
      subject: ('New estimate request: ' + (p.name || 'a visitor') + (p.services_text ? ', ' + p.services_text : '')).slice(0, 150),
      from_name: (p.business_name || 'Estimate funnel').slice(0, 80) + ' estimate funnel',
      name: p.name,
      email: p.email,
      phone: p.phone,
      estimate: estimateLine(est, cfg),
      message: p.summary_text,
      page_url: p.page_url
    };
  }

  /* v1.1.2: the owner alert. When the CRM send is not confirmed (a network error, no answer in
   * 15 seconds, or, for a CRM whose answer the browser can read, an error answer) and a backup
   * email key is set, the same lead goes to the owner by email, ALERT line first. v1.2.1: the line
   * says what is known, not more: a timed out send can still land in the CRM later. */
  var ALERT_LINE = 'ALERT: your CRM did not confirm this lead, so it was emailed to you. It may also be in your CRM. Check your funnel settings.';

  function alertKey(config) {
    var lc = config && isObj(config.lead_capture) ? config.lead_capture : {};
    var k = isStr(lc.alert_email_key) ? lc.alert_email_key.trim().toLowerCase() : '';
    return UUID_RE.test(k) ? k : '';
  }

  function alertRelayBody(config, answers, contact, meta) {
    var b = relayBody(config, answers, contact, meta);
    /* the alert key goes first in the email Web3Forms writes, the message starts with it too */
    return {
      access_key: alertKey(config),
      subject: ('ALERT, CRM did not confirm. ' + b.subject).slice(0, 150),
      from_name: b.from_name,
      alert: ALERT_LINE,
      name: b.name,
      email: b.email,
      phone: b.phone,
      estimate: b.estimate,
      message: ALERT_LINE + '\n\n' + b.message,
      page_url: b.page_url
    };
  }

  /* v1.2.1: webhooks whose answer the browser is allowed to read. HighLevel inbound webhooks
   * (services.leadconnectorhq.com) answer with Access-Control-Allow-Origin: * and accept a JSON
   * body (checked 2026-10-02: a text/plain body is answered "Error: Request has invalid data").
   * For these the funnel posts application/json in cors mode, reads the answer, and an HTTP
   * error or a {"status":"Error..."} answer counts as failed. Every other webhook is posted
   * no-cors as before: the browser cannot see that CRM's answer, so only a network error or
   * no answer in 15 seconds counts as failed. */
  var READABLE_WEBHOOK_RE = /^https:\/\/services\.leadconnectorhq\.com\//i;
  function webhookReadable(url) { return READABLE_WEBHOOK_RE.test(str(url).trim()); }

  /* One webhook post. Resolves, never rejects, to { state: 'sent' | 'failed', readable, detail }. */
  function postWebhook(url, body, f) {
    var readable = webhookReadable(url);
    var text = JSON.stringify(body);
    if (!readable) {
      return Promise.resolve().then(function () {
        return f(url, {
          method: 'POST', mode: 'no-cors', keepalive: true,
          headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
          body: text
        });
      }).then(function () { return { state: 'sent', readable: false, detail: '' }; },
        function () { return { state: 'failed', readable: false, detail: 'no connection' }; });
    }
    return Promise.resolve().then(function () {
      return f(url, {
        method: 'POST', mode: 'cors',
        headers: { 'Content-Type': 'application/json' },
        body: text
      });
    }).then(function (r) {
      if (!r || !r.ok) return { state: 'failed', readable: true, detail: 'HTTP ' + (r && r.status ? r.status : 'error') };
      return Promise.resolve().then(function () { return typeof r.text === 'function' ? r.text() : ''; }).then(function (t) {
        var j = null;
        try { j = JSON.parse(t); } catch (e) { j = null; }
        var st = j && typeof j.status === 'string' ? j.status.trim() : '';
        if (/^error/i.test(st)) return { state: 'failed', readable: true, detail: st.slice(0, 160) };
        return { state: 'sent', readable: true, detail: st.slice(0, 160) };
      }, function () { return { state: 'sent', readable: true, detail: '' }; });
    }, function () { return { state: 'failed', readable: true, detail: 'no connection' }; });
  }

  /* Send one lead. deps.fetch is the browser's fetch (or a test double), deps.timeoutMs
   * defaults to 15 seconds per attempt. Resolves, never rejects, to
   * { state: 'sent' | 'failed' | 'unknown' | 'none', via: 'webhook' | 'email' | 'alert' | '' }.
   * The webhook goes through postWebhook (above): read for HighLevel, no-cors for the rest. The
   * email relay answers with JSON, so there 'sent' means the relay accepted it. Neither is proof
   * the lead reached an inbox or a contact was made. */
  function sendLead(config, answers, contact, meta, deps) {
    var d = isObj(deps) ? deps : {};
    var f = typeof d.fetch === 'function' ? d.fetch : null;
    var ms = toNum(d.timeoutMs);
    if (ms === null || ms <= 0) ms = 15000;
    var m = leadMode(config);
    if (m === 'none') return Promise.resolve({ state: 'none', via: '' });
    if (!f) return Promise.resolve({ state: 'failed', via: m });

    function timed(p) {
      return new Promise(function (res) {
        var done = false;
        var t = setTimeout(function () { if (!done) { done = true; res('unknown'); } }, ms);
        p.then(function (v) { if (!done) { done = true; clearTimeout(t); res(v); } },
          function () { if (!done) { done = true; clearTimeout(t); res('failed'); } });
      });
    }
    function relay(body) {
      return timed(Promise.resolve().then(function () {
        return f(RELAY_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify(body)
        });
      }).then(function (r) {
        return r.json().then(function (j) { return (r.ok && j && j.success === true) ? 'sent' : 'failed'; }, function () { return 'failed'; });
      }, function () { return 'failed'; }));
    }

    if (m === 'email') {
      return relay(relayBody(config, answers, contact, meta)).then(function (s) { return { state: s, via: 'email' }; });
    }
    var url = config.lead_capture.webhook_url;
    return timed(postWebhook(url, payload(config, answers, contact, meta), f)
      .then(function (r) { return r.state; })).then(function (w) {
      if (w === 'sent' || !alertKey(config)) return { state: w, via: 'webhook' };
      return relay(alertRelayBody(config, answers, contact, meta)).then(function (a) {
        if (a === 'sent') return { state: 'sent', via: 'alert' };
        /* nothing confirmed: 'unknown' when either attempt might still have landed */
        return { state: (w === 'unknown' || a === 'unknown') ? 'unknown' : 'failed', via: 'alert' };
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * 10c. The live link (v1.1): the whole config travels in the URL fragment.
   * Link shape: <LIVE_BASE>/#v1.<base64url(deflate-raw(json))>, or v0. with
   * plain utf-8 when the browser has no CompressionStream. The runner treats
   * every field as hostile: size caps, strict https, then the doctor.
   * ------------------------------------------------------------------ */

  var LINK_MAX_FRAGMENT = 16384;
  var LINK_MAX_JSON = 200000;

  function b64urlFromBytes(bytes) {
    var bin = '';
    for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function bytesFromB64url(s) {
    if (!/^[A-Za-z0-9_-]+$/.test(s)) return null;
    var b = s.replace(/-/g, '+').replace(/_/g, '/');
    while (b.length % 4) b += '=';
    var bin;
    try { bin = atob(b); } catch (e) { return null; }
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  /* The config minus everything the doctor puts back by itself, so the link
   * (and its QR code) stays as small as it can. */
  function linkConfig(config) {
    var c = publicConfig(config);
    var d = defaults();
    delete c.preview_result; delete c.kit_version; delete c.demo_banner; delete c.demo_banner_url;
    function sameAs(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
    ['knobs', 'toggles'].forEach(function (k) { if (sameAs(c[k], d[k])) delete c[k]; });
    if (isObj(c.calibration) && sameAs(c.calibration.per_service, {}) && !c.calibration.rounds) delete c.calibration;
    if (c.allow_multiple_services !== false) delete c.allow_multiple_services;
    if (isObj(c.business)) {
      for (var bk in c.business) if (Object.prototype.hasOwnProperty.call(c.business, bk) && (c.business[bk] === '' || c.business[bk] === null)) delete c.business[bk];
      if (c.business.currency === 'USD') delete c.business.currency;
      if (c.business.unit === 'price') delete c.business.unit;
    }
    if (isObj(c.lead_capture)) {
      var lc = c.lead_capture;
      if (sameAs(lc.fields, d.lead_capture.fields)) delete lc.fields;
      if (isArr(lc.watch_list) && !lc.watch_list.length) delete lc.watch_list;
      for (var lk in lc) if (Object.prototype.hasOwnProperty.call(lc, lk) && lc[lk] === '') delete lc[lk];
      if (lc.destination === 'none') delete lc.destination;
    }
    if (isObj(c.result_copy)) {
      for (var rk in d.result_copy) if (c.result_copy[rk] === d.result_copy[rk]) delete c.result_copy[rk];
    }
    (c.services || []).forEach(function (sv) { if (sv.help === '') delete sv.help; if (sv.example_data === false) delete sv.example_data; });
    (c.questions || []).forEach(function (q) {
      if (isArr(q.applies_to) && !q.applies_to.length) delete q.applies_to;
      if (q.type === 'single') delete q.type;
    });
    return c;
  }

  function encodeLink(config) {
    return Promise.resolve().then(function () {
      var bytes = new TextEncoder().encode(JSON.stringify(linkConfig(config)));
      if (typeof CompressionStream === 'function') {
        try {
          var cs = new CompressionStream('deflate-raw');
          return new Response(new Blob([bytes]).stream().pipeThrough(cs)).arrayBuffer().then(
            function (buf) { return 'v1.' + b64urlFromBytes(new Uint8Array(buf)); },
            function () { return 'v0.' + b64urlFromBytes(bytes); });
        } catch (e) { /* deflate-raw not supported here */ }
      }
      return 'v0.' + b64urlFromBytes(bytes);
    });
  }

  function inflateCapped(bytes, cap) {
    if (typeof DecompressionStream !== 'function') return Promise.reject(new Error('this browser cannot open compressed links'));
    var reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
    var chunks = [], total = 0;
    function pump() {
      return reader.read().then(function (r) {
        if (r.done) {
          var out = new Uint8Array(total), at = 0;
          for (var i = 0; i < chunks.length; i++) { out.set(chunks[i], at); at += chunks[i].length; }
          return out;
        }
        total += r.value.length;
        if (total > cap) { try { reader.cancel(); } catch (e) { /* done */ } throw new Error('the link unpacks to more than ' + cap + ' bytes'); }
        chunks.push(r.value);
        return pump();
      });
    }
    return pump();
  }

  function linkFail(reason) { return { ok: false, config: null, reason: reason }; }

  /* A link config is attacker controlled. Every link field must already be https
   * (no silent http repair here), the relay key must look like a key, and the
   * doctor must pass it. */
  function checkLinkConfig(raw) {
    if (!isObj(raw)) return linkFail('the link does not hold a settings object');
    var b = isObj(raw.business) ? raw.business : {};
    var lc = isObj(raw.lead_capture) ? raw.lead_capture : {};
    var urls = [b.booking_url, b.logo_url, lc.webhook_url, raw.demo_banner_url];
    for (var i = 0; i < urls.length; i++) {
      if (urls[i] === undefined || urls[i] === null || urls[i] === '') continue;
      if (!isStr(urls[i]) || !/^https:\/\/[^\s"'<>`\\]+$/i.test(urls[i].trim())) return linkFail('a link in the settings is not a plain https link');
    }
    if (lc.email_key !== undefined && lc.email_key !== '' && !(isStr(lc.email_key) && UUID_RE.test(lc.email_key.trim()))) return linkFail('the email key is not a key');
    if (lc.alert_email_key !== undefined && lc.alert_email_key !== '' && !(isStr(lc.alert_email_key) && UUID_RE.test(lc.alert_email_key.trim()))) return linkFail('the backup email key is not a key');
    var dx = doctor(raw);
    if (!dx.ok) return linkFail('the settings do not pass the doctor: ' + dx.errors.join(' '));
    var cfg = dx.config;
    cfg.demo_banner = false;
    cfg.demo_banner_url = '';
    delete cfg.preview_result;
    return { ok: true, config: cfg, reason: '' };
  }

  /* v1.2.1: split a live link fragment into the packed settings and any query written after
   * them. "LINK#v1.xxx?utm_source=booked" happens when an owner appends ?utm_source=booked to a
   * live link; the settings alphabet has no "?", so the split is safe. */
  function splitLinkFragment(fragment) {
    var f = fragment === null || fragment === undefined ? '' : String(fragment);
    if (f.charAt(0) === '#') f = f.slice(1);
    var q = f.indexOf('?');
    if (q === -1) return { packed: f, query: '' };
    return { packed: f.slice(0, q), query: f.slice(q + 1) };
  }

  /* The utm_ values a visitor arrived with: from the page query (location.search), and from a
   * query written after a live link's settings. The page query wins when both carry one. */
  function linkUtm(search, fragment) {
    var out = { utm_source: '', utm_medium: '', utm_campaign: '' };
    function take(q) {
      var parts = str(q).replace(/^\?/, '').split('&');
      var got = {};
      for (var i = 0; i < parts.length; i++) {
        var kv = parts[i].split('=');
        var k = '', v = '';
        try { k = decodeURIComponent(kv[0].replace(/\+/g, ' ')); v = decodeURIComponent(kv.slice(1).join('=').replace(/\+/g, ' ')); } catch (e) { continue; }
        if (Object.prototype.hasOwnProperty.call(out, k) && !got[k]) got[k] = v.slice(0, 120);
      }
      return got;
    }
    var fromHash = take(splitLinkFragment(fragment).query);
    var fromPage = take(search);
    for (var k in out) {
      if (!Object.prototype.hasOwnProperty.call(out, k)) continue;
      out[k] = fromPage[k] || fromHash[k] || '';
    }
    return out;
  }

  /* The call prep link for a booking confirmation: the funnel link with utm_source=booked in its
   * query, which is always BEFORE any #. Works for a hosted file and for a live link. */
  function callPrepLink(url) {
    var s = str(url).trim();
    if (!s) return '';
    var hash = '';
    var h = s.indexOf('#');
    if (h !== -1) { hash = s.slice(h); s = s.slice(0, h); }
    /* a query an owner wrote after the settings belongs before the # */
    var hq = hash.indexOf('?');
    var extra = '';
    if (hq !== -1) { extra = hash.slice(hq + 1); hash = hash.slice(0, hq); }
    var q = '';
    var qi = s.indexOf('?');
    if (qi !== -1) { q = s.slice(qi + 1); s = s.slice(0, qi); }
    var parts = (q + (q && extra ? '&' : '') + extra).split('&').filter(function (p) { return p && !/^utm_source=/i.test(p); });
    parts.push('utm_source=booked');
    return s + '?' + parts.join('&') + hash;
  }

  function decodeLink(fragment) {
    return Promise.resolve().then(function () {
      var f = splitLinkFragment(fragment).packed;
      if (!f) return linkFail('the link has no settings in it');
      if (f.length > LINK_MAX_FRAGMENT) return linkFail('the link is too long');
      var m = /^v([01])\.([A-Za-z0-9_-]+)$/.exec(f);
      if (!m) return linkFail('the link is from an unknown version');
      var bytes = bytesFromB64url(m[2]);
      if (!bytes || !bytes.length) return linkFail('the link is damaged');
      var raw = m[1] === '1' ? inflateCapped(bytes, LINK_MAX_JSON)
        : (bytes.length > LINK_MAX_JSON ? Promise.reject(new Error('too big')) : Promise.resolve(bytes));
      return raw.then(function (u8) {
        var text = new TextDecoder('utf-8', { fatal: true }).decode(u8);
        return checkLinkConfig(JSON.parse(text));
      });
    }).then(null, function (e) { return linkFail('the link could not be read (' + String(e && e.message ? e.message : e).slice(0, 80) + ')'); });
  }

  function str(v) {
    if (v === null || v === undefined) return '';
    if (typeof v === 'object') return '';
    return String(v);
  }

  /* ------------------------------------------------------------------ *
   * 11. Three sample leads for the knob preview
   * ------------------------------------------------------------------ */

  function sampleLeads(config) {
    var out = [
      { label: 'Small job', answers: { services: [], q: {} } },
      { label: 'Typical job', answers: { services: [], q: {} } },
      { label: 'Big job', answers: { services: [], q: {} } }
    ];
    try {
      var cfg = isObj(config) ? config : defaults();
      var svcs = isArr(cfg.services) ? cfg.services : [];
      if (!svcs.length) return out;

      /* Cheapest first. The "typical" lead is deliberately NOT the middle of the list:
       * a middle row is usually a small add-on, and then the knob sliders look like
       * they do nothing. Typical = the second biggest job, big = the biggest. */
      var sorted = svcs.slice().sort(function (a, b) { return ((a.lo + a.hi) / 2) - ((b.lo + b.hi) / 2); });
      var last = sorted.length - 1;
      var small = [sorted[0].key];
      var typical = [sorted[sorted.length >= 3 ? last - 1 : Math.floor(sorted.length / 2)].key];
      var big;
      if (cfg.allow_multiple_services !== false && sorted.length > 1) {
        big = [sorted[last].key, sorted[last - 1].key];
      } else {
        big = [sorted[last].key];
      }

      var picks = [small, typical, big];
      var modes = ['low', 'mid', 'high'];
      for (var i = 0; i < 3; i++) {
        out[i].answers.services = picks[i];
        var qs = applicableQuestions(cfg, picks[i]);
        for (var j = 0; j < qs.length; j++) {
          var q = qs[j];
          if (q.type === 'number') {
            var mn = isFiniteNum(q.min) ? q.min : 0;
            var mx = isFiniteNum(q.max) ? q.max : 10;
            out[i].answers.q[q.key] = modes[i] === 'low' ? mn : (modes[i] === 'mid' ? Math.round((mn + mx) / 2) : mx);
            continue;
          }
          var opts = isArr(q.options) ? q.options : [];
          if (!opts.length) continue;
          var bestIdx = 0, bestScore = null;
          for (var o = 0; o < opts.length; o++) {
            var e = opts[o].effect || { type: 'none', value: 0 };
            if (e.type === 'widen') continue; // a sample lead is never "not sure"
            var score;
            if (e.type === 'multiply') score = toNum(e.value) || 1;
            else if (e.type === 'add') score = 1 + (toNum(e.value) || 0) / 1000;
            else score = 1;
            if (bestScore === null) { bestScore = score; bestIdx = o; continue; }
            if (modes[i] === 'low' && score < bestScore) { bestScore = score; bestIdx = o; }
            if (modes[i] === 'high' && score > bestScore) { bestScore = score; bestIdx = o; }
            if (modes[i] === 'mid' && Math.abs(score - 1) < Math.abs(bestScore - 1)) { bestScore = score; bestIdx = o; }
          }
          out[i].answers.q[q.key] = q.type === 'multi' ? [bestIdx] : bestIdx;
        }
      }
    } catch (e) { /* defaults above */ }
    return out;
  }

  /* ------------------------------------------------------------------ *
   * Export
   * ------------------------------------------------------------------ */

  var EFK = {
    version: VERSION,
    defaults: defaults,
    doctor: doctor,
    estimate: estimate,
    explainKnob: explainKnob,
    train: train,
    applyTraining: applyTraining,
    payload: payload,
    sampleLeads: sampleLeads,
    /* additive helpers used by studio.html and funnel.html */
    applicableQuestions: applicableQuestions,
    knobKeys: KNOB_KEYS.slice(),
    slugify: slugify,
    fmtMoney: fmtMoney,
    fmtHours: fmtHours,
    parseJobs: parseJobs,
    lenientParse: function (t) { return lenientParse(t, []); },
    firstBalanced: firstBalanced,
    /* v1.1 */
    RELAY_URL: RELAY_URL,
    leadMode: leadMode,
    relayBody: relayBody,
    ALERT_LINE: ALERT_LINE,
    alertKey: alertKey,
    alertRelayBody: alertRelayBody,
    sendLead: sendLead,
    /* v1.2.1 */
    webhookReadable: webhookReadable,
    postWebhook: postWebhook,
    splitLinkFragment: splitLinkFragment,
    linkUtm: linkUtm,
    callPrepLink: callPrepLink,
    isPlaceholderUrl: isPlaceholderUrl,
    linkConfig: linkConfig,
    encodeLink: encodeLink,
    decodeLink: decodeLink,
    LINK_MAX_FRAGMENT: LINK_MAX_FRAGMENT,
    LINK_MAX_JSON: LINK_MAX_JSON,
    /* v1.2 */
    fakeCheck: fakeCheck,
    watchMatch: watchMatch,
    publicConfig: publicConfig,
    timelineStyles: TIMELINE_STYLES.slice()
  };

  /* ------------------------------------------------------------------ *
   * 12. Forgiving past-jobs parser (CSV, tabs, semicolons, pipes)
   * ------------------------------------------------------------------ */

  function splitRow(line) {
    if (line.indexOf('\t') !== -1) return line.split('\t');
    if (line.indexOf('|') !== -1 && line.indexOf(',') === -1) return line.split('|');
    if (line.indexOf(';') !== -1 && line.indexOf(',') === -1) return line.split(';');
    /* comma split that respects quotes */
    var out = [], cur = '', inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line[i];
      if (ch === '"') { inQ = !inQ; continue; }
      if (ch === ',' && !inQ) { out.push(cur); cur = ''; continue; }
      cur += ch;
    }
    out.push(cur);
    return out;
  }

  function parseJobs(text) {
    var jobs = [], problems = [];
    try {
      var lines = String(text || '').split(/\r\n|\r|\n/);
      var order = null;
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (!line || !line.trim()) continue;
        var cells = splitRow(line);
        for (var c = 0; c < cells.length; c++) cells[c] = String(cells[c]).trim();
        var joined = cells.join(' ').toLowerCase();

        if (order === null && /service|job|item/.test(joined) && /actual|final|real|billed/.test(joined)) {
          order = { service: -1, lo: -1, hi: -1, actual: -1 };
          for (var h = 0; h < cells.length; h++) {
            var hh = cells[h].toLowerCase();
            if (order.service === -1 && /service|job|item|type/.test(hh)) order.service = h;
            else if (order.lo === -1 && /(low|lo|min|from)/.test(hh) && !/actual/.test(hh)) order.lo = h;
            else if (order.hi === -1 && /(high|hi|max|to)/.test(hh) && !/actual/.test(hh)) order.hi = h;
            else if (order.actual === -1 && /actual|final|real|billed/.test(hh)) order.actual = h;
          }
          continue;
        }
        var nums = [];
        for (var k = 0; k < cells.length; k++) { var nv = toNum(cells[k]); if (nv !== null) nums.push({ i: k, v: nv }); }
        var name = '';
        for (var m = 0; m < cells.length; m++) {
          if (cells[m] && toNum(cells[m]) === null) { name = cells[m]; break; }
        }
        var lo = null, hi = null, act = null;
        if (order && order.service !== -1 && order.actual !== -1 && cells.length > order.actual) {
          name = cells[order.service] || name;
          lo = order.lo !== -1 ? toNum(cells[order.lo]) : null;
          hi = order.hi !== -1 ? toNum(cells[order.hi]) : null;
          act = toNum(cells[order.actual]);
        } else if (nums.length >= 3) {
          lo = nums[0].v; hi = nums[1].v; act = nums[2].v;
        } else if (nums.length === 2) {
          lo = nums[0].v; hi = nums[0].v; act = nums[1].v;
        } else {
          problems.push('Line ' + (i + 1) + ' did not have enough numbers on it, so we skipped it.');
          continue;
        }
        if (!name) { problems.push('Line ' + (i + 1) + ' had no service name, so we skipped it.'); continue; }
        if (act === null) { problems.push('Line ' + (i + 1) + ' had no final price, so we skipped it.'); continue; }
        jobs.push({ service: name, quoted_lo: lo, quoted_hi: hi, actual: act });
        if (jobs.length > 2000) break;
      }
    } catch (e) {
      problems.push('We could not read that. Paste four columns: service, quoted low, quoted high, and what it actually came to.');
    }
    return { jobs: jobs, problems: problems };
  }

  root.EFK = EFK;
  /* node / ESM interop. A file imported with `await import('./engine.js')` hands back
   * EFK on .default (and on .EFK), and globalThis.EFK is set either way. No `export`
   * keyword is used, because that would make this file unreadable to plain `require`. */
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = EFK;
    module.exports.EFK = EFK;
    module.exports.default = EFK;
  }

})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
